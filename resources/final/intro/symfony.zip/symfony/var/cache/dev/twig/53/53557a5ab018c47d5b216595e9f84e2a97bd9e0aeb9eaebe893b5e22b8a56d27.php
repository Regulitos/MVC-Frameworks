<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_596134ad84a45d3a703ef1c943d6679f4d623e85895794760a3bbcf0e91e4958 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_297439ed22be81bae725c32eb1dffe367800a4c8d4fdee00e4930a2d532ceb75 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_297439ed22be81bae725c32eb1dffe367800a4c8d4fdee00e4930a2d532ceb75->enter($__internal_297439ed22be81bae725c32eb1dffe367800a4c8d4fdee00e4930a2d532ceb75_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $__internal_05c8a3be248f4c35120d5dcde71094b8e68908b27fa8e827d63f7ac26803bfad = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_05c8a3be248f4c35120d5dcde71094b8e68908b27fa8e827d63f7ac26803bfad->enter($__internal_05c8a3be248f4c35120d5dcde71094b8e68908b27fa8e827d63f7ac26803bfad_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_297439ed22be81bae725c32eb1dffe367800a4c8d4fdee00e4930a2d532ceb75->leave($__internal_297439ed22be81bae725c32eb1dffe367800a4c8d4fdee00e4930a2d532ceb75_prof);

        
        $__internal_05c8a3be248f4c35120d5dcde71094b8e68908b27fa8e827d63f7ac26803bfad->leave($__internal_05c8a3be248f4c35120d5dcde71094b8e68908b27fa8e827d63f7ac26803bfad_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_1cc1118ef81aa0fa4735dfc391c5006d65b4eae756d87620f8fed87bcac0f4d5 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1cc1118ef81aa0fa4735dfc391c5006d65b4eae756d87620f8fed87bcac0f4d5->enter($__internal_1cc1118ef81aa0fa4735dfc391c5006d65b4eae756d87620f8fed87bcac0f4d5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        $__internal_26dc16305be425b9d60e84a543adc3de649100c65cbc2cbfe9107584063ff292 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_26dc16305be425b9d60e84a543adc3de649100c65cbc2cbfe9107584063ff292->enter($__internal_26dc16305be425b9d60e84a543adc3de649100c65cbc2cbfe9107584063ff292_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_26dc16305be425b9d60e84a543adc3de649100c65cbc2cbfe9107584063ff292->leave($__internal_26dc16305be425b9d60e84a543adc3de649100c65cbc2cbfe9107584063ff292_prof);

        
        $__internal_1cc1118ef81aa0fa4735dfc391c5006d65b4eae756d87620f8fed87bcac0f4d5->leave($__internal_1cc1118ef81aa0fa4735dfc391c5006d65b4eae756d87620f8fed87bcac0f4d5_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_286e45b57346945bd144545648bc2f732497cf42b4dcd9c0924a3ec6506b516c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_286e45b57346945bd144545648bc2f732497cf42b4dcd9c0924a3ec6506b516c->enter($__internal_286e45b57346945bd144545648bc2f732497cf42b4dcd9c0924a3ec6506b516c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_8d75d7c9fac6f50623bdc866ebb75774e319c18ff5a83139604eb40dc5a54c3c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8d75d7c9fac6f50623bdc866ebb75774e319c18ff5a83139604eb40dc5a54c3c->enter($__internal_8d75d7c9fac6f50623bdc866ebb75774e319c18ff5a83139604eb40dc5a54c3c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_8d75d7c9fac6f50623bdc866ebb75774e319c18ff5a83139604eb40dc5a54c3c->leave($__internal_8d75d7c9fac6f50623bdc866ebb75774e319c18ff5a83139604eb40dc5a54c3c_prof);

        
        $__internal_286e45b57346945bd144545648bc2f732497cf42b4dcd9c0924a3ec6506b516c->leave($__internal_286e45b57346945bd144545648bc2f732497cf42b4dcd9c0924a3ec6506b516c_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_645ba8eee3733d3ee60afe8cdfd936d3afa8eb51d0f48d149a52a3ce937aa3ce = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_645ba8eee3733d3ee60afe8cdfd936d3afa8eb51d0f48d149a52a3ce937aa3ce->enter($__internal_645ba8eee3733d3ee60afe8cdfd936d3afa8eb51d0f48d149a52a3ce937aa3ce_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_1a71170e5d5a54a6e532636085ef8618db490e9cad5f89ab46411e04b4ca4205 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1a71170e5d5a54a6e532636085ef8618db490e9cad5f89ab46411e04b4ca4205->enter($__internal_1a71170e5d5a54a6e532636085ef8618db490e9cad5f89ab46411e04b4ca4205_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_1a71170e5d5a54a6e532636085ef8618db490e9cad5f89ab46411e04b4ca4205->leave($__internal_1a71170e5d5a54a6e532636085ef8618db490e9cad5f89ab46411e04b4ca4205_prof);

        
        $__internal_645ba8eee3733d3ee60afe8cdfd936d3afa8eb51d0f48d149a52a3ce937aa3ce->leave($__internal_645ba8eee3733d3ee60afe8cdfd936d3afa8eb51d0f48d149a52a3ce937aa3ce_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  94 => 13,  85 => 12,  71 => 7,  68 => 6,  59 => 5,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
", "@WebProfiler/Collector/router.html.twig", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\intro\\symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Collector\\router.html.twig");
    }
}
