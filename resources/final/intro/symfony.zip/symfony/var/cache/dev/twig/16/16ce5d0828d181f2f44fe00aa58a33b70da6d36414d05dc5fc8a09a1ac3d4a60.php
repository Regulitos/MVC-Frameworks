<?php

/* @WebProfiler/Collector/ajax.html.twig */
class __TwigTemplate_9bec9c1139426df76c081e6ef116bd2e812519a4d5506c90fcd87d715956378d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/ajax.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_52badd5fdca253247950f1c7a1ac4ef199cd3627579d165fe13c3804bfd01413 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_52badd5fdca253247950f1c7a1ac4ef199cd3627579d165fe13c3804bfd01413->enter($__internal_52badd5fdca253247950f1c7a1ac4ef199cd3627579d165fe13c3804bfd01413_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/ajax.html.twig"));

        $__internal_4647258e96d581e1947a6486b4a92df418a8bf392dd6bbbbca69e03956d7c91f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4647258e96d581e1947a6486b4a92df418a8bf392dd6bbbbca69e03956d7c91f->enter($__internal_4647258e96d581e1947a6486b4a92df418a8bf392dd6bbbbca69e03956d7c91f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/ajax.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_52badd5fdca253247950f1c7a1ac4ef199cd3627579d165fe13c3804bfd01413->leave($__internal_52badd5fdca253247950f1c7a1ac4ef199cd3627579d165fe13c3804bfd01413_prof);

        
        $__internal_4647258e96d581e1947a6486b4a92df418a8bf392dd6bbbbca69e03956d7c91f->leave($__internal_4647258e96d581e1947a6486b4a92df418a8bf392dd6bbbbca69e03956d7c91f_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_dc0f5d23b292aeda9cdb0aa5b3c59d1538650d32897df9ff361352c30e45ffb0 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_dc0f5d23b292aeda9cdb0aa5b3c59d1538650d32897df9ff361352c30e45ffb0->enter($__internal_dc0f5d23b292aeda9cdb0aa5b3c59d1538650d32897df9ff361352c30e45ffb0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        $__internal_180dba0fecb468e4a38a69f8d528bad17960a7855ff37089a12394a5d331adaa = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_180dba0fecb468e4a38a69f8d528bad17960a7855ff37089a12394a5d331adaa->enter($__internal_180dba0fecb468e4a38a69f8d528bad17960a7855ff37089a12394a5d331adaa_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        // line 4
        echo "    ";
        ob_start();
        // line 5
        echo "        ";
        echo twig_include($this->env, $context, "@WebProfiler/Icon/ajax.svg");
        echo "
        <span class=\"sf-toolbar-value sf-toolbar-ajax-request-counter\">0</span>
    ";
        $context["icon"] = ('' === $tmp = ob_get_clean()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        // line 8
        echo "
    ";
        // line 9
        $context["text"] = ('' === $tmp = "        <div class=\"sf-toolbar-info-piece\">
            <b class=\"sf-toolbar-ajax-info\"></b>
        </div>
        <div class=\"sf-toolbar-info-piece\">
            <table class=\"sf-toolbar-ajax-requests\">
                <thead>
                    <tr>
                        <th>Method</th>
                        <th>Type</th>
                        <th>Status</th>
                        <th>URL</th>
                        <th>Time</th>
                        <th>Profile</th>
                    </tr>
                </thead>
                <tbody class=\"sf-toolbar-ajax-request-list\"></tbody>
            </table>
        </div>
    ") ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        // line 29
        echo "
    ";
        // line 30
        echo twig_include($this->env, $context, "@WebProfiler/Profiler/toolbar_item.html.twig", array("link" => false));
        echo "
";
        
        $__internal_180dba0fecb468e4a38a69f8d528bad17960a7855ff37089a12394a5d331adaa->leave($__internal_180dba0fecb468e4a38a69f8d528bad17960a7855ff37089a12394a5d331adaa_prof);

        
        $__internal_dc0f5d23b292aeda9cdb0aa5b3c59d1538650d32897df9ff361352c30e45ffb0->leave($__internal_dc0f5d23b292aeda9cdb0aa5b3c59d1538650d32897df9ff361352c30e45ffb0_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/ajax.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  85 => 30,  82 => 29,  62 => 9,  59 => 8,  52 => 5,  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}
    {% set icon %}
        {{ include('@WebProfiler/Icon/ajax.svg') }}
        <span class=\"sf-toolbar-value sf-toolbar-ajax-request-counter\">0</span>
    {% endset %}

    {% set text %}
        <div class=\"sf-toolbar-info-piece\">
            <b class=\"sf-toolbar-ajax-info\"></b>
        </div>
        <div class=\"sf-toolbar-info-piece\">
            <table class=\"sf-toolbar-ajax-requests\">
                <thead>
                    <tr>
                        <th>Method</th>
                        <th>Type</th>
                        <th>Status</th>
                        <th>URL</th>
                        <th>Time</th>
                        <th>Profile</th>
                    </tr>
                </thead>
                <tbody class=\"sf-toolbar-ajax-request-list\"></tbody>
            </table>
        </div>
    {% endset %}

    {{ include('@WebProfiler/Profiler/toolbar_item.html.twig', { link: false }) }}
{% endblock %}
", "@WebProfiler/Collector/ajax.html.twig", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\intro\\symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Collector\\ajax.html.twig");
    }
}
