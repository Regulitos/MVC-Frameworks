<?php

/* base.html.twig */
class __TwigTemplate_cf276ec5c8aeca8007e33ee25c4885ab60c5782e044b68c641db76c6879257f8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8e9403c0f0a0c02264bbcaee731766efaa6714204ebf632f49b6090acb0c687b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8e9403c0f0a0c02264bbcaee731766efaa6714204ebf632f49b6090acb0c687b->enter($__internal_8e9403c0f0a0c02264bbcaee731766efaa6714204ebf632f49b6090acb0c687b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        $__internal_6bddda17bda9048740de006d6ca302c46c6089ba21d2c9d3b1dd99cfa2d6e5de = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6bddda17bda9048740de006d6ca302c46c6089ba21d2c9d3b1dd99cfa2d6e5de->enter($__internal_6bddda17bda9048740de006d6ca302c46c6089ba21d2c9d3b1dd99cfa2d6e5de_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>";
        // line 5
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        ";
        // line 6
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 7
        echo "        <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />
    </head>
    <body>
        ";
        // line 10
        $this->displayBlock('body', $context, $blocks);
        // line 11
        echo "        ";
        $this->displayBlock('javascripts', $context, $blocks);
        // line 12
        echo "    </body>
</html>
";
        
        $__internal_8e9403c0f0a0c02264bbcaee731766efaa6714204ebf632f49b6090acb0c687b->leave($__internal_8e9403c0f0a0c02264bbcaee731766efaa6714204ebf632f49b6090acb0c687b_prof);

        
        $__internal_6bddda17bda9048740de006d6ca302c46c6089ba21d2c9d3b1dd99cfa2d6e5de->leave($__internal_6bddda17bda9048740de006d6ca302c46c6089ba21d2c9d3b1dd99cfa2d6e5de_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_f3b2c893ab138c0c4bb15ac84fd9fce4755dde67cb16a5eb8d40fe4f662e3a0b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f3b2c893ab138c0c4bb15ac84fd9fce4755dde67cb16a5eb8d40fe4f662e3a0b->enter($__internal_f3b2c893ab138c0c4bb15ac84fd9fce4755dde67cb16a5eb8d40fe4f662e3a0b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_e145525dd5b7301c0a4e764a79e736ff4b3df66f491b1166104c7844f0c94fbf = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e145525dd5b7301c0a4e764a79e736ff4b3df66f491b1166104c7844f0c94fbf->enter($__internal_e145525dd5b7301c0a4e764a79e736ff4b3df66f491b1166104c7844f0c94fbf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Welcome!";
        
        $__internal_e145525dd5b7301c0a4e764a79e736ff4b3df66f491b1166104c7844f0c94fbf->leave($__internal_e145525dd5b7301c0a4e764a79e736ff4b3df66f491b1166104c7844f0c94fbf_prof);

        
        $__internal_f3b2c893ab138c0c4bb15ac84fd9fce4755dde67cb16a5eb8d40fe4f662e3a0b->leave($__internal_f3b2c893ab138c0c4bb15ac84fd9fce4755dde67cb16a5eb8d40fe4f662e3a0b_prof);

    }

    // line 6
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_e0356eafe43bdd11f1a942816025ef832b9d1f9f77b357c7b8131741f53c2f44 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e0356eafe43bdd11f1a942816025ef832b9d1f9f77b357c7b8131741f53c2f44->enter($__internal_e0356eafe43bdd11f1a942816025ef832b9d1f9f77b357c7b8131741f53c2f44_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_209d766de7c76a19597a8a27b35f0968c82542bbd36864f2da91a55a928d3788 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_209d766de7c76a19597a8a27b35f0968c82542bbd36864f2da91a55a928d3788->enter($__internal_209d766de7c76a19597a8a27b35f0968c82542bbd36864f2da91a55a928d3788_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_209d766de7c76a19597a8a27b35f0968c82542bbd36864f2da91a55a928d3788->leave($__internal_209d766de7c76a19597a8a27b35f0968c82542bbd36864f2da91a55a928d3788_prof);

        
        $__internal_e0356eafe43bdd11f1a942816025ef832b9d1f9f77b357c7b8131741f53c2f44->leave($__internal_e0356eafe43bdd11f1a942816025ef832b9d1f9f77b357c7b8131741f53c2f44_prof);

    }

    // line 10
    public function block_body($context, array $blocks = array())
    {
        $__internal_75dbaa04b4c18918cbe918f10b3f915a2c51b635f2b060ac80d47ae6ec97151a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_75dbaa04b4c18918cbe918f10b3f915a2c51b635f2b060ac80d47ae6ec97151a->enter($__internal_75dbaa04b4c18918cbe918f10b3f915a2c51b635f2b060ac80d47ae6ec97151a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_0c6154791960e8a5fa66f55e95e2dd4c3f4d0eabe68d47b34623c882602a8757 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0c6154791960e8a5fa66f55e95e2dd4c3f4d0eabe68d47b34623c882602a8757->enter($__internal_0c6154791960e8a5fa66f55e95e2dd4c3f4d0eabe68d47b34623c882602a8757_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_0c6154791960e8a5fa66f55e95e2dd4c3f4d0eabe68d47b34623c882602a8757->leave($__internal_0c6154791960e8a5fa66f55e95e2dd4c3f4d0eabe68d47b34623c882602a8757_prof);

        
        $__internal_75dbaa04b4c18918cbe918f10b3f915a2c51b635f2b060ac80d47ae6ec97151a->leave($__internal_75dbaa04b4c18918cbe918f10b3f915a2c51b635f2b060ac80d47ae6ec97151a_prof);

    }

    // line 11
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_b3df19e16d183174e7733a6b11d11fa4001e81683ce5bfce8cc0d0cc75022022 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b3df19e16d183174e7733a6b11d11fa4001e81683ce5bfce8cc0d0cc75022022->enter($__internal_b3df19e16d183174e7733a6b11d11fa4001e81683ce5bfce8cc0d0cc75022022_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_1ff2c9a4f2a44f8279999a5566fc78651233115f291e0e3ba473cb263c851837 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1ff2c9a4f2a44f8279999a5566fc78651233115f291e0e3ba473cb263c851837->enter($__internal_1ff2c9a4f2a44f8279999a5566fc78651233115f291e0e3ba473cb263c851837_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_1ff2c9a4f2a44f8279999a5566fc78651233115f291e0e3ba473cb263c851837->leave($__internal_1ff2c9a4f2a44f8279999a5566fc78651233115f291e0e3ba473cb263c851837_prof);

        
        $__internal_b3df19e16d183174e7733a6b11d11fa4001e81683ce5bfce8cc0d0cc75022022->leave($__internal_b3df19e16d183174e7733a6b11d11fa4001e81683ce5bfce8cc0d0cc75022022_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  117 => 11,  100 => 10,  83 => 6,  65 => 5,  53 => 12,  50 => 11,  48 => 10,  41 => 7,  39 => 6,  35 => 5,  29 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>{% block title %}Welcome!{% endblock %}</title>
        {% block stylesheets %}{% endblock %}
        <link rel=\"icon\" type=\"image/x-icon\" href=\"{{ asset('favicon.ico') }}\" />
    </head>
    <body>
        {% block body %}{% endblock %}
        {% block javascripts %}{% endblock %}
    </body>
</html>
", "base.html.twig", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\intro\\symfony\\app\\Resources\\views\\base.html.twig");
    }
}
