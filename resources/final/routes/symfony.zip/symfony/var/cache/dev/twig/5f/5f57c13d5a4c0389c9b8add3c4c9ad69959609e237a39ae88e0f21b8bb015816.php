<?php

/* @Twig/Exception/exception_full.html.twig */
class __TwigTemplate_6b1b118ca9a4f51e779e95d9f3e4cd5a7efce8433f21005203583c13633b4d1f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@Twig/layout.html.twig", "@Twig/Exception/exception_full.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@Twig/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_38da335092ec56f8bbeea496252950ba7be23989869f504f17d9cb99c5b3dc1c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_38da335092ec56f8bbeea496252950ba7be23989869f504f17d9cb99c5b3dc1c->enter($__internal_38da335092ec56f8bbeea496252950ba7be23989869f504f17d9cb99c5b3dc1c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception_full.html.twig"));

        $__internal_94d167cceccdd0a4a3d2edc472651f013ec5eb42fd6e3a517e7e541e8d225316 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_94d167cceccdd0a4a3d2edc472651f013ec5eb42fd6e3a517e7e541e8d225316->enter($__internal_94d167cceccdd0a4a3d2edc472651f013ec5eb42fd6e3a517e7e541e8d225316_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception_full.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_38da335092ec56f8bbeea496252950ba7be23989869f504f17d9cb99c5b3dc1c->leave($__internal_38da335092ec56f8bbeea496252950ba7be23989869f504f17d9cb99c5b3dc1c_prof);

        
        $__internal_94d167cceccdd0a4a3d2edc472651f013ec5eb42fd6e3a517e7e541e8d225316->leave($__internal_94d167cceccdd0a4a3d2edc472651f013ec5eb42fd6e3a517e7e541e8d225316_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_792103819e0d396b4add34fbd6079e10f57d8a8443131c095711838190d4001c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_792103819e0d396b4add34fbd6079e10f57d8a8443131c095711838190d4001c->enter($__internal_792103819e0d396b4add34fbd6079e10f57d8a8443131c095711838190d4001c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        $__internal_c769b13bfd175bccd8354bb80f0d821267ecf26648190d04f86d7546e811f01a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c769b13bfd175bccd8354bb80f0d821267ecf26648190d04f86d7546e811f01a->enter($__internal_c769b13bfd175bccd8354bb80f0d821267ecf26648190d04f86d7546e811f01a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    <style>
        .sf-reset .traces {
            padding-bottom: 14px;
        }
        .sf-reset .traces li {
            font-size: 12px;
            color: #868686;
            padding: 5px 4px;
            list-style-type: decimal;
            margin-left: 20px;
        }
        .sf-reset #logs .traces li.error {
            font-style: normal;
            color: #AA3333;
            background: #f9ecec;
        }
        .sf-reset #logs .traces li.warning {
            font-style: normal;
            background: #ffcc00;
        }
        /* fix for Opera not liking empty <li> */
        .sf-reset .traces li:after {
            content: \"\\00A0\";
        }
        .sf-reset .trace {
            border: 1px solid #D3D3D3;
            padding: 10px;
            overflow: auto;
            margin: 10px 0 20px;
        }
        .sf-reset .block-exception {
            -moz-border-radius: 16px;
            -webkit-border-radius: 16px;
            border-radius: 16px;
            margin-bottom: 20px;
            background-color: #f6f6f6;
            border: 1px solid #dfdfdf;
            padding: 30px 28px;
            word-wrap: break-word;
            overflow: hidden;
        }
        .sf-reset .block-exception div {
            color: #313131;
            font-size: 10px;
        }
        .sf-reset .block-exception-detected .illustration-exception,
        .sf-reset .block-exception-detected .text-exception {
            float: left;
        }
        .sf-reset .block-exception-detected .illustration-exception {
            width: 152px;
        }
        .sf-reset .block-exception-detected .text-exception {
            width: 670px;
            padding: 30px 44px 24px 46px;
            position: relative;
        }
        .sf-reset .text-exception .open-quote,
        .sf-reset .text-exception .close-quote {
            font-family: Arial, Helvetica, sans-serif;
            position: absolute;
            color: #C9C9C9;
            font-size: 8em;
        }
        .sf-reset .open-quote {
            top: 0;
            left: 0;
        }
        .sf-reset .close-quote {
            bottom: -0.5em;
            right: 50px;
        }
        .sf-reset .block-exception p {
            font-family: Arial, Helvetica, sans-serif;
        }
        .sf-reset .block-exception p a,
        .sf-reset .block-exception p a:hover {
            color: #565656;
        }
        .sf-reset .logs h2 {
            float: left;
            width: 654px;
        }
        .sf-reset .error-count, .sf-reset .support {
            float: right;
            width: 170px;
            text-align: right;
        }
        .sf-reset .error-count span {
             display: inline-block;
             background-color: #aacd4e;
             -moz-border-radius: 6px;
             -webkit-border-radius: 6px;
             border-radius: 6px;
             padding: 4px;
             color: white;
             margin-right: 2px;
             font-size: 11px;
             font-weight: bold;
        }

        .sf-reset .support a {
            display: inline-block;
            -moz-border-radius: 6px;
            -webkit-border-radius: 6px;
            border-radius: 6px;
            padding: 4px;
            color: #000000;
            margin-right: 2px;
            font-size: 11px;
            font-weight: bold;
        }

        .sf-reset .toggle {
            vertical-align: middle;
        }
        .sf-reset .linked ul,
        .sf-reset .linked li {
            display: inline;
        }
        .sf-reset #output-content {
            color: #000;
            font-size: 12px;
        }
        .sf-reset #traces-text pre {
            white-space: pre;
            font-size: 12px;
            font-family: monospace;
        }
    </style>
";
        
        $__internal_c769b13bfd175bccd8354bb80f0d821267ecf26648190d04f86d7546e811f01a->leave($__internal_c769b13bfd175bccd8354bb80f0d821267ecf26648190d04f86d7546e811f01a_prof);

        
        $__internal_792103819e0d396b4add34fbd6079e10f57d8a8443131c095711838190d4001c->leave($__internal_792103819e0d396b4add34fbd6079e10f57d8a8443131c095711838190d4001c_prof);

    }

    // line 136
    public function block_title($context, array $blocks = array())
    {
        $__internal_c759db00b2728c96639191ea7eab93516c1e768067af19f2f8d0c5a1e47e60a8 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c759db00b2728c96639191ea7eab93516c1e768067af19f2f8d0c5a1e47e60a8->enter($__internal_c759db00b2728c96639191ea7eab93516c1e768067af19f2f8d0c5a1e47e60a8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_b1fc9f1255f40f16273b5827e39ebc1960d3b434c36703829cd25180f531cd12 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b1fc9f1255f40f16273b5827e39ebc1960d3b434c36703829cd25180f531cd12->enter($__internal_b1fc9f1255f40f16273b5827e39ebc1960d3b434c36703829cd25180f531cd12_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 137
        echo "    ";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["exception"] ?? $this->getContext($context, "exception")), "message", array()), "html", null, true);
        echo " (";
        echo twig_escape_filter($this->env, ($context["status_code"] ?? $this->getContext($context, "status_code")), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, ($context["status_text"] ?? $this->getContext($context, "status_text")), "html", null, true);
        echo ")
";
        
        $__internal_b1fc9f1255f40f16273b5827e39ebc1960d3b434c36703829cd25180f531cd12->leave($__internal_b1fc9f1255f40f16273b5827e39ebc1960d3b434c36703829cd25180f531cd12_prof);

        
        $__internal_c759db00b2728c96639191ea7eab93516c1e768067af19f2f8d0c5a1e47e60a8->leave($__internal_c759db00b2728c96639191ea7eab93516c1e768067af19f2f8d0c5a1e47e60a8_prof);

    }

    // line 140
    public function block_body($context, array $blocks = array())
    {
        $__internal_2935e6c617e68ff764a099bba94ff1d652a6a1b8654d8b5f4fb967b4eb2cdde6 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2935e6c617e68ff764a099bba94ff1d652a6a1b8654d8b5f4fb967b4eb2cdde6->enter($__internal_2935e6c617e68ff764a099bba94ff1d652a6a1b8654d8b5f4fb967b4eb2cdde6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_baf65608832f234e5b5b71cf49096e0804770b5e40a4d32cd550e8726ff7d7c1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_baf65608832f234e5b5b71cf49096e0804770b5e40a4d32cd550e8726ff7d7c1->enter($__internal_baf65608832f234e5b5b71cf49096e0804770b5e40a4d32cd550e8726ff7d7c1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 141
        echo "    ";
        $this->loadTemplate("@Twig/Exception/exception.html.twig", "@Twig/Exception/exception_full.html.twig", 141)->display($context);
        
        $__internal_baf65608832f234e5b5b71cf49096e0804770b5e40a4d32cd550e8726ff7d7c1->leave($__internal_baf65608832f234e5b5b71cf49096e0804770b5e40a4d32cd550e8726ff7d7c1_prof);

        
        $__internal_2935e6c617e68ff764a099bba94ff1d652a6a1b8654d8b5f4fb967b4eb2cdde6->leave($__internal_2935e6c617e68ff764a099bba94ff1d652a6a1b8654d8b5f4fb967b4eb2cdde6_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/exception_full.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  226 => 141,  217 => 140,  200 => 137,  191 => 136,  51 => 4,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@Twig/layout.html.twig' %}

{% block head %}
    <style>
        .sf-reset .traces {
            padding-bottom: 14px;
        }
        .sf-reset .traces li {
            font-size: 12px;
            color: #868686;
            padding: 5px 4px;
            list-style-type: decimal;
            margin-left: 20px;
        }
        .sf-reset #logs .traces li.error {
            font-style: normal;
            color: #AA3333;
            background: #f9ecec;
        }
        .sf-reset #logs .traces li.warning {
            font-style: normal;
            background: #ffcc00;
        }
        /* fix for Opera not liking empty <li> */
        .sf-reset .traces li:after {
            content: \"\\00A0\";
        }
        .sf-reset .trace {
            border: 1px solid #D3D3D3;
            padding: 10px;
            overflow: auto;
            margin: 10px 0 20px;
        }
        .sf-reset .block-exception {
            -moz-border-radius: 16px;
            -webkit-border-radius: 16px;
            border-radius: 16px;
            margin-bottom: 20px;
            background-color: #f6f6f6;
            border: 1px solid #dfdfdf;
            padding: 30px 28px;
            word-wrap: break-word;
            overflow: hidden;
        }
        .sf-reset .block-exception div {
            color: #313131;
            font-size: 10px;
        }
        .sf-reset .block-exception-detected .illustration-exception,
        .sf-reset .block-exception-detected .text-exception {
            float: left;
        }
        .sf-reset .block-exception-detected .illustration-exception {
            width: 152px;
        }
        .sf-reset .block-exception-detected .text-exception {
            width: 670px;
            padding: 30px 44px 24px 46px;
            position: relative;
        }
        .sf-reset .text-exception .open-quote,
        .sf-reset .text-exception .close-quote {
            font-family: Arial, Helvetica, sans-serif;
            position: absolute;
            color: #C9C9C9;
            font-size: 8em;
        }
        .sf-reset .open-quote {
            top: 0;
            left: 0;
        }
        .sf-reset .close-quote {
            bottom: -0.5em;
            right: 50px;
        }
        .sf-reset .block-exception p {
            font-family: Arial, Helvetica, sans-serif;
        }
        .sf-reset .block-exception p a,
        .sf-reset .block-exception p a:hover {
            color: #565656;
        }
        .sf-reset .logs h2 {
            float: left;
            width: 654px;
        }
        .sf-reset .error-count, .sf-reset .support {
            float: right;
            width: 170px;
            text-align: right;
        }
        .sf-reset .error-count span {
             display: inline-block;
             background-color: #aacd4e;
             -moz-border-radius: 6px;
             -webkit-border-radius: 6px;
             border-radius: 6px;
             padding: 4px;
             color: white;
             margin-right: 2px;
             font-size: 11px;
             font-weight: bold;
        }

        .sf-reset .support a {
            display: inline-block;
            -moz-border-radius: 6px;
            -webkit-border-radius: 6px;
            border-radius: 6px;
            padding: 4px;
            color: #000000;
            margin-right: 2px;
            font-size: 11px;
            font-weight: bold;
        }

        .sf-reset .toggle {
            vertical-align: middle;
        }
        .sf-reset .linked ul,
        .sf-reset .linked li {
            display: inline;
        }
        .sf-reset #output-content {
            color: #000;
            font-size: 12px;
        }
        .sf-reset #traces-text pre {
            white-space: pre;
            font-size: 12px;
            font-family: monospace;
        }
    </style>
{% endblock %}

{% block title %}
    {{ exception.message }} ({{ status_code }} {{ status_text }})
{% endblock %}

{% block body %}
    {% include '@Twig/Exception/exception.html.twig' %}
{% endblock %}
", "@Twig/Exception/exception_full.html.twig", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\routes\\symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\exception_full.html.twig");
    }
}
