<?php

/* @WebProfiler/Collector/exception.html.twig */
class __TwigTemplate_91f23d26d1e9c4d15bd74abc1f548fe71498140eaf4fd2e477e058e8a9bd1df4 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/exception.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e4dc5afd7109853338e9f85f84b2ba7c1151add8489e77e68b844c6757291dca = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e4dc5afd7109853338e9f85f84b2ba7c1151add8489e77e68b844c6757291dca->enter($__internal_e4dc5afd7109853338e9f85f84b2ba7c1151add8489e77e68b844c6757291dca_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/exception.html.twig"));

        $__internal_88c423204390793d56fb5b6df4fb9517732b516cf3384ec27491d068796c90dc = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_88c423204390793d56fb5b6df4fb9517732b516cf3384ec27491d068796c90dc->enter($__internal_88c423204390793d56fb5b6df4fb9517732b516cf3384ec27491d068796c90dc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/exception.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_e4dc5afd7109853338e9f85f84b2ba7c1151add8489e77e68b844c6757291dca->leave($__internal_e4dc5afd7109853338e9f85f84b2ba7c1151add8489e77e68b844c6757291dca_prof);

        
        $__internal_88c423204390793d56fb5b6df4fb9517732b516cf3384ec27491d068796c90dc->leave($__internal_88c423204390793d56fb5b6df4fb9517732b516cf3384ec27491d068796c90dc_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_d611c6792c9c8dad979c474efb694edf1df193adbf2857e7af740736b3a60b77 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d611c6792c9c8dad979c474efb694edf1df193adbf2857e7af740736b3a60b77->enter($__internal_d611c6792c9c8dad979c474efb694edf1df193adbf2857e7af740736b3a60b77_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        $__internal_03e1322ac0a919e3e62451805669a68e35dc85e4767013073f762ead35071e59 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_03e1322ac0a919e3e62451805669a68e35dc85e4767013073f762ead35071e59->enter($__internal_03e1322ac0a919e3e62451805669a68e35dc85e4767013073f762ead35071e59_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    ";
        if ($this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) {
            // line 5
            echo "        <style>
            ";
            // line 6
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_exception_css", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
            echo "
        </style>
    ";
        }
        // line 9
        echo "    ";
        $this->displayParentBlock("head", $context, $blocks);
        echo "
";
        
        $__internal_03e1322ac0a919e3e62451805669a68e35dc85e4767013073f762ead35071e59->leave($__internal_03e1322ac0a919e3e62451805669a68e35dc85e4767013073f762ead35071e59_prof);

        
        $__internal_d611c6792c9c8dad979c474efb694edf1df193adbf2857e7af740736b3a60b77->leave($__internal_d611c6792c9c8dad979c474efb694edf1df193adbf2857e7af740736b3a60b77_prof);

    }

    // line 12
    public function block_menu($context, array $blocks = array())
    {
        $__internal_e365c8c1d144686d089ea5165e8d5dea8e0dfbc7594ac52abedf35bedc3013ee = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e365c8c1d144686d089ea5165e8d5dea8e0dfbc7594ac52abedf35bedc3013ee->enter($__internal_e365c8c1d144686d089ea5165e8d5dea8e0dfbc7594ac52abedf35bedc3013ee_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_f24f7fedbf395fafdd1ce6d4bb4a58ecf96957c05a3660333453f8696ce7eaf3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f24f7fedbf395fafdd1ce6d4bb4a58ecf96957c05a3660333453f8696ce7eaf3->enter($__internal_f24f7fedbf395fafdd1ce6d4bb4a58ecf96957c05a3660333453f8696ce7eaf3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 13
        echo "    <span class=\"label ";
        echo (($this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) ? ("label-status-error") : ("disabled"));
        echo "\">
        <span class=\"icon\">";
        // line 14
        echo twig_include($this->env, $context, "@WebProfiler/Icon/exception.svg");
        echo "</span>
        <strong>Exception</strong>
        ";
        // line 16
        if ($this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) {
            // line 17
            echo "            <span class=\"count\">
                <span>1</span>
            </span>
        ";
        }
        // line 21
        echo "    </span>
";
        
        $__internal_f24f7fedbf395fafdd1ce6d4bb4a58ecf96957c05a3660333453f8696ce7eaf3->leave($__internal_f24f7fedbf395fafdd1ce6d4bb4a58ecf96957c05a3660333453f8696ce7eaf3_prof);

        
        $__internal_e365c8c1d144686d089ea5165e8d5dea8e0dfbc7594ac52abedf35bedc3013ee->leave($__internal_e365c8c1d144686d089ea5165e8d5dea8e0dfbc7594ac52abedf35bedc3013ee_prof);

    }

    // line 24
    public function block_panel($context, array $blocks = array())
    {
        $__internal_6f6606d51a4ac0f23f2cf92bd2d3318e0cd8a8dbe78307bba3936299a8477d9e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6f6606d51a4ac0f23f2cf92bd2d3318e0cd8a8dbe78307bba3936299a8477d9e->enter($__internal_6f6606d51a4ac0f23f2cf92bd2d3318e0cd8a8dbe78307bba3936299a8477d9e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_e00d0f15751b5fc763a794555a2af25f65e6c35a98b115c2ca5743e3eaba2d23 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e00d0f15751b5fc763a794555a2af25f65e6c35a98b115c2ca5743e3eaba2d23->enter($__internal_e00d0f15751b5fc763a794555a2af25f65e6c35a98b115c2ca5743e3eaba2d23_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 25
        echo "    <h2>Exceptions</h2>

    ";
        // line 27
        if ( !$this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) {
            // line 28
            echo "        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    ";
        } else {
            // line 32
            echo "        <div class=\"sf-reset\">
            ";
            // line 33
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_exception", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
            echo "
        </div>
    ";
        }
        
        $__internal_e00d0f15751b5fc763a794555a2af25f65e6c35a98b115c2ca5743e3eaba2d23->leave($__internal_e00d0f15751b5fc763a794555a2af25f65e6c35a98b115c2ca5743e3eaba2d23_prof);

        
        $__internal_6f6606d51a4ac0f23f2cf92bd2d3318e0cd8a8dbe78307bba3936299a8477d9e->leave($__internal_6f6606d51a4ac0f23f2cf92bd2d3318e0cd8a8dbe78307bba3936299a8477d9e_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/exception.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  138 => 33,  135 => 32,  129 => 28,  127 => 27,  123 => 25,  114 => 24,  103 => 21,  97 => 17,  95 => 16,  90 => 14,  85 => 13,  76 => 12,  63 => 9,  57 => 6,  54 => 5,  51 => 4,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block head %}
    {% if collector.hasexception %}
        <style>
            {{ render(path('_profiler_exception_css', { token: token })) }}
        </style>
    {% endif %}
    {{ parent() }}
{% endblock %}

{% block menu %}
    <span class=\"label {{ collector.hasexception ? 'label-status-error' : 'disabled' }}\">
        <span class=\"icon\">{{ include('@WebProfiler/Icon/exception.svg') }}</span>
        <strong>Exception</strong>
        {% if collector.hasexception %}
            <span class=\"count\">
                <span>1</span>
            </span>
        {% endif %}
    </span>
{% endblock %}

{% block panel %}
    <h2>Exceptions</h2>

    {% if not collector.hasexception %}
        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    {% else %}
        <div class=\"sf-reset\">
            {{ render(path('_profiler_exception', { token: token })) }}
        </div>
    {% endif %}
{% endblock %}
", "@WebProfiler/Collector/exception.html.twig", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\routes\\symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Collector\\exception.html.twig");
    }
}
