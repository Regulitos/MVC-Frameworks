<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_596134ad84a45d3a703ef1c943d6679f4d623e85895794760a3bbcf0e91e4958 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5f219e0d37384c8c57d902f331999dcf5fc50abfa49ec9593b7c5adb3293523a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5f219e0d37384c8c57d902f331999dcf5fc50abfa49ec9593b7c5adb3293523a->enter($__internal_5f219e0d37384c8c57d902f331999dcf5fc50abfa49ec9593b7c5adb3293523a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $__internal_1bc1fc1f866e4072e2d20746950484de7f048d42f1ddfdb2348efcc81a470c92 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1bc1fc1f866e4072e2d20746950484de7f048d42f1ddfdb2348efcc81a470c92->enter($__internal_1bc1fc1f866e4072e2d20746950484de7f048d42f1ddfdb2348efcc81a470c92_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_5f219e0d37384c8c57d902f331999dcf5fc50abfa49ec9593b7c5adb3293523a->leave($__internal_5f219e0d37384c8c57d902f331999dcf5fc50abfa49ec9593b7c5adb3293523a_prof);

        
        $__internal_1bc1fc1f866e4072e2d20746950484de7f048d42f1ddfdb2348efcc81a470c92->leave($__internal_1bc1fc1f866e4072e2d20746950484de7f048d42f1ddfdb2348efcc81a470c92_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_c650a57d65b51443723628873b2c37d1491e946c9ed3d317a4131751b3bcba5d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c650a57d65b51443723628873b2c37d1491e946c9ed3d317a4131751b3bcba5d->enter($__internal_c650a57d65b51443723628873b2c37d1491e946c9ed3d317a4131751b3bcba5d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        $__internal_1047eba4b45cb471e76feda7bb3ec93746a2a564a878531cc780df8e26184ecb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1047eba4b45cb471e76feda7bb3ec93746a2a564a878531cc780df8e26184ecb->enter($__internal_1047eba4b45cb471e76feda7bb3ec93746a2a564a878531cc780df8e26184ecb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_1047eba4b45cb471e76feda7bb3ec93746a2a564a878531cc780df8e26184ecb->leave($__internal_1047eba4b45cb471e76feda7bb3ec93746a2a564a878531cc780df8e26184ecb_prof);

        
        $__internal_c650a57d65b51443723628873b2c37d1491e946c9ed3d317a4131751b3bcba5d->leave($__internal_c650a57d65b51443723628873b2c37d1491e946c9ed3d317a4131751b3bcba5d_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_b1c66bdebf432d9d291ff5a202810322b75144d7fa92ed1956d88c35c164cb2e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b1c66bdebf432d9d291ff5a202810322b75144d7fa92ed1956d88c35c164cb2e->enter($__internal_b1c66bdebf432d9d291ff5a202810322b75144d7fa92ed1956d88c35c164cb2e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_e53fce17972ea63929ee23dfa63db8de80ca3fc88036ae2988ed21b663938f2d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e53fce17972ea63929ee23dfa63db8de80ca3fc88036ae2988ed21b663938f2d->enter($__internal_e53fce17972ea63929ee23dfa63db8de80ca3fc88036ae2988ed21b663938f2d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_e53fce17972ea63929ee23dfa63db8de80ca3fc88036ae2988ed21b663938f2d->leave($__internal_e53fce17972ea63929ee23dfa63db8de80ca3fc88036ae2988ed21b663938f2d_prof);

        
        $__internal_b1c66bdebf432d9d291ff5a202810322b75144d7fa92ed1956d88c35c164cb2e->leave($__internal_b1c66bdebf432d9d291ff5a202810322b75144d7fa92ed1956d88c35c164cb2e_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_d3dd82824fafb5b2905993d39a93c830075bbc7b1071774cffd0236409628f09 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d3dd82824fafb5b2905993d39a93c830075bbc7b1071774cffd0236409628f09->enter($__internal_d3dd82824fafb5b2905993d39a93c830075bbc7b1071774cffd0236409628f09_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_ada2e517b7c2f36e9305b2d2c356290dcd240f76735465c278d0313f1303919a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ada2e517b7c2f36e9305b2d2c356290dcd240f76735465c278d0313f1303919a->enter($__internal_ada2e517b7c2f36e9305b2d2c356290dcd240f76735465c278d0313f1303919a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_ada2e517b7c2f36e9305b2d2c356290dcd240f76735465c278d0313f1303919a->leave($__internal_ada2e517b7c2f36e9305b2d2c356290dcd240f76735465c278d0313f1303919a_prof);

        
        $__internal_d3dd82824fafb5b2905993d39a93c830075bbc7b1071774cffd0236409628f09->leave($__internal_d3dd82824fafb5b2905993d39a93c830075bbc7b1071774cffd0236409628f09_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  94 => 13,  85 => 12,  71 => 7,  68 => 6,  59 => 5,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
", "@WebProfiler/Collector/router.html.twig", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\routes\\symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Collector\\router.html.twig");
    }
}
