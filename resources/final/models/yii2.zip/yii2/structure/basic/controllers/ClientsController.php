<?php

namespace app\controllers;

use Yii;
use yii\filters\AccessControl;
use yii\web\Controller;
use yii\filters\VerbFilter;

class ClientsController extends Controller
{

    var $clients = [ 
                    [ 'id' => 0 , 'name' => 'Emmett', 'last_name' => 'Brown', 'email' => 'emmett@domain.com' ] ,
                    [ 'id' => 1 , 'name' => 'Jennifer', 'last_name' => 'Parker', 'email' => 'jennifer@domain.com' ] ,
                ];

    public function actionIndex()
    {
        //return "New controller method index";
        return $this->render('index', ['clients' => $this->clients]);
    }

    public function actionDetails( $id )
    {
        //return "Id: " . $id;
        return $this->render('details');
    }
}
