<?php

namespace app\controllers;

use Yii;
use yii\filters\AccessControl;
use yii\web\Controller;
use yii\filters\VerbFilter;
use app\models\Client;

class ClientsController extends Controller
{

    public function actionIndex()
    {
        //return "New controller method index";
        $client_instance = new Client;
        $clients = $client_instance->find()
                    ->all();
        return $this->render('index', ['clients' => $clients]);
    }

    public function actionDetails( $id )
    {
        //return "Id: " . $id;
        $client_instance = new Client;
        $client = $client_instance->findOne( $id );
        return $this->render('details' , [ 'client' => $client ]);
    }
}
