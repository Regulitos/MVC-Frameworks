<?php
namespace App\Controller;

use App\Controller\AppController;

class ClientsController extends AppController
{

    public function index()
    {
        //$this->response->body('New controller method index');
        //return $this->response;
        $this->loadModel('Clients');
        $clients = $this->Clients->find('all');
        $this->set('clients', $clients);
    }

    public function details( $id )
    {
        //$this->response->body('Id: ' . $id);
        //return $this->response;
        $this->loadModel('Clients');
        $clients = $this->Clients->find('all')->where( [ 'id' => $id ] )->first();
        $this->set('client', $clients);

    }
}