<?php

/* @Framework/Form/form_rows.html.php */
class __TwigTemplate_cc6c901cdef63566eb911ff579d162bdf1c429ff439dacd25386ab6f285f8d8f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_24516970961c756f3917f7d67ae4dc5b6ddd07c7b5439994f5209d4cf748d018 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_24516970961c756f3917f7d67ae4dc5b6ddd07c7b5439994f5209d4cf748d018->enter($__internal_24516970961c756f3917f7d67ae4dc5b6ddd07c7b5439994f5209d4cf748d018_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_rows.html.php"));

        $__internal_ef512ae14ed3878e41e1ca586c390fb367449c5aed296df30b73b8a4de47beb8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ef512ae14ed3878e41e1ca586c390fb367449c5aed296df30b73b8a4de47beb8->enter($__internal_ef512ae14ed3878e41e1ca586c390fb367449c5aed296df30b73b8a4de47beb8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_rows.html.php"));

        // line 1
        echo "<?php foreach (\$form as \$child) : ?>
    <?php echo \$view['form']->row(\$child) ?>
<?php endforeach; ?>
";
        
        $__internal_24516970961c756f3917f7d67ae4dc5b6ddd07c7b5439994f5209d4cf748d018->leave($__internal_24516970961c756f3917f7d67ae4dc5b6ddd07c7b5439994f5209d4cf748d018_prof);

        
        $__internal_ef512ae14ed3878e41e1ca586c390fb367449c5aed296df30b73b8a4de47beb8->leave($__internal_ef512ae14ed3878e41e1ca586c390fb367449c5aed296df30b73b8a4de47beb8_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_rows.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php foreach (\$form as \$child) : ?>
    <?php echo \$view['form']->row(\$child) ?>
<?php endforeach; ?>
", "@Framework/Form/form_rows.html.php", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\models\\symfony\\db_action\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\form_rows.html.php");
    }
}
