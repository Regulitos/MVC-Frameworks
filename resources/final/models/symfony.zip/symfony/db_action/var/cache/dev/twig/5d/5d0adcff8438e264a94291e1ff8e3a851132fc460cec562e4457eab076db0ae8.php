<?php

/* @Framework/FormTable/hidden_row.html.php */
class __TwigTemplate_cf2596bacc63137065402920d774b5256063187a65f51591cf623dd87798c29d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a0067fd1624955c6d019969a8b1411dd26b12b055a190bc88a7c726d016b6e87 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a0067fd1624955c6d019969a8b1411dd26b12b055a190bc88a7c726d016b6e87->enter($__internal_a0067fd1624955c6d019969a8b1411dd26b12b055a190bc88a7c726d016b6e87_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/hidden_row.html.php"));

        $__internal_f702ed43deee46376365954970afc0869bc1830c610aabf405e695c85907b7f0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f702ed43deee46376365954970afc0869bc1830c610aabf405e695c85907b7f0->enter($__internal_f702ed43deee46376365954970afc0869bc1830c610aabf405e695c85907b7f0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/hidden_row.html.php"));

        // line 1
        echo "<tr style=\"display: none\">
    <td colspan=\"2\">
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
";
        
        $__internal_a0067fd1624955c6d019969a8b1411dd26b12b055a190bc88a7c726d016b6e87->leave($__internal_a0067fd1624955c6d019969a8b1411dd26b12b055a190bc88a7c726d016b6e87_prof);

        
        $__internal_f702ed43deee46376365954970afc0869bc1830c610aabf405e695c85907b7f0->leave($__internal_f702ed43deee46376365954970afc0869bc1830c610aabf405e695c85907b7f0_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/hidden_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<tr style=\"display: none\">
    <td colspan=\"2\">
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
", "@Framework/FormTable/hidden_row.html.php", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\models\\symfony\\db_action\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\FormTable\\hidden_row.html.php");
    }
}
