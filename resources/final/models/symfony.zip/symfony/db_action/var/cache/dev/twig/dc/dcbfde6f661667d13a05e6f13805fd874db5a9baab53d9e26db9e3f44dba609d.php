<?php

/* @Twig/Exception/error.css.twig */
class __TwigTemplate_43e207f99fe2921cfe350cdef0e238b6199e42ae5461d651cd38238c2d0b4230 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_63a84a675f77815273e8ca8b574b881c499b8788e2acb8cdbed8fefcb8df3dfe = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_63a84a675f77815273e8ca8b574b881c499b8788e2acb8cdbed8fefcb8df3dfe->enter($__internal_63a84a675f77815273e8ca8b574b881c499b8788e2acb8cdbed8fefcb8df3dfe_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.css.twig"));

        $__internal_b62b7464143df35183957aeb10c32d03ab79748ada2304de12f80feed96b5245 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b62b7464143df35183957aeb10c32d03ab79748ada2304de12f80feed96b5245->enter($__internal_b62b7464143df35183957aeb10c32d03ab79748ada2304de12f80feed96b5245_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.css.twig"));

        // line 1
        echo "/*
";
        // line 2
        echo twig_escape_filter($this->env, ($context["status_code"] ?? $this->getContext($context, "status_code")), "css", null, true);
        echo " ";
        echo twig_escape_filter($this->env, ($context["status_text"] ?? $this->getContext($context, "status_text")), "css", null, true);
        echo "

*/
";
        
        $__internal_63a84a675f77815273e8ca8b574b881c499b8788e2acb8cdbed8fefcb8df3dfe->leave($__internal_63a84a675f77815273e8ca8b574b881c499b8788e2acb8cdbed8fefcb8df3dfe_prof);

        
        $__internal_b62b7464143df35183957aeb10c32d03ab79748ada2304de12f80feed96b5245->leave($__internal_b62b7464143df35183957aeb10c32d03ab79748ada2304de12f80feed96b5245_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/error.css.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  28 => 2,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("/*
{{ status_code }} {{ status_text }}

*/
", "@Twig/Exception/error.css.twig", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\models\\symfony\\db_action\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\error.css.twig");
    }
}
