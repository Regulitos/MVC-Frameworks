<?php

/* @Framework/Form/collection_widget.html.php */
class __TwigTemplate_255253f2c3060780688db7ce61005f093c0a2fc6e262175bc6b4c196785cb70d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_141827bea6f0a5ec4d8ee20e3f04f37f1c7e254c85881357dd0969ca219888bc = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_141827bea6f0a5ec4d8ee20e3f04f37f1c7e254c85881357dd0969ca219888bc->enter($__internal_141827bea6f0a5ec4d8ee20e3f04f37f1c7e254c85881357dd0969ca219888bc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/collection_widget.html.php"));

        $__internal_a13af1a70fd10d104d88141d2780055548b15f6de4ba5577f5977ab99eb9efc5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a13af1a70fd10d104d88141d2780055548b15f6de4ba5577f5977ab99eb9efc5->enter($__internal_a13af1a70fd10d104d88141d2780055548b15f6de4ba5577f5977ab99eb9efc5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/collection_widget.html.php"));

        // line 1
        echo "<?php if (isset(\$prototype)): ?>
    <?php \$attr['data-prototype'] = \$view->escape(\$view['form']->row(\$prototype)) ?>
<?php endif ?>
<?php echo \$view['form']->widget(\$form, array('attr' => \$attr)) ?>
";
        
        $__internal_141827bea6f0a5ec4d8ee20e3f04f37f1c7e254c85881357dd0969ca219888bc->leave($__internal_141827bea6f0a5ec4d8ee20e3f04f37f1c7e254c85881357dd0969ca219888bc_prof);

        
        $__internal_a13af1a70fd10d104d88141d2780055548b15f6de4ba5577f5977ab99eb9efc5->leave($__internal_a13af1a70fd10d104d88141d2780055548b15f6de4ba5577f5977ab99eb9efc5_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/collection_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (isset(\$prototype)): ?>
    <?php \$attr['data-prototype'] = \$view->escape(\$view['form']->row(\$prototype)) ?>
<?php endif ?>
<?php echo \$view['form']->widget(\$form, array('attr' => \$attr)) ?>
", "@Framework/Form/collection_widget.html.php", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\models\\symfony\\db_action\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\collection_widget.html.php");
    }
}
