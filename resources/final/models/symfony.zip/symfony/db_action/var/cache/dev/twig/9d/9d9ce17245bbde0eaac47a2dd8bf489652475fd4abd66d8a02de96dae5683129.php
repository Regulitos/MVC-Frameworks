<?php

/* @Framework/Form/form_errors.html.php */
class __TwigTemplate_3b78a17d11ea126e62d0bdf52d09edb80cc0f65697f4c9950a62baf4715755f3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b357058e5223d52d2a71f5258159e48c8e8078cf4a9d922386c10bc135bde9fb = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b357058e5223d52d2a71f5258159e48c8e8078cf4a9d922386c10bc135bde9fb->enter($__internal_b357058e5223d52d2a71f5258159e48c8e8078cf4a9d922386c10bc135bde9fb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_errors.html.php"));

        $__internal_1c1c255e102c26603fbdc74f72703bd186a3203e398653526473317bf819a3b6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1c1c255e102c26603fbdc74f72703bd186a3203e398653526473317bf819a3b6->enter($__internal_1c1c255e102c26603fbdc74f72703bd186a3203e398653526473317bf819a3b6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_errors.html.php"));

        // line 1
        echo "<?php if (count(\$errors) > 0): ?>
    <ul>
        <?php foreach (\$errors as \$error): ?>
            <li><?php echo \$error->getMessage() ?></li>
        <?php endforeach; ?>
    </ul>
<?php endif ?>
";
        
        $__internal_b357058e5223d52d2a71f5258159e48c8e8078cf4a9d922386c10bc135bde9fb->leave($__internal_b357058e5223d52d2a71f5258159e48c8e8078cf4a9d922386c10bc135bde9fb_prof);

        
        $__internal_1c1c255e102c26603fbdc74f72703bd186a3203e398653526473317bf819a3b6->leave($__internal_1c1c255e102c26603fbdc74f72703bd186a3203e398653526473317bf819a3b6_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_errors.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (count(\$errors) > 0): ?>
    <ul>
        <?php foreach (\$errors as \$error): ?>
            <li><?php echo \$error->getMessage() ?></li>
        <?php endforeach; ?>
    </ul>
<?php endif ?>
", "@Framework/Form/form_errors.html.php", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\models\\symfony\\db_action\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\form_errors.html.php");
    }
}
