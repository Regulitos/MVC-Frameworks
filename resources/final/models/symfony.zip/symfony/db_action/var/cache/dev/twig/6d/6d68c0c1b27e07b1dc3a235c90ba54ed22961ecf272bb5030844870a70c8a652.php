<?php

/* @Framework/Form/integer_widget.html.php */
class __TwigTemplate_c8f4bb651aa9a53a250947c965509d5f20972e5542037524e593ab87d08da757 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_004a623c9f1f0f5a91d9a0802c64c352128b3d0244e275dde4bcf0681d9c791f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_004a623c9f1f0f5a91d9a0802c64c352128b3d0244e275dde4bcf0681d9c791f->enter($__internal_004a623c9f1f0f5a91d9a0802c64c352128b3d0244e275dde4bcf0681d9c791f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/integer_widget.html.php"));

        $__internal_e8980f71921e032b0c32e7718d5f5294018d3d41f1a3dac2385f70b43ab1cc90 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e8980f71921e032b0c32e7718d5f5294018d3d41f1a3dac2385f70b43ab1cc90->enter($__internal_e8980f71921e032b0c32e7718d5f5294018d3d41f1a3dac2385f70b43ab1cc90_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/integer_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'number')) ?>
";
        
        $__internal_004a623c9f1f0f5a91d9a0802c64c352128b3d0244e275dde4bcf0681d9c791f->leave($__internal_004a623c9f1f0f5a91d9a0802c64c352128b3d0244e275dde4bcf0681d9c791f_prof);

        
        $__internal_e8980f71921e032b0c32e7718d5f5294018d3d41f1a3dac2385f70b43ab1cc90->leave($__internal_e8980f71921e032b0c32e7718d5f5294018d3d41f1a3dac2385f70b43ab1cc90_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/integer_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'number')) ?>
", "@Framework/Form/integer_widget.html.php", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\models\\symfony\\db_action\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\integer_widget.html.php");
    }
}
