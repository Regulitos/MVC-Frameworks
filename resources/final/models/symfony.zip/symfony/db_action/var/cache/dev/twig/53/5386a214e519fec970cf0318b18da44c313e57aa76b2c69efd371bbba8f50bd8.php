<?php

/* @Twig/Exception/error.json.twig */
class __TwigTemplate_a8051311ad4758eb4d5b462fca1efa2add9ae20489400a05f18ce663c249a3c8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1fc63e466c4cd981e47cdf4482d23b16fa06dee1f22e7b696a308637c6435556 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1fc63e466c4cd981e47cdf4482d23b16fa06dee1f22e7b696a308637c6435556->enter($__internal_1fc63e466c4cd981e47cdf4482d23b16fa06dee1f22e7b696a308637c6435556_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.json.twig"));

        $__internal_5fe3394ef5d0ef88ac756573a2383b232dc1869c25c229ceefbf079f9d1cb6fc = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5fe3394ef5d0ef88ac756573a2383b232dc1869c25c229ceefbf079f9d1cb6fc->enter($__internal_5fe3394ef5d0ef88ac756573a2383b232dc1869c25c229ceefbf079f9d1cb6fc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.json.twig"));

        // line 1
        echo twig_jsonencode_filter(array("error" => array("code" => ($context["status_code"] ?? $this->getContext($context, "status_code")), "message" => ($context["status_text"] ?? $this->getContext($context, "status_text")))));
        echo "
";
        
        $__internal_1fc63e466c4cd981e47cdf4482d23b16fa06dee1f22e7b696a308637c6435556->leave($__internal_1fc63e466c4cd981e47cdf4482d23b16fa06dee1f22e7b696a308637c6435556_prof);

        
        $__internal_5fe3394ef5d0ef88ac756573a2383b232dc1869c25c229ceefbf079f9d1cb6fc->leave($__internal_5fe3394ef5d0ef88ac756573a2383b232dc1869c25c229ceefbf079f9d1cb6fc_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/error.json.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ { 'error': { 'code': status_code, 'message': status_text } }|json_encode|raw }}
", "@Twig/Exception/error.json.twig", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\models\\symfony\\db_action\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\error.json.twig");
    }
}
