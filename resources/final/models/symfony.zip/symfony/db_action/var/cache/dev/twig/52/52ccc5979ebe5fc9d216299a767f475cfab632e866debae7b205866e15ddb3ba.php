<?php

/* @Framework/Form/radio_widget.html.php */
class __TwigTemplate_de4109765a9af087da3d5e729e2c8a0137a15deeb1f70611aa50efcd0b8649fa extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_66cd0bfe48e586608875a94f90893dce326c30eb7e4249e7345c05f4940450cd = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_66cd0bfe48e586608875a94f90893dce326c30eb7e4249e7345c05f4940450cd->enter($__internal_66cd0bfe48e586608875a94f90893dce326c30eb7e4249e7345c05f4940450cd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/radio_widget.html.php"));

        $__internal_467aa3dff59bf9e216b6bb87de148131edb2aa5f65a56ab1d6b2cbc9682afcec = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_467aa3dff59bf9e216b6bb87de148131edb2aa5f65a56ab1d6b2cbc9682afcec->enter($__internal_467aa3dff59bf9e216b6bb87de148131edb2aa5f65a56ab1d6b2cbc9682afcec_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/radio_widget.html.php"));

        // line 1
        echo "<input type=\"radio\"
    <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
    value=\"<?php echo \$view->escape(\$value) ?>\"
    <?php if (\$checked): ?> checked=\"checked\"<?php endif ?>
/>
";
        
        $__internal_66cd0bfe48e586608875a94f90893dce326c30eb7e4249e7345c05f4940450cd->leave($__internal_66cd0bfe48e586608875a94f90893dce326c30eb7e4249e7345c05f4940450cd_prof);

        
        $__internal_467aa3dff59bf9e216b6bb87de148131edb2aa5f65a56ab1d6b2cbc9682afcec->leave($__internal_467aa3dff59bf9e216b6bb87de148131edb2aa5f65a56ab1d6b2cbc9682afcec_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/radio_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<input type=\"radio\"
    <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
    value=\"<?php echo \$view->escape(\$value) ?>\"
    <?php if (\$checked): ?> checked=\"checked\"<?php endif ?>
/>
", "@Framework/Form/radio_widget.html.php", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\models\\symfony\\db_action\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\radio_widget.html.php");
    }
}
