<?php

/* @Framework/Form/widget_container_attributes.html.php */
class __TwigTemplate_1b6e41835f4598fb72cb484202e6decba551bbdec1fc800033620f1eac72e899 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0164419286caa34a505be013961793b01286e9b51d6f6864a4ee0cae46b11661 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0164419286caa34a505be013961793b01286e9b51d6f6864a4ee0cae46b11661->enter($__internal_0164419286caa34a505be013961793b01286e9b51d6f6864a4ee0cae46b11661_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/widget_container_attributes.html.php"));

        $__internal_c28faedb9f5e7b8d0cd5a5d1d38b11fdfadd9abb5395927ff754d995e831c037 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c28faedb9f5e7b8d0cd5a5d1d38b11fdfadd9abb5395927ff754d995e831c037->enter($__internal_c28faedb9f5e7b8d0cd5a5d1d38b11fdfadd9abb5395927ff754d995e831c037_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/widget_container_attributes.html.php"));

        // line 1
        echo "<?php if (!empty(\$id)): ?>id=\"<?php echo \$view->escape(\$id) ?>\"<?php endif ?>
<?php echo \$attr ? ' '.\$view['form']->block(\$form, 'attributes') : '' ?>
";
        
        $__internal_0164419286caa34a505be013961793b01286e9b51d6f6864a4ee0cae46b11661->leave($__internal_0164419286caa34a505be013961793b01286e9b51d6f6864a4ee0cae46b11661_prof);

        
        $__internal_c28faedb9f5e7b8d0cd5a5d1d38b11fdfadd9abb5395927ff754d995e831c037->leave($__internal_c28faedb9f5e7b8d0cd5a5d1d38b11fdfadd9abb5395927ff754d995e831c037_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/widget_container_attributes.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (!empty(\$id)): ?>id=\"<?php echo \$view->escape(\$id) ?>\"<?php endif ?>
<?php echo \$attr ? ' '.\$view['form']->block(\$form, 'attributes') : '' ?>
", "@Framework/Form/widget_container_attributes.html.php", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\models\\symfony\\db_action\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\widget_container_attributes.html.php");
    }
}
