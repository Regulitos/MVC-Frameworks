<?php

/* @Framework/FormTable/form_row.html.php */
class __TwigTemplate_8f7220a77fb36e6d8fa16d61b380ee42426aa3f3ac024037966e3c0bd6cbbbe6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3e1d03d015aebe0ed7e125c6f1c982e34f7d3b1f831fb097e89703dc54f67a8f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3e1d03d015aebe0ed7e125c6f1c982e34f7d3b1f831fb097e89703dc54f67a8f->enter($__internal_3e1d03d015aebe0ed7e125c6f1c982e34f7d3b1f831fb097e89703dc54f67a8f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/form_row.html.php"));

        $__internal_69ef0d7c8902a15dcf596244ebb8db6f64a048eeb405f7d00b919f900b0570ae = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_69ef0d7c8902a15dcf596244ebb8db6f64a048eeb405f7d00b919f900b0570ae->enter($__internal_69ef0d7c8902a15dcf596244ebb8db6f64a048eeb405f7d00b919f900b0570ae_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/form_row.html.php"));

        // line 1
        echo "<tr>
    <td>
        <?php echo \$view['form']->label(\$form) ?>
    </td>
    <td>
        <?php echo \$view['form']->errors(\$form) ?>
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
";
        
        $__internal_3e1d03d015aebe0ed7e125c6f1c982e34f7d3b1f831fb097e89703dc54f67a8f->leave($__internal_3e1d03d015aebe0ed7e125c6f1c982e34f7d3b1f831fb097e89703dc54f67a8f_prof);

        
        $__internal_69ef0d7c8902a15dcf596244ebb8db6f64a048eeb405f7d00b919f900b0570ae->leave($__internal_69ef0d7c8902a15dcf596244ebb8db6f64a048eeb405f7d00b919f900b0570ae_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/form_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<tr>
    <td>
        <?php echo \$view['form']->label(\$form) ?>
    </td>
    <td>
        <?php echo \$view['form']->errors(\$form) ?>
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
", "@Framework/FormTable/form_row.html.php", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\models\\symfony\\db_action\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\FormTable\\form_row.html.php");
    }
}
