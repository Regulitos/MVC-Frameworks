<?php

/* @Framework/Form/percent_widget.html.php */
class __TwigTemplate_09c9defca89b2fc2b2d87d9354240e301bf227357198eca9ac867e5082d3d5bf extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f6d15493a3cb91cbf9f2d6373de5d2913db737783f46178493b0dff4a9bec6e6 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f6d15493a3cb91cbf9f2d6373de5d2913db737783f46178493b0dff4a9bec6e6->enter($__internal_f6d15493a3cb91cbf9f2d6373de5d2913db737783f46178493b0dff4a9bec6e6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/percent_widget.html.php"));

        $__internal_f5ad8a3b4eae23239139cb534934aef6095b1c9ef1b6133c0aa60b5e116dd410 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f5ad8a3b4eae23239139cb534934aef6095b1c9ef1b6133c0aa60b5e116dd410->enter($__internal_f5ad8a3b4eae23239139cb534934aef6095b1c9ef1b6133c0aa60b5e116dd410_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/percent_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'text')) ?> %
";
        
        $__internal_f6d15493a3cb91cbf9f2d6373de5d2913db737783f46178493b0dff4a9bec6e6->leave($__internal_f6d15493a3cb91cbf9f2d6373de5d2913db737783f46178493b0dff4a9bec6e6_prof);

        
        $__internal_f5ad8a3b4eae23239139cb534934aef6095b1c9ef1b6133c0aa60b5e116dd410->leave($__internal_f5ad8a3b4eae23239139cb534934aef6095b1c9ef1b6133c0aa60b5e116dd410_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/percent_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'text')) ?> %
", "@Framework/Form/percent_widget.html.php", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\models\\symfony\\db_action\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\percent_widget.html.php");
    }
}
