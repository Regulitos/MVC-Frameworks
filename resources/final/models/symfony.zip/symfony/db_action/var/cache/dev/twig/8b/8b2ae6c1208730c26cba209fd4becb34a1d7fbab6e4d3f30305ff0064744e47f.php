<?php

/* @Framework/Form/reset_widget.html.php */
class __TwigTemplate_58940593f855337d9d75604ee90768a3352995d21a47aa79598ce8f367b6c809 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4539107418b8782bec0243364e31eefc0e4eff89aec821b3feee5e15ebfbee13 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4539107418b8782bec0243364e31eefc0e4eff89aec821b3feee5e15ebfbee13->enter($__internal_4539107418b8782bec0243364e31eefc0e4eff89aec821b3feee5e15ebfbee13_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/reset_widget.html.php"));

        $__internal_9dceec78a1732c1d4a85a73a51b09f55ae8bd4c0b73371da3fafd0dbbac4b2d4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9dceec78a1732c1d4a85a73a51b09f55ae8bd4c0b73371da3fafd0dbbac4b2d4->enter($__internal_9dceec78a1732c1d4a85a73a51b09f55ae8bd4c0b73371da3fafd0dbbac4b2d4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/reset_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'button_widget', array('type' => isset(\$type) ? \$type : 'reset')) ?>
";
        
        $__internal_4539107418b8782bec0243364e31eefc0e4eff89aec821b3feee5e15ebfbee13->leave($__internal_4539107418b8782bec0243364e31eefc0e4eff89aec821b3feee5e15ebfbee13_prof);

        
        $__internal_9dceec78a1732c1d4a85a73a51b09f55ae8bd4c0b73371da3fafd0dbbac4b2d4->leave($__internal_9dceec78a1732c1d4a85a73a51b09f55ae8bd4c0b73371da3fafd0dbbac4b2d4_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/reset_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'button_widget', array('type' => isset(\$type) ? \$type : 'reset')) ?>
", "@Framework/Form/reset_widget.html.php", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\models\\symfony\\db_action\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\reset_widget.html.php");
    }
}
