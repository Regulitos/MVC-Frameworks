<?php

/* @Twig/Exception/error.rdf.twig */
class __TwigTemplate_ebf8aedd5c44f694607413aed4441f8014f0fb155687e68b832612ce09917b3e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_408ee90ea770cd9cfa65b947a3ca8b9247bf549e33c4a697a0ad6956988706a9 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_408ee90ea770cd9cfa65b947a3ca8b9247bf549e33c4a697a0ad6956988706a9->enter($__internal_408ee90ea770cd9cfa65b947a3ca8b9247bf549e33c4a697a0ad6956988706a9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.rdf.twig"));

        $__internal_9998483c11d255b19f9d166f4b41195fc00fe9649d4e6d68ce27748da610f9e1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9998483c11d255b19f9d166f4b41195fc00fe9649d4e6d68ce27748da610f9e1->enter($__internal_9998483c11d255b19f9d166f4b41195fc00fe9649d4e6d68ce27748da610f9e1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.rdf.twig"));

        // line 1
        echo twig_include($this->env, $context, "@Twig/Exception/error.xml.twig");
        echo "
";
        
        $__internal_408ee90ea770cd9cfa65b947a3ca8b9247bf549e33c4a697a0ad6956988706a9->leave($__internal_408ee90ea770cd9cfa65b947a3ca8b9247bf549e33c4a697a0ad6956988706a9_prof);

        
        $__internal_9998483c11d255b19f9d166f4b41195fc00fe9649d4e6d68ce27748da610f9e1->leave($__internal_9998483c11d255b19f9d166f4b41195fc00fe9649d4e6d68ce27748da610f9e1_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/error.rdf.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ include('@Twig/Exception/error.xml.twig') }}
", "@Twig/Exception/error.rdf.twig", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\models\\symfony\\db_action\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\error.rdf.twig");
    }
}
