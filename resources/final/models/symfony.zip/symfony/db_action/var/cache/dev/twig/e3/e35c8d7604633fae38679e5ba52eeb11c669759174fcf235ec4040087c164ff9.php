<?php

/* @Framework/Form/hidden_row.html.php */
class __TwigTemplate_3b66698657688110c1d99f82d8dc6c391d6b0a988ea590935983182a60dfccc5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c30f5faf906bb61d13d00aca6399b9576df9f29fbd5d06c02c37d805fbd7244a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c30f5faf906bb61d13d00aca6399b9576df9f29fbd5d06c02c37d805fbd7244a->enter($__internal_c30f5faf906bb61d13d00aca6399b9576df9f29fbd5d06c02c37d805fbd7244a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/hidden_row.html.php"));

        $__internal_41f4d9a3b0171bafd2a304d02ad86db2d27e06b77d7b85cf4eda10435ec59ae2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_41f4d9a3b0171bafd2a304d02ad86db2d27e06b77d7b85cf4eda10435ec59ae2->enter($__internal_41f4d9a3b0171bafd2a304d02ad86db2d27e06b77d7b85cf4eda10435ec59ae2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/hidden_row.html.php"));

        // line 1
        echo "<?php echo \$view['form']->widget(\$form) ?>
";
        
        $__internal_c30f5faf906bb61d13d00aca6399b9576df9f29fbd5d06c02c37d805fbd7244a->leave($__internal_c30f5faf906bb61d13d00aca6399b9576df9f29fbd5d06c02c37d805fbd7244a_prof);

        
        $__internal_41f4d9a3b0171bafd2a304d02ad86db2d27e06b77d7b85cf4eda10435ec59ae2->leave($__internal_41f4d9a3b0171bafd2a304d02ad86db2d27e06b77d7b85cf4eda10435ec59ae2_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/hidden_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->widget(\$form) ?>
", "@Framework/Form/hidden_row.html.php", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\models\\symfony\\db_action\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\hidden_row.html.php");
    }
}
