<?php

/* @Framework/Form/form_row.html.php */
class __TwigTemplate_71f85e5b30b4aa0015add95fdf2e935f230ba8438e56b4bfc4a827ede9341e12 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c194ea02c49f5dd244efd4a45f78e5bcc20c19db40d658d26857fa0ba3ec58de = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c194ea02c49f5dd244efd4a45f78e5bcc20c19db40d658d26857fa0ba3ec58de->enter($__internal_c194ea02c49f5dd244efd4a45f78e5bcc20c19db40d658d26857fa0ba3ec58de_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_row.html.php"));

        $__internal_4612050f0fcdbb27d65ee3d8b94585bba97cdb6b2ff8883c156a990a916f1e68 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4612050f0fcdbb27d65ee3d8b94585bba97cdb6b2ff8883c156a990a916f1e68->enter($__internal_4612050f0fcdbb27d65ee3d8b94585bba97cdb6b2ff8883c156a990a916f1e68_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_row.html.php"));

        // line 1
        echo "<div>
    <?php echo \$view['form']->label(\$form) ?>
    <?php echo \$view['form']->errors(\$form) ?>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
";
        
        $__internal_c194ea02c49f5dd244efd4a45f78e5bcc20c19db40d658d26857fa0ba3ec58de->leave($__internal_c194ea02c49f5dd244efd4a45f78e5bcc20c19db40d658d26857fa0ba3ec58de_prof);

        
        $__internal_4612050f0fcdbb27d65ee3d8b94585bba97cdb6b2ff8883c156a990a916f1e68->leave($__internal_4612050f0fcdbb27d65ee3d8b94585bba97cdb6b2ff8883c156a990a916f1e68_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div>
    <?php echo \$view['form']->label(\$form) ?>
    <?php echo \$view['form']->errors(\$form) ?>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
", "@Framework/Form/form_row.html.php", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\models\\symfony\\db_action\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\form_row.html.php");
    }
}
