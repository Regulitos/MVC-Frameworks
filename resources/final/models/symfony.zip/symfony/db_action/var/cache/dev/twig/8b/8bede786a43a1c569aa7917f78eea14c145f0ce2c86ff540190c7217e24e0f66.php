<?php

/* @Framework/FormTable/form_widget_compound.html.php */
class __TwigTemplate_94b714eb50b1fcf10bfe4f1c0066fe655182602551c87adbb131e5beaa9a8b4f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_630271cee34358ece80bd7fee62c34d12e7b1879e9b3b33b01fea2b7519d0272 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_630271cee34358ece80bd7fee62c34d12e7b1879e9b3b33b01fea2b7519d0272->enter($__internal_630271cee34358ece80bd7fee62c34d12e7b1879e9b3b33b01fea2b7519d0272_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/form_widget_compound.html.php"));

        $__internal_7d846a4b56b3e17fbdf461bf6249e5a66453bf70040601e8e61487e8b767aee8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7d846a4b56b3e17fbdf461bf6249e5a66453bf70040601e8e61487e8b767aee8->enter($__internal_7d846a4b56b3e17fbdf461bf6249e5a66453bf70040601e8e61487e8b767aee8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/form_widget_compound.html.php"));

        // line 1
        echo "<table <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
    <?php if (!\$form->parent && \$errors): ?>
    <tr>
        <td colspan=\"2\">
            <?php echo \$view['form']->errors(\$form) ?>
        </td>
    </tr>
    <?php endif ?>
    <?php echo \$view['form']->block(\$form, 'form_rows') ?>
    <?php echo \$view['form']->rest(\$form) ?>
</table>
";
        
        $__internal_630271cee34358ece80bd7fee62c34d12e7b1879e9b3b33b01fea2b7519d0272->leave($__internal_630271cee34358ece80bd7fee62c34d12e7b1879e9b3b33b01fea2b7519d0272_prof);

        
        $__internal_7d846a4b56b3e17fbdf461bf6249e5a66453bf70040601e8e61487e8b767aee8->leave($__internal_7d846a4b56b3e17fbdf461bf6249e5a66453bf70040601e8e61487e8b767aee8_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/form_widget_compound.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<table <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
    <?php if (!\$form->parent && \$errors): ?>
    <tr>
        <td colspan=\"2\">
            <?php echo \$view['form']->errors(\$form) ?>
        </td>
    </tr>
    <?php endif ?>
    <?php echo \$view['form']->block(\$form, 'form_rows') ?>
    <?php echo \$view['form']->rest(\$form) ?>
</table>
", "@Framework/FormTable/form_widget_compound.html.php", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\models\\symfony\\db_action\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\FormTable\\form_widget_compound.html.php");
    }
}
