<?php

/* TwigBundle:Exception:error.xml.twig */
class __TwigTemplate_28a039a80e0ef40c60fda3b17e748f036240e77c7f4aa18a9845a028b51c9a29 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e44dcd368ea509ae649e2e20fac1a743fe2630a3d96e1dfd0058675b5fb48e20 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e44dcd368ea509ae649e2e20fac1a743fe2630a3d96e1dfd0058675b5fb48e20->enter($__internal_e44dcd368ea509ae649e2e20fac1a743fe2630a3d96e1dfd0058675b5fb48e20_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.xml.twig"));

        $__internal_40d4eefd0859ea0a8c839f21a7299fb5bf170362fcf65be2f4c2d493ea1843da = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_40d4eefd0859ea0a8c839f21a7299fb5bf170362fcf65be2f4c2d493ea1843da->enter($__internal_40d4eefd0859ea0a8c839f21a7299fb5bf170362fcf65be2f4c2d493ea1843da_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.xml.twig"));

        // line 1
        echo "<?xml version=\"1.0\" encoding=\"";
        echo twig_escape_filter($this->env, $this->env->getCharset(), "html", null, true);
        echo "\" ?>

<error code=\"";
        // line 3
        echo twig_escape_filter($this->env, ($context["status_code"] ?? $this->getContext($context, "status_code")), "html", null, true);
        echo "\" message=\"";
        echo twig_escape_filter($this->env, ($context["status_text"] ?? $this->getContext($context, "status_text")), "html", null, true);
        echo "\" />
";
        
        $__internal_e44dcd368ea509ae649e2e20fac1a743fe2630a3d96e1dfd0058675b5fb48e20->leave($__internal_e44dcd368ea509ae649e2e20fac1a743fe2630a3d96e1dfd0058675b5fb48e20_prof);

        
        $__internal_40d4eefd0859ea0a8c839f21a7299fb5bf170362fcf65be2f4c2d493ea1843da->leave($__internal_40d4eefd0859ea0a8c839f21a7299fb5bf170362fcf65be2f4c2d493ea1843da_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.xml.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  31 => 3,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?xml version=\"1.0\" encoding=\"{{ _charset }}\" ?>

<error code=\"{{ status_code }}\" message=\"{{ status_text }}\" />
", "TwigBundle:Exception:error.xml.twig", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\models\\symfony\\db_action\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle/Resources/views/Exception/error.xml.twig");
    }
}
