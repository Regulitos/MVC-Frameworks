<?php

/* TwigBundle:Exception:error.txt.twig */
class __TwigTemplate_68b5d63f7afffb2b243217ce96d745bf0a563bb8d2e5b6925445dc16766b395a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_09f60a77e51fd0ce00f39d4a86a2b40011bae41f46951f476acd58c7740b1dfa = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_09f60a77e51fd0ce00f39d4a86a2b40011bae41f46951f476acd58c7740b1dfa->enter($__internal_09f60a77e51fd0ce00f39d4a86a2b40011bae41f46951f476acd58c7740b1dfa_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.txt.twig"));

        $__internal_7273dc9af0170c3547dadd4beac89c18213dd2dc36a699cdca4ed64c3302e74a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7273dc9af0170c3547dadd4beac89c18213dd2dc36a699cdca4ed64c3302e74a->enter($__internal_7273dc9af0170c3547dadd4beac89c18213dd2dc36a699cdca4ed64c3302e74a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.txt.twig"));

        // line 1
        echo "Oops! An Error Occurred
=======================

The server returned a \"";
        // line 4
        echo ($context["status_code"] ?? $this->getContext($context, "status_code"));
        echo " ";
        echo ($context["status_text"] ?? $this->getContext($context, "status_text"));
        echo "\".

Something is broken. Please let us know what you were doing when this error occurred.
We will fix it as soon as possible. Sorry for any inconvenience caused.
";
        
        $__internal_09f60a77e51fd0ce00f39d4a86a2b40011bae41f46951f476acd58c7740b1dfa->leave($__internal_09f60a77e51fd0ce00f39d4a86a2b40011bae41f46951f476acd58c7740b1dfa_prof);

        
        $__internal_7273dc9af0170c3547dadd4beac89c18213dd2dc36a699cdca4ed64c3302e74a->leave($__internal_7273dc9af0170c3547dadd4beac89c18213dd2dc36a699cdca4ed64c3302e74a_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.txt.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  30 => 4,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("Oops! An Error Occurred
=======================

The server returned a \"{{ status_code }} {{ status_text }}\".

Something is broken. Please let us know what you were doing when this error occurred.
We will fix it as soon as possible. Sorry for any inconvenience caused.
", "TwigBundle:Exception:error.txt.twig", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\models\\symfony\\db_action\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle/Resources/views/Exception/error.txt.twig");
    }
}
