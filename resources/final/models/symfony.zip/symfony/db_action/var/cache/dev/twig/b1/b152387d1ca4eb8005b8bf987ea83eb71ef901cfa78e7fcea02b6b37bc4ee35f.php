<?php

/* @WebProfiler/Profiler/toolbar_redirect.html.twig */
class __TwigTemplate_b3bc6c61daa78099703cd636bf909b5a35b1e5a72efb9a36c4125b567accfaa0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@Twig/layout.html.twig", "@WebProfiler/Profiler/toolbar_redirect.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@Twig/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0a0d1da28a123a4a32c0bee8f086fd06db1cf3c78da61d7cbe28d9cccc488be7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0a0d1da28a123a4a32c0bee8f086fd06db1cf3c78da61d7cbe28d9cccc488be7->enter($__internal_0a0d1da28a123a4a32c0bee8f086fd06db1cf3c78da61d7cbe28d9cccc488be7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/toolbar_redirect.html.twig"));

        $__internal_a7705aaaff7c5f9d7d7175934bb274f0d919dd0163aa36e960a06abaad88b4e4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a7705aaaff7c5f9d7d7175934bb274f0d919dd0163aa36e960a06abaad88b4e4->enter($__internal_a7705aaaff7c5f9d7d7175934bb274f0d919dd0163aa36e960a06abaad88b4e4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/toolbar_redirect.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_0a0d1da28a123a4a32c0bee8f086fd06db1cf3c78da61d7cbe28d9cccc488be7->leave($__internal_0a0d1da28a123a4a32c0bee8f086fd06db1cf3c78da61d7cbe28d9cccc488be7_prof);

        
        $__internal_a7705aaaff7c5f9d7d7175934bb274f0d919dd0163aa36e960a06abaad88b4e4->leave($__internal_a7705aaaff7c5f9d7d7175934bb274f0d919dd0163aa36e960a06abaad88b4e4_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_008a2d72456d5fb9bf357c666ddb4a34ad8922eeeea166baded92239f244da48 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_008a2d72456d5fb9bf357c666ddb4a34ad8922eeeea166baded92239f244da48->enter($__internal_008a2d72456d5fb9bf357c666ddb4a34ad8922eeeea166baded92239f244da48_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_dd2bc0991340b452e0ea86b20bb52db9ee2650b1a387c06aa754dcb34f1da113 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_dd2bc0991340b452e0ea86b20bb52db9ee2650b1a387c06aa754dcb34f1da113->enter($__internal_dd2bc0991340b452e0ea86b20bb52db9ee2650b1a387c06aa754dcb34f1da113_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Redirection Intercepted";
        
        $__internal_dd2bc0991340b452e0ea86b20bb52db9ee2650b1a387c06aa754dcb34f1da113->leave($__internal_dd2bc0991340b452e0ea86b20bb52db9ee2650b1a387c06aa754dcb34f1da113_prof);

        
        $__internal_008a2d72456d5fb9bf357c666ddb4a34ad8922eeeea166baded92239f244da48->leave($__internal_008a2d72456d5fb9bf357c666ddb4a34ad8922eeeea166baded92239f244da48_prof);

    }

    // line 5
    public function block_body($context, array $blocks = array())
    {
        $__internal_78ccd655627cbc43a34269892c1aee1b2c98e21c3d210c881e55e6381f5fd1c1 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_78ccd655627cbc43a34269892c1aee1b2c98e21c3d210c881e55e6381f5fd1c1->enter($__internal_78ccd655627cbc43a34269892c1aee1b2c98e21c3d210c881e55e6381f5fd1c1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_974259c430731ea6a672d6ceccee7248c4b5a556e16b6fa0c63ac9af2f45700c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_974259c430731ea6a672d6ceccee7248c4b5a556e16b6fa0c63ac9af2f45700c->enter($__internal_974259c430731ea6a672d6ceccee7248c4b5a556e16b6fa0c63ac9af2f45700c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "    <div class=\"sf-reset\">
        <div class=\"block-exception\">
            <h1>This request redirects to <a href=\"";
        // line 8
        echo twig_escape_filter($this->env, ($context["location"] ?? $this->getContext($context, "location")), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, ($context["location"] ?? $this->getContext($context, "location")), "html", null, true);
        echo "</a>.</h1>

            <p>
                <small>
                    The redirect was intercepted by the web debug toolbar to help debugging.
                    For more information, see the \"intercept-redirects\" option of the Profiler.
                </small>
            </p>
        </div>
    </div>
";
        
        $__internal_974259c430731ea6a672d6ceccee7248c4b5a556e16b6fa0c63ac9af2f45700c->leave($__internal_974259c430731ea6a672d6ceccee7248c4b5a556e16b6fa0c63ac9af2f45700c_prof);

        
        $__internal_78ccd655627cbc43a34269892c1aee1b2c98e21c3d210c881e55e6381f5fd1c1->leave($__internal_78ccd655627cbc43a34269892c1aee1b2c98e21c3d210c881e55e6381f5fd1c1_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Profiler/toolbar_redirect.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  72 => 8,  68 => 6,  59 => 5,  41 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@Twig/layout.html.twig' %}

{% block title 'Redirection Intercepted' %}

{% block body %}
    <div class=\"sf-reset\">
        <div class=\"block-exception\">
            <h1>This request redirects to <a href=\"{{ location }}\">{{ location }}</a>.</h1>

            <p>
                <small>
                    The redirect was intercepted by the web debug toolbar to help debugging.
                    For more information, see the \"intercept-redirects\" option of the Profiler.
                </small>
            </p>
        </div>
    </div>
{% endblock %}
", "@WebProfiler/Profiler/toolbar_redirect.html.twig", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\models\\symfony\\db_action\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Profiler\\toolbar_redirect.html.twig");
    }
}
