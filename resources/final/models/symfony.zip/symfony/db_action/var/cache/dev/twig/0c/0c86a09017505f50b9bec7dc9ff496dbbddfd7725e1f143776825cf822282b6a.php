<?php

/* TwigBundle:Exception:exception.js.twig */
class __TwigTemplate_b8abb0eb73b136d8efa53cdaca99e6dcdacfbf93297656837016661dd03ef842 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8e927d71facdf9c10255d03be77aede93ec9a92c83983071f506cd422aedb095 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8e927d71facdf9c10255d03be77aede93ec9a92c83983071f506cd422aedb095->enter($__internal_8e927d71facdf9c10255d03be77aede93ec9a92c83983071f506cd422aedb095_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.js.twig"));

        $__internal_f2513d5a562b600aa9f9d34f3a7c540652c5c01aa8110b610143d59aa3a281b9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f2513d5a562b600aa9f9d34f3a7c540652c5c01aa8110b610143d59aa3a281b9->enter($__internal_f2513d5a562b600aa9f9d34f3a7c540652c5c01aa8110b610143d59aa3a281b9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.js.twig"));

        // line 1
        echo "/*
";
        // line 2
        echo twig_include($this->env, $context, "@Twig/Exception/exception.txt.twig", array("exception" => ($context["exception"] ?? $this->getContext($context, "exception"))));
        echo "
*/
";
        
        $__internal_8e927d71facdf9c10255d03be77aede93ec9a92c83983071f506cd422aedb095->leave($__internal_8e927d71facdf9c10255d03be77aede93ec9a92c83983071f506cd422aedb095_prof);

        
        $__internal_f2513d5a562b600aa9f9d34f3a7c540652c5c01aa8110b610143d59aa3a281b9->leave($__internal_f2513d5a562b600aa9f9d34f3a7c540652c5c01aa8110b610143d59aa3a281b9_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.js.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  28 => 2,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("/*
{{ include('@Twig/Exception/exception.txt.twig', { exception: exception }) }}
*/
", "TwigBundle:Exception:exception.js.twig", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\models\\symfony\\db_action\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle/Resources/views/Exception/exception.js.twig");
    }
}
