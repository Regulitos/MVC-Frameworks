<?php

/* base.html.twig */
class __TwigTemplate_cf276ec5c8aeca8007e33ee25c4885ab60c5782e044b68c641db76c6879257f8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9d8a2c47bcdb1274914c06d2243a864927cdfe080d1d366c6ad3f0b6256d90bc = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9d8a2c47bcdb1274914c06d2243a864927cdfe080d1d366c6ad3f0b6256d90bc->enter($__internal_9d8a2c47bcdb1274914c06d2243a864927cdfe080d1d366c6ad3f0b6256d90bc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        $__internal_6c0e8a8aacaed5dc46b6f77058997e423a8e686f882c3adb2f6cb6db1a346183 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6c0e8a8aacaed5dc46b6f77058997e423a8e686f882c3adb2f6cb6db1a346183->enter($__internal_6c0e8a8aacaed5dc46b6f77058997e423a8e686f882c3adb2f6cb6db1a346183_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>";
        // line 5
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        ";
        // line 6
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 7
        echo "        <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />
    </head>
    <body>
        ";
        // line 10
        $this->displayBlock('body', $context, $blocks);
        // line 11
        echo "        ";
        $this->displayBlock('javascripts', $context, $blocks);
        // line 12
        echo "    </body>
</html>
";
        
        $__internal_9d8a2c47bcdb1274914c06d2243a864927cdfe080d1d366c6ad3f0b6256d90bc->leave($__internal_9d8a2c47bcdb1274914c06d2243a864927cdfe080d1d366c6ad3f0b6256d90bc_prof);

        
        $__internal_6c0e8a8aacaed5dc46b6f77058997e423a8e686f882c3adb2f6cb6db1a346183->leave($__internal_6c0e8a8aacaed5dc46b6f77058997e423a8e686f882c3adb2f6cb6db1a346183_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_80ae535007fbb944ead0b5006555475181a3afb68ad18a8d5fae4c63a0371bd2 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_80ae535007fbb944ead0b5006555475181a3afb68ad18a8d5fae4c63a0371bd2->enter($__internal_80ae535007fbb944ead0b5006555475181a3afb68ad18a8d5fae4c63a0371bd2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_333a8bd616260af12fbe09183dc6e8c4762b21abe80cdb67d03086a40da79b24 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_333a8bd616260af12fbe09183dc6e8c4762b21abe80cdb67d03086a40da79b24->enter($__internal_333a8bd616260af12fbe09183dc6e8c4762b21abe80cdb67d03086a40da79b24_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Welcome!";
        
        $__internal_333a8bd616260af12fbe09183dc6e8c4762b21abe80cdb67d03086a40da79b24->leave($__internal_333a8bd616260af12fbe09183dc6e8c4762b21abe80cdb67d03086a40da79b24_prof);

        
        $__internal_80ae535007fbb944ead0b5006555475181a3afb68ad18a8d5fae4c63a0371bd2->leave($__internal_80ae535007fbb944ead0b5006555475181a3afb68ad18a8d5fae4c63a0371bd2_prof);

    }

    // line 6
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_b12924b9b9905c1442ed45cc7d33bec9b7bf6cae3e54a4c1389a2cce59f9a5cc = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b12924b9b9905c1442ed45cc7d33bec9b7bf6cae3e54a4c1389a2cce59f9a5cc->enter($__internal_b12924b9b9905c1442ed45cc7d33bec9b7bf6cae3e54a4c1389a2cce59f9a5cc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_0fdd6c7ab6406e332da85d78abd46ad3ce3513c55aaf3eccd110936744df6954 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0fdd6c7ab6406e332da85d78abd46ad3ce3513c55aaf3eccd110936744df6954->enter($__internal_0fdd6c7ab6406e332da85d78abd46ad3ce3513c55aaf3eccd110936744df6954_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_0fdd6c7ab6406e332da85d78abd46ad3ce3513c55aaf3eccd110936744df6954->leave($__internal_0fdd6c7ab6406e332da85d78abd46ad3ce3513c55aaf3eccd110936744df6954_prof);

        
        $__internal_b12924b9b9905c1442ed45cc7d33bec9b7bf6cae3e54a4c1389a2cce59f9a5cc->leave($__internal_b12924b9b9905c1442ed45cc7d33bec9b7bf6cae3e54a4c1389a2cce59f9a5cc_prof);

    }

    // line 10
    public function block_body($context, array $blocks = array())
    {
        $__internal_d699e14a603a95fdb214221db3620df9387902c5fcd6b4c84f7054f6211447e9 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d699e14a603a95fdb214221db3620df9387902c5fcd6b4c84f7054f6211447e9->enter($__internal_d699e14a603a95fdb214221db3620df9387902c5fcd6b4c84f7054f6211447e9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_dd74bd9295342953dd116b9c0a3a165f4b841e52a9e896ef197f4292b6c0911f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_dd74bd9295342953dd116b9c0a3a165f4b841e52a9e896ef197f4292b6c0911f->enter($__internal_dd74bd9295342953dd116b9c0a3a165f4b841e52a9e896ef197f4292b6c0911f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_dd74bd9295342953dd116b9c0a3a165f4b841e52a9e896ef197f4292b6c0911f->leave($__internal_dd74bd9295342953dd116b9c0a3a165f4b841e52a9e896ef197f4292b6c0911f_prof);

        
        $__internal_d699e14a603a95fdb214221db3620df9387902c5fcd6b4c84f7054f6211447e9->leave($__internal_d699e14a603a95fdb214221db3620df9387902c5fcd6b4c84f7054f6211447e9_prof);

    }

    // line 11
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_1502d44529407be4808657ec438d641dc0f4d653ddf3ad676e9a9747754ba27a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1502d44529407be4808657ec438d641dc0f4d653ddf3ad676e9a9747754ba27a->enter($__internal_1502d44529407be4808657ec438d641dc0f4d653ddf3ad676e9a9747754ba27a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_89a3dbee5c2cb680c44c865dda969fd40caa975d0a9c60be6a4f2e7974532b92 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_89a3dbee5c2cb680c44c865dda969fd40caa975d0a9c60be6a4f2e7974532b92->enter($__internal_89a3dbee5c2cb680c44c865dda969fd40caa975d0a9c60be6a4f2e7974532b92_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_89a3dbee5c2cb680c44c865dda969fd40caa975d0a9c60be6a4f2e7974532b92->leave($__internal_89a3dbee5c2cb680c44c865dda969fd40caa975d0a9c60be6a4f2e7974532b92_prof);

        
        $__internal_1502d44529407be4808657ec438d641dc0f4d653ddf3ad676e9a9747754ba27a->leave($__internal_1502d44529407be4808657ec438d641dc0f4d653ddf3ad676e9a9747754ba27a_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  117 => 11,  100 => 10,  83 => 6,  65 => 5,  53 => 12,  50 => 11,  48 => 10,  41 => 7,  39 => 6,  35 => 5,  29 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>{% block title %}Welcome!{% endblock %}</title>
        {% block stylesheets %}{% endblock %}
        <link rel=\"icon\" type=\"image/x-icon\" href=\"{{ asset('favicon.ico') }}\" />
    </head>
    <body>
        {% block body %}{% endblock %}
        {% block javascripts %}{% endblock %}
    </body>
</html>
", "base.html.twig", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\models\\symfony\\db_action\\app\\Resources\\views\\base.html.twig");
    }
}
