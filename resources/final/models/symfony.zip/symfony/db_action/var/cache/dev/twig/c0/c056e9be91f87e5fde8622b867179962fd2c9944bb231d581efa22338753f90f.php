<?php

/* TwigBundle:Exception:error.rdf.twig */
class __TwigTemplate_26edb4916903690e4fa175d2997e52784c4ac4cddc89b07f3700cfc3850459e3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_60f1d8e944e456ba303c66ec046f42a84be14965132ef8b8ef9e4f47da81df8a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_60f1d8e944e456ba303c66ec046f42a84be14965132ef8b8ef9e4f47da81df8a->enter($__internal_60f1d8e944e456ba303c66ec046f42a84be14965132ef8b8ef9e4f47da81df8a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.rdf.twig"));

        $__internal_f6ae37f6f2847c7fd21561308894342a8ced5ea0da91dab7730cd4094a8394be = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f6ae37f6f2847c7fd21561308894342a8ced5ea0da91dab7730cd4094a8394be->enter($__internal_f6ae37f6f2847c7fd21561308894342a8ced5ea0da91dab7730cd4094a8394be_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.rdf.twig"));

        // line 1
        echo twig_include($this->env, $context, "@Twig/Exception/error.xml.twig");
        echo "
";
        
        $__internal_60f1d8e944e456ba303c66ec046f42a84be14965132ef8b8ef9e4f47da81df8a->leave($__internal_60f1d8e944e456ba303c66ec046f42a84be14965132ef8b8ef9e4f47da81df8a_prof);

        
        $__internal_f6ae37f6f2847c7fd21561308894342a8ced5ea0da91dab7730cd4094a8394be->leave($__internal_f6ae37f6f2847c7fd21561308894342a8ced5ea0da91dab7730cd4094a8394be_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.rdf.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ include('@Twig/Exception/error.xml.twig') }}
", "TwigBundle:Exception:error.rdf.twig", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\models\\symfony\\db_action\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle/Resources/views/Exception/error.rdf.twig");
    }
}
