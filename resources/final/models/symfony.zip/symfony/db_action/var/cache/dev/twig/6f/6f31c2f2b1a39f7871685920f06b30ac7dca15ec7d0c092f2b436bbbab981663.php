<?php

/* @Framework/Form/form_widget.html.php */
class __TwigTemplate_d572ad79cf07edcbf04f8519722e71bda34fbd095c29299224d58fd7eb57d90d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_092c2faec83697cd31bb98ef515228d2e259e3863c9dc8eba1d5c5e61f02830b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_092c2faec83697cd31bb98ef515228d2e259e3863c9dc8eba1d5c5e61f02830b->enter($__internal_092c2faec83697cd31bb98ef515228d2e259e3863c9dc8eba1d5c5e61f02830b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget.html.php"));

        $__internal_b37a98c10fee5b951e084f9778359eef2269295d020b6aa9687d25b9dc1dbb8f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b37a98c10fee5b951e084f9778359eef2269295d020b6aa9687d25b9dc1dbb8f->enter($__internal_b37a98c10fee5b951e084f9778359eef2269295d020b6aa9687d25b9dc1dbb8f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget.html.php"));

        // line 1
        echo "<?php if (\$compound): ?>
<?php echo \$view['form']->block(\$form, 'form_widget_compound')?>
<?php else: ?>
<?php echo \$view['form']->block(\$form, 'form_widget_simple')?>
<?php endif ?>
";
        
        $__internal_092c2faec83697cd31bb98ef515228d2e259e3863c9dc8eba1d5c5e61f02830b->leave($__internal_092c2faec83697cd31bb98ef515228d2e259e3863c9dc8eba1d5c5e61f02830b_prof);

        
        $__internal_b37a98c10fee5b951e084f9778359eef2269295d020b6aa9687d25b9dc1dbb8f->leave($__internal_b37a98c10fee5b951e084f9778359eef2269295d020b6aa9687d25b9dc1dbb8f_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (\$compound): ?>
<?php echo \$view['form']->block(\$form, 'form_widget_compound')?>
<?php else: ?>
<?php echo \$view['form']->block(\$form, 'form_widget_simple')?>
<?php endif ?>
", "@Framework/Form/form_widget.html.php", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\models\\symfony\\db_action\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\form_widget.html.php");
    }
}
