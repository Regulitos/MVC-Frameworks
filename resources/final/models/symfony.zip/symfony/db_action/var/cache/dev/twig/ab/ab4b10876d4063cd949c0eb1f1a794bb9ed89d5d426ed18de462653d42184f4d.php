<?php

/* @Twig/Exception/exception.css.twig */
class __TwigTemplate_8c787de82f553afc7f06ec5bf16f923d919d2bb78f51f178c51dd2668ed08e18 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f8dda811c63dc1cd91105711b13473e00e9bb402fd73ccf1a73b7df49c25014b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f8dda811c63dc1cd91105711b13473e00e9bb402fd73ccf1a73b7df49c25014b->enter($__internal_f8dda811c63dc1cd91105711b13473e00e9bb402fd73ccf1a73b7df49c25014b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.css.twig"));

        $__internal_f0cb0f3c68797cfe5ebcf36888bd80c283b266d05517db93a117be3097bac59a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f0cb0f3c68797cfe5ebcf36888bd80c283b266d05517db93a117be3097bac59a->enter($__internal_f0cb0f3c68797cfe5ebcf36888bd80c283b266d05517db93a117be3097bac59a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.css.twig"));

        // line 1
        echo "/*
";
        // line 2
        echo twig_include($this->env, $context, "@Twig/Exception/exception.txt.twig", array("exception" => ($context["exception"] ?? $this->getContext($context, "exception"))));
        echo "
*/
";
        
        $__internal_f8dda811c63dc1cd91105711b13473e00e9bb402fd73ccf1a73b7df49c25014b->leave($__internal_f8dda811c63dc1cd91105711b13473e00e9bb402fd73ccf1a73b7df49c25014b_prof);

        
        $__internal_f0cb0f3c68797cfe5ebcf36888bd80c283b266d05517db93a117be3097bac59a->leave($__internal_f0cb0f3c68797cfe5ebcf36888bd80c283b266d05517db93a117be3097bac59a_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/exception.css.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  28 => 2,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("/*
{{ include('@Twig/Exception/exception.txt.twig', { exception: exception }) }}
*/
", "@Twig/Exception/exception.css.twig", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\models\\symfony\\db_action\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\exception.css.twig");
    }
}
