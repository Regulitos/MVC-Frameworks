<?php

/* @Framework/Form/form_enctype.html.php */
class __TwigTemplate_c54de38a96336fc8c264fa5246cffcb1f77d7fbae541c8075c040282d209c2fd extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_617d9d0fac1424752a1fb879c10bb148d9a41cb7703e38fe20e9e4d7e18850d4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_617d9d0fac1424752a1fb879c10bb148d9a41cb7703e38fe20e9e4d7e18850d4->enter($__internal_617d9d0fac1424752a1fb879c10bb148d9a41cb7703e38fe20e9e4d7e18850d4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_enctype.html.php"));

        $__internal_f28d61236a6f81586d2ffb2398effb9fb4a9795e0487603ad982e4e0af649cab = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f28d61236a6f81586d2ffb2398effb9fb4a9795e0487603ad982e4e0af649cab->enter($__internal_f28d61236a6f81586d2ffb2398effb9fb4a9795e0487603ad982e4e0af649cab_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_enctype.html.php"));

        // line 1
        echo "<?php if (\$form->vars['multipart']): ?>enctype=\"multipart/form-data\"<?php endif ?>
";
        
        $__internal_617d9d0fac1424752a1fb879c10bb148d9a41cb7703e38fe20e9e4d7e18850d4->leave($__internal_617d9d0fac1424752a1fb879c10bb148d9a41cb7703e38fe20e9e4d7e18850d4_prof);

        
        $__internal_f28d61236a6f81586d2ffb2398effb9fb4a9795e0487603ad982e4e0af649cab->leave($__internal_f28d61236a6f81586d2ffb2398effb9fb4a9795e0487603ad982e4e0af649cab_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_enctype.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (\$form->vars['multipart']): ?>enctype=\"multipart/form-data\"<?php endif ?>
", "@Framework/Form/form_enctype.html.php", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\models\\symfony\\db_action\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\form_enctype.html.php");
    }
}
