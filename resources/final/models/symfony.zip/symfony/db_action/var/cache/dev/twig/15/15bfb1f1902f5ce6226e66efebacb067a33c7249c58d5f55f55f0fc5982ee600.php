<?php

/* @WebProfiler/Profiler/ajax_layout.html.twig */
class __TwigTemplate_e654a57c1c1190cdb6754f7fe92c6fa0261a0159ec19cdd8b92747da0cd431a8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8fa9269a493e410a04bc145c2aec3c4da59b264e09b0a67ce7e0d8e6a2a5eb25 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8fa9269a493e410a04bc145c2aec3c4da59b264e09b0a67ce7e0d8e6a2a5eb25->enter($__internal_8fa9269a493e410a04bc145c2aec3c4da59b264e09b0a67ce7e0d8e6a2a5eb25_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/ajax_layout.html.twig"));

        $__internal_f4a6b979980524f8837c6ecf85f237e29aec97ad6ce6cfa25c6b37d6187caffa = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f4a6b979980524f8837c6ecf85f237e29aec97ad6ce6cfa25c6b37d6187caffa->enter($__internal_f4a6b979980524f8837c6ecf85f237e29aec97ad6ce6cfa25c6b37d6187caffa_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/ajax_layout.html.twig"));

        // line 1
        $this->displayBlock('panel', $context, $blocks);
        
        $__internal_8fa9269a493e410a04bc145c2aec3c4da59b264e09b0a67ce7e0d8e6a2a5eb25->leave($__internal_8fa9269a493e410a04bc145c2aec3c4da59b264e09b0a67ce7e0d8e6a2a5eb25_prof);

        
        $__internal_f4a6b979980524f8837c6ecf85f237e29aec97ad6ce6cfa25c6b37d6187caffa->leave($__internal_f4a6b979980524f8837c6ecf85f237e29aec97ad6ce6cfa25c6b37d6187caffa_prof);

    }

    public function block_panel($context, array $blocks = array())
    {
        $__internal_71c6e7a6b2db99b935ed96993952d00b1e09829bb4c71197895a02025850eb4c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_71c6e7a6b2db99b935ed96993952d00b1e09829bb4c71197895a02025850eb4c->enter($__internal_71c6e7a6b2db99b935ed96993952d00b1e09829bb4c71197895a02025850eb4c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_451ec2915301e9efb5b0af8eeeeeb4f46d3379967b4d976535db82714e0ca2a5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_451ec2915301e9efb5b0af8eeeeeb4f46d3379967b4d976535db82714e0ca2a5->enter($__internal_451ec2915301e9efb5b0af8eeeeeb4f46d3379967b4d976535db82714e0ca2a5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        echo "";
        
        $__internal_451ec2915301e9efb5b0af8eeeeeb4f46d3379967b4d976535db82714e0ca2a5->leave($__internal_451ec2915301e9efb5b0af8eeeeeb4f46d3379967b4d976535db82714e0ca2a5_prof);

        
        $__internal_71c6e7a6b2db99b935ed96993952d00b1e09829bb4c71197895a02025850eb4c->leave($__internal_71c6e7a6b2db99b935ed96993952d00b1e09829bb4c71197895a02025850eb4c_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Profiler/ajax_layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  26 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% block panel '' %}
", "@WebProfiler/Profiler/ajax_layout.html.twig", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\models\\symfony\\db_action\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Profiler\\ajax_layout.html.twig");
    }
}
