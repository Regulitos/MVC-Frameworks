<?php

/* WebProfilerBundle:Collector:exception.html.twig */
class __TwigTemplate_d71a5f5e94f2b0257425a9e1434dc911e1d46aff551a473bfd59a328eba8fd64 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "WebProfilerBundle:Collector:exception.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_41486f225851b77dd7a593a2530625a030aad873a3805b4f0689673b7a013aa9 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_41486f225851b77dd7a593a2530625a030aad873a3805b4f0689673b7a013aa9->enter($__internal_41486f225851b77dd7a593a2530625a030aad873a3805b4f0689673b7a013aa9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Collector:exception.html.twig"));

        $__internal_7c314c08c83a889448816600f45c8b9592354c63139458d02d5af15492ecfb02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7c314c08c83a889448816600f45c8b9592354c63139458d02d5af15492ecfb02->enter($__internal_7c314c08c83a889448816600f45c8b9592354c63139458d02d5af15492ecfb02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Collector:exception.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_41486f225851b77dd7a593a2530625a030aad873a3805b4f0689673b7a013aa9->leave($__internal_41486f225851b77dd7a593a2530625a030aad873a3805b4f0689673b7a013aa9_prof);

        
        $__internal_7c314c08c83a889448816600f45c8b9592354c63139458d02d5af15492ecfb02->leave($__internal_7c314c08c83a889448816600f45c8b9592354c63139458d02d5af15492ecfb02_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_3ea1c0fc2a76756fc2adc19f6a185fee55111614881d850f7196759f602d6a92 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3ea1c0fc2a76756fc2adc19f6a185fee55111614881d850f7196759f602d6a92->enter($__internal_3ea1c0fc2a76756fc2adc19f6a185fee55111614881d850f7196759f602d6a92_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        $__internal_838caebe458a7f443b6768e17cd5ceffa17f35c2cb3382827da943624e9dec0c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_838caebe458a7f443b6768e17cd5ceffa17f35c2cb3382827da943624e9dec0c->enter($__internal_838caebe458a7f443b6768e17cd5ceffa17f35c2cb3382827da943624e9dec0c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    ";
        if ($this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) {
            // line 5
            echo "        <style>
            ";
            // line 6
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_exception_css", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
            echo "
        </style>
    ";
        }
        // line 9
        echo "    ";
        $this->displayParentBlock("head", $context, $blocks);
        echo "
";
        
        $__internal_838caebe458a7f443b6768e17cd5ceffa17f35c2cb3382827da943624e9dec0c->leave($__internal_838caebe458a7f443b6768e17cd5ceffa17f35c2cb3382827da943624e9dec0c_prof);

        
        $__internal_3ea1c0fc2a76756fc2adc19f6a185fee55111614881d850f7196759f602d6a92->leave($__internal_3ea1c0fc2a76756fc2adc19f6a185fee55111614881d850f7196759f602d6a92_prof);

    }

    // line 12
    public function block_menu($context, array $blocks = array())
    {
        $__internal_1a8a5cd9a632cebc069583fa273b39604faeb32f053649c4cf49c97beeb4cd39 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1a8a5cd9a632cebc069583fa273b39604faeb32f053649c4cf49c97beeb4cd39->enter($__internal_1a8a5cd9a632cebc069583fa273b39604faeb32f053649c4cf49c97beeb4cd39_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_31d369abfa05c6bf9f60fdbc8b31c9cf460b83c3c476735d66cef7c6f7a7644b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_31d369abfa05c6bf9f60fdbc8b31c9cf460b83c3c476735d66cef7c6f7a7644b->enter($__internal_31d369abfa05c6bf9f60fdbc8b31c9cf460b83c3c476735d66cef7c6f7a7644b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 13
        echo "    <span class=\"label ";
        echo (($this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) ? ("label-status-error") : ("disabled"));
        echo "\">
        <span class=\"icon\">";
        // line 14
        echo twig_include($this->env, $context, "@WebProfiler/Icon/exception.svg");
        echo "</span>
        <strong>Exception</strong>
        ";
        // line 16
        if ($this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) {
            // line 17
            echo "            <span class=\"count\">
                <span>1</span>
            </span>
        ";
        }
        // line 21
        echo "    </span>
";
        
        $__internal_31d369abfa05c6bf9f60fdbc8b31c9cf460b83c3c476735d66cef7c6f7a7644b->leave($__internal_31d369abfa05c6bf9f60fdbc8b31c9cf460b83c3c476735d66cef7c6f7a7644b_prof);

        
        $__internal_1a8a5cd9a632cebc069583fa273b39604faeb32f053649c4cf49c97beeb4cd39->leave($__internal_1a8a5cd9a632cebc069583fa273b39604faeb32f053649c4cf49c97beeb4cd39_prof);

    }

    // line 24
    public function block_panel($context, array $blocks = array())
    {
        $__internal_3e039f6fc5c839d244591148ce583ea23da24b4ddddd1190f3035507b3e4a9e8 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3e039f6fc5c839d244591148ce583ea23da24b4ddddd1190f3035507b3e4a9e8->enter($__internal_3e039f6fc5c839d244591148ce583ea23da24b4ddddd1190f3035507b3e4a9e8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_f53f62da1d318ae96bbcdd880810acda8f142b225ecfabe9f9b9cc0e4f605b7e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f53f62da1d318ae96bbcdd880810acda8f142b225ecfabe9f9b9cc0e4f605b7e->enter($__internal_f53f62da1d318ae96bbcdd880810acda8f142b225ecfabe9f9b9cc0e4f605b7e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 25
        echo "    <h2>Exceptions</h2>

    ";
        // line 27
        if ( !$this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) {
            // line 28
            echo "        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    ";
        } else {
            // line 32
            echo "        <div class=\"sf-reset\">
            ";
            // line 33
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_exception", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
            echo "
        </div>
    ";
        }
        
        $__internal_f53f62da1d318ae96bbcdd880810acda8f142b225ecfabe9f9b9cc0e4f605b7e->leave($__internal_f53f62da1d318ae96bbcdd880810acda8f142b225ecfabe9f9b9cc0e4f605b7e_prof);

        
        $__internal_3e039f6fc5c839d244591148ce583ea23da24b4ddddd1190f3035507b3e4a9e8->leave($__internal_3e039f6fc5c839d244591148ce583ea23da24b4ddddd1190f3035507b3e4a9e8_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Collector:exception.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  138 => 33,  135 => 32,  129 => 28,  127 => 27,  123 => 25,  114 => 24,  103 => 21,  97 => 17,  95 => 16,  90 => 14,  85 => 13,  76 => 12,  63 => 9,  57 => 6,  54 => 5,  51 => 4,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block head %}
    {% if collector.hasexception %}
        <style>
            {{ render(path('_profiler_exception_css', { token: token })) }}
        </style>
    {% endif %}
    {{ parent() }}
{% endblock %}

{% block menu %}
    <span class=\"label {{ collector.hasexception ? 'label-status-error' : 'disabled' }}\">
        <span class=\"icon\">{{ include('@WebProfiler/Icon/exception.svg') }}</span>
        <strong>Exception</strong>
        {% if collector.hasexception %}
            <span class=\"count\">
                <span>1</span>
            </span>
        {% endif %}
    </span>
{% endblock %}

{% block panel %}
    <h2>Exceptions</h2>

    {% if not collector.hasexception %}
        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    {% else %}
        <div class=\"sf-reset\">
            {{ render(path('_profiler_exception', { token: token })) }}
        </div>
    {% endif %}
{% endblock %}
", "WebProfilerBundle:Collector:exception.html.twig", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\models\\symfony\\db_action\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle/Resources/views/Collector/exception.html.twig");
    }
}
