<?php

/* @Twig/Exception/error.js.twig */
class __TwigTemplate_b2fe359392c0997a04c6199ebc33f0fb3a476aa27c4a552a2ea1174f5cc48be3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9f74e0f2794cb23aeca9c2d54b4dfb5b16bdedbe4353ed15fe1aedf7bdd1cb84 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9f74e0f2794cb23aeca9c2d54b4dfb5b16bdedbe4353ed15fe1aedf7bdd1cb84->enter($__internal_9f74e0f2794cb23aeca9c2d54b4dfb5b16bdedbe4353ed15fe1aedf7bdd1cb84_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.js.twig"));

        $__internal_c8b4f39193cab33d82a3caaa32fe0509e3fb9654fe3ba1d49f665731166bb098 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c8b4f39193cab33d82a3caaa32fe0509e3fb9654fe3ba1d49f665731166bb098->enter($__internal_c8b4f39193cab33d82a3caaa32fe0509e3fb9654fe3ba1d49f665731166bb098_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.js.twig"));

        // line 1
        echo "/*
";
        // line 2
        echo twig_escape_filter($this->env, ($context["status_code"] ?? $this->getContext($context, "status_code")), "js", null, true);
        echo " ";
        echo twig_escape_filter($this->env, ($context["status_text"] ?? $this->getContext($context, "status_text")), "js", null, true);
        echo "

*/
";
        
        $__internal_9f74e0f2794cb23aeca9c2d54b4dfb5b16bdedbe4353ed15fe1aedf7bdd1cb84->leave($__internal_9f74e0f2794cb23aeca9c2d54b4dfb5b16bdedbe4353ed15fe1aedf7bdd1cb84_prof);

        
        $__internal_c8b4f39193cab33d82a3caaa32fe0509e3fb9654fe3ba1d49f665731166bb098->leave($__internal_c8b4f39193cab33d82a3caaa32fe0509e3fb9654fe3ba1d49f665731166bb098_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/error.js.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  28 => 2,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("/*
{{ status_code }} {{ status_text }}

*/
", "@Twig/Exception/error.js.twig", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\models\\symfony\\db_action\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\error.js.twig");
    }
}
