<?php

/* @Framework/Form/choice_widget.html.php */
class __TwigTemplate_19b24c3ca01ff1c80cb89eb5c1e553139f31644b676124b8966ecfc0b2ac90f6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_031d36a51c06d18d8cab763dd2ee2097eb89fc404b2ab1cce308a580eb8b2460 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_031d36a51c06d18d8cab763dd2ee2097eb89fc404b2ab1cce308a580eb8b2460->enter($__internal_031d36a51c06d18d8cab763dd2ee2097eb89fc404b2ab1cce308a580eb8b2460_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_widget.html.php"));

        $__internal_067aeb51112ebf102774c065d39cfbf6ae18cd003f8cacbf2fc3b35486991ba0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_067aeb51112ebf102774c065d39cfbf6ae18cd003f8cacbf2fc3b35486991ba0->enter($__internal_067aeb51112ebf102774c065d39cfbf6ae18cd003f8cacbf2fc3b35486991ba0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_widget.html.php"));

        // line 1
        echo "<?php if (\$expanded): ?>
<?php echo \$view['form']->block(\$form, 'choice_widget_expanded') ?>
<?php else: ?>
<?php echo \$view['form']->block(\$form, 'choice_widget_collapsed') ?>
<?php endif ?>
";
        
        $__internal_031d36a51c06d18d8cab763dd2ee2097eb89fc404b2ab1cce308a580eb8b2460->leave($__internal_031d36a51c06d18d8cab763dd2ee2097eb89fc404b2ab1cce308a580eb8b2460_prof);

        
        $__internal_067aeb51112ebf102774c065d39cfbf6ae18cd003f8cacbf2fc3b35486991ba0->leave($__internal_067aeb51112ebf102774c065d39cfbf6ae18cd003f8cacbf2fc3b35486991ba0_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/choice_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (\$expanded): ?>
<?php echo \$view['form']->block(\$form, 'choice_widget_expanded') ?>
<?php else: ?>
<?php echo \$view['form']->block(\$form, 'choice_widget_collapsed') ?>
<?php endif ?>
", "@Framework/Form/choice_widget.html.php", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\models\\symfony\\db_action\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\choice_widget.html.php");
    }
}
