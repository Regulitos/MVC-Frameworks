<?php

/* @Framework/Form/repeated_row.html.php */
class __TwigTemplate_3d206093c01bde614dd5f7f2051942fddf01f2a533f1e9edcb39b5be2ec6f34e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ab55189c3e872072eb6b49fb54b7d1696eddaa8c534b4fadb86d4bdffe13b04e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ab55189c3e872072eb6b49fb54b7d1696eddaa8c534b4fadb86d4bdffe13b04e->enter($__internal_ab55189c3e872072eb6b49fb54b7d1696eddaa8c534b4fadb86d4bdffe13b04e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/repeated_row.html.php"));

        $__internal_316c185ab7feabdad3fa5b3cfca96b9f32975823c30ae3af5661ac056ffd57e0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_316c185ab7feabdad3fa5b3cfca96b9f32975823c30ae3af5661ac056ffd57e0->enter($__internal_316c185ab7feabdad3fa5b3cfca96b9f32975823c30ae3af5661ac056ffd57e0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/repeated_row.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_rows') ?>
";
        
        $__internal_ab55189c3e872072eb6b49fb54b7d1696eddaa8c534b4fadb86d4bdffe13b04e->leave($__internal_ab55189c3e872072eb6b49fb54b7d1696eddaa8c534b4fadb86d4bdffe13b04e_prof);

        
        $__internal_316c185ab7feabdad3fa5b3cfca96b9f32975823c30ae3af5661ac056ffd57e0->leave($__internal_316c185ab7feabdad3fa5b3cfca96b9f32975823c30ae3af5661ac056ffd57e0_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/repeated_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_rows') ?>
", "@Framework/Form/repeated_row.html.php", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\models\\symfony\\db_action\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\repeated_row.html.php");
    }
}
