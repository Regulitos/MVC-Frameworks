<?php

/* @Framework/Form/container_attributes.html.php */
class __TwigTemplate_8a959162f56f1bfbb5f9c52e02de2bde1e6c6462ba175f004ceb38a8defcd36f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e899938dfef33d77737fadf5fb6cc317d809ba8eef58f52f19153febd68e1a93 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e899938dfef33d77737fadf5fb6cc317d809ba8eef58f52f19153febd68e1a93->enter($__internal_e899938dfef33d77737fadf5fb6cc317d809ba8eef58f52f19153febd68e1a93_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/container_attributes.html.php"));

        $__internal_46c5416b929ec58ca07e34e023c6fb41223aa6914ad7c1800fa2d83a813a0606 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_46c5416b929ec58ca07e34e023c6fb41223aa6914ad7c1800fa2d83a813a0606->enter($__internal_46c5416b929ec58ca07e34e023c6fb41223aa6914ad7c1800fa2d83a813a0606_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/container_attributes.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>
";
        
        $__internal_e899938dfef33d77737fadf5fb6cc317d809ba8eef58f52f19153febd68e1a93->leave($__internal_e899938dfef33d77737fadf5fb6cc317d809ba8eef58f52f19153febd68e1a93_prof);

        
        $__internal_46c5416b929ec58ca07e34e023c6fb41223aa6914ad7c1800fa2d83a813a0606->leave($__internal_46c5416b929ec58ca07e34e023c6fb41223aa6914ad7c1800fa2d83a813a0606_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/container_attributes.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>
", "@Framework/Form/container_attributes.html.php", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\models\\symfony\\db_action\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\container_attributes.html.php");
    }
}
