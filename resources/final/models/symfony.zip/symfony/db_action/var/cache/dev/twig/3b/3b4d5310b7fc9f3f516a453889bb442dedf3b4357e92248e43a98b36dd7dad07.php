<?php

/* WebProfilerBundle:Profiler:ajax_layout.html.twig */
class __TwigTemplate_ea5546ba30baf4b586e3d8de7ea5609933e843ee1c480e8a1618a0e56cbaf936 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1a5c619fca0afc9eb5d69007619084b77e5bc5a798333c968e5dc56611b4bce1 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1a5c619fca0afc9eb5d69007619084b77e5bc5a798333c968e5dc56611b4bce1->enter($__internal_1a5c619fca0afc9eb5d69007619084b77e5bc5a798333c968e5dc56611b4bce1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:ajax_layout.html.twig"));

        $__internal_4c46c6f0f4db3df6e0fafe57921c2d8106206f030cd2a8f02622de83d746ed3d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4c46c6f0f4db3df6e0fafe57921c2d8106206f030cd2a8f02622de83d746ed3d->enter($__internal_4c46c6f0f4db3df6e0fafe57921c2d8106206f030cd2a8f02622de83d746ed3d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:ajax_layout.html.twig"));

        // line 1
        $this->displayBlock('panel', $context, $blocks);
        
        $__internal_1a5c619fca0afc9eb5d69007619084b77e5bc5a798333c968e5dc56611b4bce1->leave($__internal_1a5c619fca0afc9eb5d69007619084b77e5bc5a798333c968e5dc56611b4bce1_prof);

        
        $__internal_4c46c6f0f4db3df6e0fafe57921c2d8106206f030cd2a8f02622de83d746ed3d->leave($__internal_4c46c6f0f4db3df6e0fafe57921c2d8106206f030cd2a8f02622de83d746ed3d_prof);

    }

    public function block_panel($context, array $blocks = array())
    {
        $__internal_80101b53db819c824802e860426cfeee60cb1588df2fac8165a2f6334c3af5c2 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_80101b53db819c824802e860426cfeee60cb1588df2fac8165a2f6334c3af5c2->enter($__internal_80101b53db819c824802e860426cfeee60cb1588df2fac8165a2f6334c3af5c2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_c2bff2478e83db184518fd49cfa48ca925d4fe3faf5ff1cdca5debe39762a792 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c2bff2478e83db184518fd49cfa48ca925d4fe3faf5ff1cdca5debe39762a792->enter($__internal_c2bff2478e83db184518fd49cfa48ca925d4fe3faf5ff1cdca5debe39762a792_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        echo "";
        
        $__internal_c2bff2478e83db184518fd49cfa48ca925d4fe3faf5ff1cdca5debe39762a792->leave($__internal_c2bff2478e83db184518fd49cfa48ca925d4fe3faf5ff1cdca5debe39762a792_prof);

        
        $__internal_80101b53db819c824802e860426cfeee60cb1588df2fac8165a2f6334c3af5c2->leave($__internal_80101b53db819c824802e860426cfeee60cb1588df2fac8165a2f6334c3af5c2_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:ajax_layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  26 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% block panel '' %}
", "WebProfilerBundle:Profiler:ajax_layout.html.twig", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\models\\symfony\\db_action\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle/Resources/views/Profiler/ajax_layout.html.twig");
    }
}
