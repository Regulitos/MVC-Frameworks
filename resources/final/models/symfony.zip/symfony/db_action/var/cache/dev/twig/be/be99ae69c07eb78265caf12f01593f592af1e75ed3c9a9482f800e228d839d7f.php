<?php

/* @Framework/Form/email_widget.html.php */
class __TwigTemplate_2f3d959d9d3903a747a22cbd389c8b17ad767e5dc1fd577fc679de2d401a013c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ec1efc609a4ce12eba48ec861c20325234bdd3193bd2f46d111ac4f5e2922b01 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ec1efc609a4ce12eba48ec861c20325234bdd3193bd2f46d111ac4f5e2922b01->enter($__internal_ec1efc609a4ce12eba48ec861c20325234bdd3193bd2f46d111ac4f5e2922b01_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/email_widget.html.php"));

        $__internal_1efb39b63b9307d495a81c1bb4144dfe916288c2c086edb42bcbeda4b2e04040 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1efb39b63b9307d495a81c1bb4144dfe916288c2c086edb42bcbeda4b2e04040->enter($__internal_1efb39b63b9307d495a81c1bb4144dfe916288c2c086edb42bcbeda4b2e04040_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/email_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'email')) ?>
";
        
        $__internal_ec1efc609a4ce12eba48ec861c20325234bdd3193bd2f46d111ac4f5e2922b01->leave($__internal_ec1efc609a4ce12eba48ec861c20325234bdd3193bd2f46d111ac4f5e2922b01_prof);

        
        $__internal_1efb39b63b9307d495a81c1bb4144dfe916288c2c086edb42bcbeda4b2e04040->leave($__internal_1efb39b63b9307d495a81c1bb4144dfe916288c2c086edb42bcbeda4b2e04040_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/email_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'email')) ?>
", "@Framework/Form/email_widget.html.php", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\models\\symfony\\db_action\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\email_widget.html.php");
    }
}
