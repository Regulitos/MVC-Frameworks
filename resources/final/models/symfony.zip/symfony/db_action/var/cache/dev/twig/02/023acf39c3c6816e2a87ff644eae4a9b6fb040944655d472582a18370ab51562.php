<?php

/* WebProfilerBundle:Profiler:info.html.twig */
class __TwigTemplate_771395e64b1fa3b1b1e6864b7d2b6aef971386f838b7a7b11afeb3022181fced extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "WebProfilerBundle:Profiler:info.html.twig", 1);
        $this->blocks = array(
            'summary' => array($this, 'block_summary'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6a2e7526d1983ce34c3f6eba6d29df0b68a5ba519b82f03c238ac6fb03594318 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6a2e7526d1983ce34c3f6eba6d29df0b68a5ba519b82f03c238ac6fb03594318->enter($__internal_6a2e7526d1983ce34c3f6eba6d29df0b68a5ba519b82f03c238ac6fb03594318_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:info.html.twig"));

        $__internal_6e9adcf0cdcf10095b8dc4080f7ee5ca34c9dd676010db6cb05e5bcfc92ec246 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6e9adcf0cdcf10095b8dc4080f7ee5ca34c9dd676010db6cb05e5bcfc92ec246->enter($__internal_6e9adcf0cdcf10095b8dc4080f7ee5ca34c9dd676010db6cb05e5bcfc92ec246_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:info.html.twig"));

        // line 3
        $context["messages"] = array("purge" => array("status" => "success", "title" => "The profiler database was purged successfully", "message" => "Now you need to browse some pages with the Symfony Profiler enabled to collect data."), "no_token" => array("status" => "error", "title" => (((((        // line 11
array_key_exists("token", $context)) ? (_twig_default_filter(($context["token"] ?? $this->getContext($context, "token")), "")) : ("")) == "latest")) ? ("There are no profiles") : ("Token not found")), "message" => (((((        // line 12
array_key_exists("token", $context)) ? (_twig_default_filter(($context["token"] ?? $this->getContext($context, "token")), "")) : ("")) == "latest")) ? ("No profiles found in the database.") : ((("Token \"" . ((array_key_exists("token", $context)) ? (_twig_default_filter(($context["token"] ?? $this->getContext($context, "token")), "")) : (""))) . "\" was not found in the database.")))), "upload_error" => array("status" => "error", "title" => "A problem occurred when uploading the data", "message" => "No file given or the file was not uploaded successfully."), "already_exists" => array("status" => "error", "title" => "A problem occurred when uploading the data", "message" => "The token already exists in the database."));
        // line 1
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_6a2e7526d1983ce34c3f6eba6d29df0b68a5ba519b82f03c238ac6fb03594318->leave($__internal_6a2e7526d1983ce34c3f6eba6d29df0b68a5ba519b82f03c238ac6fb03594318_prof);

        
        $__internal_6e9adcf0cdcf10095b8dc4080f7ee5ca34c9dd676010db6cb05e5bcfc92ec246->leave($__internal_6e9adcf0cdcf10095b8dc4080f7ee5ca34c9dd676010db6cb05e5bcfc92ec246_prof);

    }

    // line 26
    public function block_summary($context, array $blocks = array())
    {
        $__internal_a9d1a612239af106c5216486a8dfc66a9bd080fef4c66640ada58b68462dbf5d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a9d1a612239af106c5216486a8dfc66a9bd080fef4c66640ada58b68462dbf5d->enter($__internal_a9d1a612239af106c5216486a8dfc66a9bd080fef4c66640ada58b68462dbf5d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "summary"));

        $__internal_1a23f98164db9f10954e3c4e67bd30aaebd7b40d006026d7df30e7a83bb01f81 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1a23f98164db9f10954e3c4e67bd30aaebd7b40d006026d7df30e7a83bb01f81->enter($__internal_1a23f98164db9f10954e3c4e67bd30aaebd7b40d006026d7df30e7a83bb01f81_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "summary"));

        // line 27
        echo "    <div class=\"status status-";
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["messages"] ?? $this->getContext($context, "messages")), ($context["about"] ?? $this->getContext($context, "about")), array(), "array"), "status", array()), "html", null, true);
        echo "\">
        <div class=\"container\">
            <h2>";
        // line 29
        echo twig_escape_filter($this->env, twig_title_string_filter($this->env, $this->getAttribute($this->getAttribute(($context["messages"] ?? $this->getContext($context, "messages")), ($context["about"] ?? $this->getContext($context, "about")), array(), "array"), "status", array())), "html", null, true);
        echo "</h2>
        </div>
    </div>
";
        
        $__internal_1a23f98164db9f10954e3c4e67bd30aaebd7b40d006026d7df30e7a83bb01f81->leave($__internal_1a23f98164db9f10954e3c4e67bd30aaebd7b40d006026d7df30e7a83bb01f81_prof);

        
        $__internal_a9d1a612239af106c5216486a8dfc66a9bd080fef4c66640ada58b68462dbf5d->leave($__internal_a9d1a612239af106c5216486a8dfc66a9bd080fef4c66640ada58b68462dbf5d_prof);

    }

    // line 34
    public function block_panel($context, array $blocks = array())
    {
        $__internal_49baa36e6846e2aebf395262d523774688d1b5fc4e3ba6aff62934e505794e38 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_49baa36e6846e2aebf395262d523774688d1b5fc4e3ba6aff62934e505794e38->enter($__internal_49baa36e6846e2aebf395262d523774688d1b5fc4e3ba6aff62934e505794e38_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_44bcc3a958991f245fe48740ac4a091b856b405460e030b451206d749bc32dce = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_44bcc3a958991f245fe48740ac4a091b856b405460e030b451206d749bc32dce->enter($__internal_44bcc3a958991f245fe48740ac4a091b856b405460e030b451206d749bc32dce_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 35
        echo "    <h2>";
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["messages"] ?? $this->getContext($context, "messages")), ($context["about"] ?? $this->getContext($context, "about")), array(), "array"), "title", array()), "html", null, true);
        echo "</h2>
    <p>";
        // line 36
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["messages"] ?? $this->getContext($context, "messages")), ($context["about"] ?? $this->getContext($context, "about")), array(), "array"), "message", array()), "html", null, true);
        echo "</p>
";
        
        $__internal_44bcc3a958991f245fe48740ac4a091b856b405460e030b451206d749bc32dce->leave($__internal_44bcc3a958991f245fe48740ac4a091b856b405460e030b451206d749bc32dce_prof);

        
        $__internal_49baa36e6846e2aebf395262d523774688d1b5fc4e3ba6aff62934e505794e38->leave($__internal_49baa36e6846e2aebf395262d523774688d1b5fc4e3ba6aff62934e505794e38_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:info.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  89 => 36,  84 => 35,  75 => 34,  61 => 29,  55 => 27,  46 => 26,  36 => 1,  34 => 12,  33 => 11,  32 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% set messages = {
    'purge' : {
        status:  'success',
        title:   'The profiler database was purged successfully',
        message: 'Now you need to browse some pages with the Symfony Profiler enabled to collect data.'
    },
    'no_token' : {
        status:  'error',
        title:   (token|default('') == 'latest') ? 'There are no profiles' : 'Token not found',
        message: (token|default('') == 'latest') ? 'No profiles found in the database.' : 'Token \"' ~ token|default('') ~ '\" was not found in the database.'
    },
    'upload_error' : {
        status:  'error',
        title:   'A problem occurred when uploading the data',
        message: 'No file given or the file was not uploaded successfully.'
    },
    'already_exists' : {
        status:  'error',
        title:   'A problem occurred when uploading the data',
        message: 'The token already exists in the database.'
    }
} %}

{% block summary %}
    <div class=\"status status-{{ messages[about].status }}\">
        <div class=\"container\">
            <h2>{{ messages[about].status|title }}</h2>
        </div>
    </div>
{% endblock %}

{% block panel %}
    <h2>{{ messages[about].title }}</h2>
    <p>{{ messages[about].message }}</p>
{% endblock %}
", "WebProfilerBundle:Profiler:info.html.twig", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\models\\symfony\\db_action\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle/Resources/views/Profiler/info.html.twig");
    }
}
