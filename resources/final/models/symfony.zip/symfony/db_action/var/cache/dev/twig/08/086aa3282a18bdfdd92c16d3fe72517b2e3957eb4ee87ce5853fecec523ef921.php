<?php

/* @WebProfiler/Collector/exception.html.twig */
class __TwigTemplate_91f23d26d1e9c4d15bd74abc1f548fe71498140eaf4fd2e477e058e8a9bd1df4 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/exception.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0dfaba4aa65c88151d17f3dbcaa86fc6bd855a31cf3fa304af14cbad432231f4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0dfaba4aa65c88151d17f3dbcaa86fc6bd855a31cf3fa304af14cbad432231f4->enter($__internal_0dfaba4aa65c88151d17f3dbcaa86fc6bd855a31cf3fa304af14cbad432231f4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/exception.html.twig"));

        $__internal_429113e1a26d22ba7cc7ec74b9df0deb071507c07936210b3604e2f8281be8e1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_429113e1a26d22ba7cc7ec74b9df0deb071507c07936210b3604e2f8281be8e1->enter($__internal_429113e1a26d22ba7cc7ec74b9df0deb071507c07936210b3604e2f8281be8e1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/exception.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_0dfaba4aa65c88151d17f3dbcaa86fc6bd855a31cf3fa304af14cbad432231f4->leave($__internal_0dfaba4aa65c88151d17f3dbcaa86fc6bd855a31cf3fa304af14cbad432231f4_prof);

        
        $__internal_429113e1a26d22ba7cc7ec74b9df0deb071507c07936210b3604e2f8281be8e1->leave($__internal_429113e1a26d22ba7cc7ec74b9df0deb071507c07936210b3604e2f8281be8e1_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_efed3775d101e31eb4a5bc884d88707d2120bd52e67829c61d2ac23958409604 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_efed3775d101e31eb4a5bc884d88707d2120bd52e67829c61d2ac23958409604->enter($__internal_efed3775d101e31eb4a5bc884d88707d2120bd52e67829c61d2ac23958409604_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        $__internal_69fc6ec17f2b48483e49ce239bcea091c971dd0aa8dc18ca392b2b5a59581b2f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_69fc6ec17f2b48483e49ce239bcea091c971dd0aa8dc18ca392b2b5a59581b2f->enter($__internal_69fc6ec17f2b48483e49ce239bcea091c971dd0aa8dc18ca392b2b5a59581b2f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    ";
        if ($this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) {
            // line 5
            echo "        <style>
            ";
            // line 6
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_exception_css", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
            echo "
        </style>
    ";
        }
        // line 9
        echo "    ";
        $this->displayParentBlock("head", $context, $blocks);
        echo "
";
        
        $__internal_69fc6ec17f2b48483e49ce239bcea091c971dd0aa8dc18ca392b2b5a59581b2f->leave($__internal_69fc6ec17f2b48483e49ce239bcea091c971dd0aa8dc18ca392b2b5a59581b2f_prof);

        
        $__internal_efed3775d101e31eb4a5bc884d88707d2120bd52e67829c61d2ac23958409604->leave($__internal_efed3775d101e31eb4a5bc884d88707d2120bd52e67829c61d2ac23958409604_prof);

    }

    // line 12
    public function block_menu($context, array $blocks = array())
    {
        $__internal_208810be57dead705ced95e8127702c93b04ee57dd85333a693f4eaef109b67d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_208810be57dead705ced95e8127702c93b04ee57dd85333a693f4eaef109b67d->enter($__internal_208810be57dead705ced95e8127702c93b04ee57dd85333a693f4eaef109b67d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_97cf61208e6fede279f18544b8833b64aeaf275b752b2a9d5b1bcb4ed1f177ac = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_97cf61208e6fede279f18544b8833b64aeaf275b752b2a9d5b1bcb4ed1f177ac->enter($__internal_97cf61208e6fede279f18544b8833b64aeaf275b752b2a9d5b1bcb4ed1f177ac_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 13
        echo "    <span class=\"label ";
        echo (($this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) ? ("label-status-error") : ("disabled"));
        echo "\">
        <span class=\"icon\">";
        // line 14
        echo twig_include($this->env, $context, "@WebProfiler/Icon/exception.svg");
        echo "</span>
        <strong>Exception</strong>
        ";
        // line 16
        if ($this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) {
            // line 17
            echo "            <span class=\"count\">
                <span>1</span>
            </span>
        ";
        }
        // line 21
        echo "    </span>
";
        
        $__internal_97cf61208e6fede279f18544b8833b64aeaf275b752b2a9d5b1bcb4ed1f177ac->leave($__internal_97cf61208e6fede279f18544b8833b64aeaf275b752b2a9d5b1bcb4ed1f177ac_prof);

        
        $__internal_208810be57dead705ced95e8127702c93b04ee57dd85333a693f4eaef109b67d->leave($__internal_208810be57dead705ced95e8127702c93b04ee57dd85333a693f4eaef109b67d_prof);

    }

    // line 24
    public function block_panel($context, array $blocks = array())
    {
        $__internal_84889f8e6f08228121023bef0174a7f091af122f2cad459fc10c8d2d2539e997 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_84889f8e6f08228121023bef0174a7f091af122f2cad459fc10c8d2d2539e997->enter($__internal_84889f8e6f08228121023bef0174a7f091af122f2cad459fc10c8d2d2539e997_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_73b3f759897dabf5ec763ee9e86369f793aee56f1591671f938ce7ac9ce6f357 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_73b3f759897dabf5ec763ee9e86369f793aee56f1591671f938ce7ac9ce6f357->enter($__internal_73b3f759897dabf5ec763ee9e86369f793aee56f1591671f938ce7ac9ce6f357_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 25
        echo "    <h2>Exceptions</h2>

    ";
        // line 27
        if ( !$this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) {
            // line 28
            echo "        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    ";
        } else {
            // line 32
            echo "        <div class=\"sf-reset\">
            ";
            // line 33
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_exception", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
            echo "
        </div>
    ";
        }
        
        $__internal_73b3f759897dabf5ec763ee9e86369f793aee56f1591671f938ce7ac9ce6f357->leave($__internal_73b3f759897dabf5ec763ee9e86369f793aee56f1591671f938ce7ac9ce6f357_prof);

        
        $__internal_84889f8e6f08228121023bef0174a7f091af122f2cad459fc10c8d2d2539e997->leave($__internal_84889f8e6f08228121023bef0174a7f091af122f2cad459fc10c8d2d2539e997_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/exception.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  138 => 33,  135 => 32,  129 => 28,  127 => 27,  123 => 25,  114 => 24,  103 => 21,  97 => 17,  95 => 16,  90 => 14,  85 => 13,  76 => 12,  63 => 9,  57 => 6,  54 => 5,  51 => 4,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block head %}
    {% if collector.hasexception %}
        <style>
            {{ render(path('_profiler_exception_css', { token: token })) }}
        </style>
    {% endif %}
    {{ parent() }}
{% endblock %}

{% block menu %}
    <span class=\"label {{ collector.hasexception ? 'label-status-error' : 'disabled' }}\">
        <span class=\"icon\">{{ include('@WebProfiler/Icon/exception.svg') }}</span>
        <strong>Exception</strong>
        {% if collector.hasexception %}
            <span class=\"count\">
                <span>1</span>
            </span>
        {% endif %}
    </span>
{% endblock %}

{% block panel %}
    <h2>Exceptions</h2>

    {% if not collector.hasexception %}
        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    {% else %}
        <div class=\"sf-reset\">
            {{ render(path('_profiler_exception', { token: token })) }}
        </div>
    {% endif %}
{% endblock %}
", "@WebProfiler/Collector/exception.html.twig", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\models\\symfony\\db_action\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Collector\\exception.html.twig");
    }
}
