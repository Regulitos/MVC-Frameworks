<?php

/* @Framework/Form/search_widget.html.php */
class __TwigTemplate_86b09fd648f156ff6c80423206809b69b634e339354b63d942f6e31710f8e890 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7a8fa41f2c22d6a6786c4a8e2bffd3bb27126398a473d28a112eec52cd39e62f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_7a8fa41f2c22d6a6786c4a8e2bffd3bb27126398a473d28a112eec52cd39e62f->enter($__internal_7a8fa41f2c22d6a6786c4a8e2bffd3bb27126398a473d28a112eec52cd39e62f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/search_widget.html.php"));

        $__internal_e847e04e8bd65de3a5a9bfa91ebfbd2a662847dee09452ddc725a2c35717feab = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e847e04e8bd65de3a5a9bfa91ebfbd2a662847dee09452ddc725a2c35717feab->enter($__internal_e847e04e8bd65de3a5a9bfa91ebfbd2a662847dee09452ddc725a2c35717feab_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/search_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'search')) ?>
";
        
        $__internal_7a8fa41f2c22d6a6786c4a8e2bffd3bb27126398a473d28a112eec52cd39e62f->leave($__internal_7a8fa41f2c22d6a6786c4a8e2bffd3bb27126398a473d28a112eec52cd39e62f_prof);

        
        $__internal_e847e04e8bd65de3a5a9bfa91ebfbd2a662847dee09452ddc725a2c35717feab->leave($__internal_e847e04e8bd65de3a5a9bfa91ebfbd2a662847dee09452ddc725a2c35717feab_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/search_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'search')) ?>
", "@Framework/Form/search_widget.html.php", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\models\\symfony\\db_action\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\search_widget.html.php");
    }
}
