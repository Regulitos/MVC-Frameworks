<?php

/* TwigBundle:Exception:exception.atom.twig */
class __TwigTemplate_8bad279752edf5670e2ecf0b4208dbc1dd1c3e31e9889cff1243f386cedd9af0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_559418fac212fd4a2f1853b136e855a6d6f81669871a68c7323a054539c63780 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_559418fac212fd4a2f1853b136e855a6d6f81669871a68c7323a054539c63780->enter($__internal_559418fac212fd4a2f1853b136e855a6d6f81669871a68c7323a054539c63780_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.atom.twig"));

        $__internal_4d77cfcc940096ae8a66fb31b37f09996a8d2285b03193e8349669b005957bde = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4d77cfcc940096ae8a66fb31b37f09996a8d2285b03193e8349669b005957bde->enter($__internal_4d77cfcc940096ae8a66fb31b37f09996a8d2285b03193e8349669b005957bde_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.atom.twig"));

        // line 1
        echo twig_include($this->env, $context, "@Twig/Exception/exception.xml.twig", array("exception" => ($context["exception"] ?? $this->getContext($context, "exception"))));
        echo "
";
        
        $__internal_559418fac212fd4a2f1853b136e855a6d6f81669871a68c7323a054539c63780->leave($__internal_559418fac212fd4a2f1853b136e855a6d6f81669871a68c7323a054539c63780_prof);

        
        $__internal_4d77cfcc940096ae8a66fb31b37f09996a8d2285b03193e8349669b005957bde->leave($__internal_4d77cfcc940096ae8a66fb31b37f09996a8d2285b03193e8349669b005957bde_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.atom.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ include('@Twig/Exception/exception.xml.twig', { exception: exception }) }}
", "TwigBundle:Exception:exception.atom.twig", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\models\\symfony\\db_action\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle/Resources/views/Exception/exception.atom.twig");
    }
}
