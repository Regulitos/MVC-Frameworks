<?php

/* @Framework/Form/hidden_widget.html.php */
class __TwigTemplate_ef0e02473280788a3697a14c8764ae33e7774eed4d262bda3aac5633e3cefc7d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a4c946523b5f4e35b7721d255ebc80e01de806b03b6a9367aed32e77a456cda1 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a4c946523b5f4e35b7721d255ebc80e01de806b03b6a9367aed32e77a456cda1->enter($__internal_a4c946523b5f4e35b7721d255ebc80e01de806b03b6a9367aed32e77a456cda1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/hidden_widget.html.php"));

        $__internal_54f351720c2df8e5a3f5c40f47b9bb6a85ed1f9dccd76422af888ecbee37ba53 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_54f351720c2df8e5a3f5c40f47b9bb6a85ed1f9dccd76422af888ecbee37ba53->enter($__internal_54f351720c2df8e5a3f5c40f47b9bb6a85ed1f9dccd76422af888ecbee37ba53_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/hidden_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'hidden')) ?>
";
        
        $__internal_a4c946523b5f4e35b7721d255ebc80e01de806b03b6a9367aed32e77a456cda1->leave($__internal_a4c946523b5f4e35b7721d255ebc80e01de806b03b6a9367aed32e77a456cda1_prof);

        
        $__internal_54f351720c2df8e5a3f5c40f47b9bb6a85ed1f9dccd76422af888ecbee37ba53->leave($__internal_54f351720c2df8e5a3f5c40f47b9bb6a85ed1f9dccd76422af888ecbee37ba53_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/hidden_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'hidden')) ?>
", "@Framework/Form/hidden_widget.html.php", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\models\\symfony\\db_action\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\hidden_widget.html.php");
    }
}
