<?php

/* @Framework/Form/button_label.html.php */
class __TwigTemplate_0710a0509677fc0eb5b818cff1fe5c815f5c29a8028b78066672fae900340f03 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_abfc6bcdebcdcd54b58ed2ea755322af7e4a1f424e6dd37c491582ba62087652 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_abfc6bcdebcdcd54b58ed2ea755322af7e4a1f424e6dd37c491582ba62087652->enter($__internal_abfc6bcdebcdcd54b58ed2ea755322af7e4a1f424e6dd37c491582ba62087652_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_label.html.php"));

        $__internal_6bb100bc9ed288e90046ae892a1652f5117053e618249e676bfd45b243e4e878 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6bb100bc9ed288e90046ae892a1652f5117053e618249e676bfd45b243e4e878->enter($__internal_6bb100bc9ed288e90046ae892a1652f5117053e618249e676bfd45b243e4e878_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_label.html.php"));

        
        $__internal_abfc6bcdebcdcd54b58ed2ea755322af7e4a1f424e6dd37c491582ba62087652->leave($__internal_abfc6bcdebcdcd54b58ed2ea755322af7e4a1f424e6dd37c491582ba62087652_prof);

        
        $__internal_6bb100bc9ed288e90046ae892a1652f5117053e618249e676bfd45b243e4e878->leave($__internal_6bb100bc9ed288e90046ae892a1652f5117053e618249e676bfd45b243e4e878_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_label.html.php";
    }

    public function getDebugInfo()
    {
        return array ();
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "@Framework/Form/button_label.html.php", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\models\\symfony\\db_action\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\button_label.html.php");
    }
}
