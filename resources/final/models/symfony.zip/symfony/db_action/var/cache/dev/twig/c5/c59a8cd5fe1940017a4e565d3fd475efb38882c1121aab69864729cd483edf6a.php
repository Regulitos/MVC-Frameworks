<?php

/* TwigBundle:Exception:error.js.twig */
class __TwigTemplate_c03c92ad869670f18bf9afe943f604332e795d48247f03ab695a303201fc70e3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9e483fc256633f16e3a153de6dd2cc1f9a4c96a55d10e7f88fec09be8da07b50 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9e483fc256633f16e3a153de6dd2cc1f9a4c96a55d10e7f88fec09be8da07b50->enter($__internal_9e483fc256633f16e3a153de6dd2cc1f9a4c96a55d10e7f88fec09be8da07b50_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.js.twig"));

        $__internal_741464ec6cc37a28cf0b3b07850333f5c6db71e3cd4fc7acdcb0e9fbe4bd12a2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_741464ec6cc37a28cf0b3b07850333f5c6db71e3cd4fc7acdcb0e9fbe4bd12a2->enter($__internal_741464ec6cc37a28cf0b3b07850333f5c6db71e3cd4fc7acdcb0e9fbe4bd12a2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.js.twig"));

        // line 1
        echo "/*
";
        // line 2
        echo twig_escape_filter($this->env, ($context["status_code"] ?? $this->getContext($context, "status_code")), "js", null, true);
        echo " ";
        echo twig_escape_filter($this->env, ($context["status_text"] ?? $this->getContext($context, "status_text")), "js", null, true);
        echo "

*/
";
        
        $__internal_9e483fc256633f16e3a153de6dd2cc1f9a4c96a55d10e7f88fec09be8da07b50->leave($__internal_9e483fc256633f16e3a153de6dd2cc1f9a4c96a55d10e7f88fec09be8da07b50_prof);

        
        $__internal_741464ec6cc37a28cf0b3b07850333f5c6db71e3cd4fc7acdcb0e9fbe4bd12a2->leave($__internal_741464ec6cc37a28cf0b3b07850333f5c6db71e3cd4fc7acdcb0e9fbe4bd12a2_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.js.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  28 => 2,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("/*
{{ status_code }} {{ status_text }}

*/
", "TwigBundle:Exception:error.js.twig", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\models\\symfony\\db_action\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle/Resources/views/Exception/error.js.twig");
    }
}
