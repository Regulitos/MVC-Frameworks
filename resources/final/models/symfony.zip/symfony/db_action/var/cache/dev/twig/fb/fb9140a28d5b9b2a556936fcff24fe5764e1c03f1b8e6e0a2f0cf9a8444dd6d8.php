<?php

/* :clients:index.html.twig */
class __TwigTemplate_1599697ce835356cd5d4e013c4286c3ad46384efc3bf0aeb491d1bf3a00c7632 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_aaddf31223efe66097afb92db073883596518ce266c7a3314cfdfc3380d470b1 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_aaddf31223efe66097afb92db073883596518ce266c7a3314cfdfc3380d470b1->enter($__internal_aaddf31223efe66097afb92db073883596518ce266c7a3314cfdfc3380d470b1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":clients:index.html.twig"));

        $__internal_b80295450b474852f893b51e5a7491b0e11b08a903bd9dc320ab7e39d0581418 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b80295450b474852f893b51e5a7491b0e11b08a903bd9dc320ab7e39d0581418->enter($__internal_b80295450b474852f893b51e5a7491b0e11b08a903bd9dc320ab7e39d0581418_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":clients:index.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html data-whatinput=\"keyboard\" data-whatintent=\"keyboard\" class=\" whatinput-types-initial whatinput-types-keyboard\"><head>
<meta http-equiv=\"content-type\" content=\"text/html; charset=UTF-8\">
        <meta charset=\"UTF-8\">
        <title>PHP MVC Frameworks</title>
            <link rel=\"icon\" type=\"image/x-icon\" href=\"favicon.ico\" />
            <link rel=\"stylesheet\" href=\"";
        // line 7
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/css/foundation.css"), "html", null, true);
        echo "\">
            <link rel=\"stylesheet\" href=\"";
        // line 8
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/css/app.css"), "html", null, true);
        echo "\">
    <meta class=\"foundation-mq\"></head>
    <body>

    <!-- Start Top Bar -->
    <div class=\"top-bar\">
      <div class=\"row\">
        <div class=\"top-bar-left\">
          <ul class=\"dropdown menu\" data-dropdown-menu=\"tckp8q-dropdown-menu\" role=\"menubar\">
            <li role=\"menuitem\">PHP MVC Frameworks</li>
          </ul>
        </div>
      </div>
    </div>
    <!-- End Top Bar -->

    <br>
    
    <div class=\"row\">
      <h4>Index</h4>
      <div class=\"medium-12  columns\">
        <table>
          <tr>
            <th>Name</th>
            <th>Last Name</th>
            <th>Email</th>
            <th width=\"200\">Action</th>
          </tr>
          ";
        // line 36
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["clients"] ?? $this->getContext($context, "clients")));
        foreach ($context['_seq'] as $context["_key"] => $context["client"]) {
            // line 37
            echo "          <tr>
            <td>";
            // line 38
            echo twig_escape_filter($this->env, $this->getAttribute($context["client"], "name", array(), "array"), "html", null, true);
            echo "</td>
            <td>";
            // line 39
            echo twig_escape_filter($this->env, $this->getAttribute($context["client"], "last_name", array(), "array"), "html", null, true);
            echo "</td>
            <td>";
            // line 40
            echo twig_escape_filter($this->env, $this->getAttribute($context["client"], "email", array(), "array"), "html", null, true);
            echo "</td>
            <td><a class=\"button hollow\" href=\"./details.html\">VIEW DETAILS</a></td>
          </tr>
          ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['client'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 44
        echo "        </table>
      </div>
    </div>

    <div class=\"row column\">
      <hr>
      <ul class=\"menu\">
        <li class=\"float-right\">Copyright Footer</li>
      </ul>
    </div>

        <script src=\"";
        // line 55
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("./assets/js/vendor/jquery.js"), "html", null, true);
        echo "\"></script>
        <script src=\"";
        // line 56
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("./assets/js/vendor/what-input.js"), "html", null, true);
        echo "\"></script>
        <script src=\"";
        // line 57
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("./assets/js/vendor/foundation.js"), "html", null, true);
        echo "\"></script>
        <script src=\"";
        // line 58
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("./assets/js/app.js"), "html", null, true);
        echo "\"></script>
    </body>
</html>";
        
        $__internal_aaddf31223efe66097afb92db073883596518ce266c7a3314cfdfc3380d470b1->leave($__internal_aaddf31223efe66097afb92db073883596518ce266c7a3314cfdfc3380d470b1_prof);

        
        $__internal_b80295450b474852f893b51e5a7491b0e11b08a903bd9dc320ab7e39d0581418->leave($__internal_b80295450b474852f893b51e5a7491b0e11b08a903bd9dc320ab7e39d0581418_prof);

    }

    public function getTemplateName()
    {
        return ":clients:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  118 => 58,  114 => 57,  110 => 56,  106 => 55,  93 => 44,  83 => 40,  79 => 39,  75 => 38,  72 => 37,  68 => 36,  37 => 8,  33 => 7,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html data-whatinput=\"keyboard\" data-whatintent=\"keyboard\" class=\" whatinput-types-initial whatinput-types-keyboard\"><head>
<meta http-equiv=\"content-type\" content=\"text/html; charset=UTF-8\">
        <meta charset=\"UTF-8\">
        <title>PHP MVC Frameworks</title>
            <link rel=\"icon\" type=\"image/x-icon\" href=\"favicon.ico\" />
            <link rel=\"stylesheet\" href=\"{{ asset('assets/css/foundation.css') }}\">
            <link rel=\"stylesheet\" href=\"{{ asset('assets/css/app.css') }}\">
    <meta class=\"foundation-mq\"></head>
    <body>

    <!-- Start Top Bar -->
    <div class=\"top-bar\">
      <div class=\"row\">
        <div class=\"top-bar-left\">
          <ul class=\"dropdown menu\" data-dropdown-menu=\"tckp8q-dropdown-menu\" role=\"menubar\">
            <li role=\"menuitem\">PHP MVC Frameworks</li>
          </ul>
        </div>
      </div>
    </div>
    <!-- End Top Bar -->

    <br>
    
    <div class=\"row\">
      <h4>Index</h4>
      <div class=\"medium-12  columns\">
        <table>
          <tr>
            <th>Name</th>
            <th>Last Name</th>
            <th>Email</th>
            <th width=\"200\">Action</th>
          </tr>
          {% for client in clients %}
          <tr>
            <td>{{ client['name'] }}</td>
            <td>{{ client['last_name'] }}</td>
            <td>{{ client['email'] }}</td>
            <td><a class=\"button hollow\" href=\"./details.html\">VIEW DETAILS</a></td>
          </tr>
          {% endfor %}
        </table>
      </div>
    </div>

    <div class=\"row column\">
      <hr>
      <ul class=\"menu\">
        <li class=\"float-right\">Copyright Footer</li>
      </ul>
    </div>

        <script src=\"{{ asset('./assets/js/vendor/jquery.js') }}\"></script>
        <script src=\"{{ asset('./assets/js/vendor/what-input.js') }}\"></script>
        <script src=\"{{ asset('./assets/js/vendor/foundation.js') }}\"></script>
        <script src=\"{{ asset('./assets/js/app.js') }}\"></script>
    </body>
</html>", ":clients:index.html.twig", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\models\\symfony\\db_action\\app/Resources\\views/clients/index.html.twig");
    }
}
