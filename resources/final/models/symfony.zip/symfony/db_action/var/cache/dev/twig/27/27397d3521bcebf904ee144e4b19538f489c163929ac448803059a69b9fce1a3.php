<?php

/* WebProfilerBundle:Profiler:header.html.twig */
class __TwigTemplate_89d2a68971fcc5d03ee9dbc593c55d4277135d64e8e135b4d0e64a77d6423a05 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_79f8c05c1ac56a816adc67b06995f6fdeffe95cd5f10b04a5949aa3531bffea6 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_79f8c05c1ac56a816adc67b06995f6fdeffe95cd5f10b04a5949aa3531bffea6->enter($__internal_79f8c05c1ac56a816adc67b06995f6fdeffe95cd5f10b04a5949aa3531bffea6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:header.html.twig"));

        $__internal_c7f81b1bbab69c571dd9c60c15a2bcdba4ed4446770176554ddc461142b2733a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c7f81b1bbab69c571dd9c60c15a2bcdba4ed4446770176554ddc461142b2733a->enter($__internal_c7f81b1bbab69c571dd9c60c15a2bcdba4ed4446770176554ddc461142b2733a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:header.html.twig"));

        // line 1
        echo "<div id=\"header\">
    <div class=\"container\">
        <h1>";
        // line 3
        echo twig_include($this->env, $context, "@WebProfiler/Icon/symfony.svg");
        echo " Symfony <span>Profiler</span></h1>

        <div class=\"search\">
            <form method=\"get\" action=\"https://symfony.com/search\" target=\"_blank\">
                <div class=\"form-row\">
                    <input name=\"q\" id=\"search-id\" type=\"search\" placeholder=\"search on symfony.com\">
                    <button type=\"submit\" class=\"btn\">Search</button>
                </div>
           </form>
        </div>
    </div>
</div>
";
        
        $__internal_79f8c05c1ac56a816adc67b06995f6fdeffe95cd5f10b04a5949aa3531bffea6->leave($__internal_79f8c05c1ac56a816adc67b06995f6fdeffe95cd5f10b04a5949aa3531bffea6_prof);

        
        $__internal_c7f81b1bbab69c571dd9c60c15a2bcdba4ed4446770176554ddc461142b2733a->leave($__internal_c7f81b1bbab69c571dd9c60c15a2bcdba4ed4446770176554ddc461142b2733a_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:header.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  29 => 3,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div id=\"header\">
    <div class=\"container\">
        <h1>{{ include('@WebProfiler/Icon/symfony.svg') }} Symfony <span>Profiler</span></h1>

        <div class=\"search\">
            <form method=\"get\" action=\"https://symfony.com/search\" target=\"_blank\">
                <div class=\"form-row\">
                    <input name=\"q\" id=\"search-id\" type=\"search\" placeholder=\"search on symfony.com\">
                    <button type=\"submit\" class=\"btn\">Search</button>
                </div>
           </form>
        </div>
    </div>
</div>
", "WebProfilerBundle:Profiler:header.html.twig", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\models\\symfony\\db_action\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle/Resources/views/Profiler/header.html.twig");
    }
}
