<?php

/* @Framework/Form/choice_attributes.html.php */
class __TwigTemplate_082a7da862c6e8763bec466c7e10b27f3ea4498bbe37edd1b2a4c7d01af07aa0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_309a0b88572cf3bb80cb11a523348f1e6c1cc087a8249fd2ebb06a63fb7abfdc = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_309a0b88572cf3bb80cb11a523348f1e6c1cc087a8249fd2ebb06a63fb7abfdc->enter($__internal_309a0b88572cf3bb80cb11a523348f1e6c1cc087a8249fd2ebb06a63fb7abfdc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_attributes.html.php"));

        $__internal_757409557f5bde455186733c1bbacae45d02a2802640c3ea93ffa49ae74644e9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_757409557f5bde455186733c1bbacae45d02a2802640c3ea93ffa49ae74644e9->enter($__internal_757409557f5bde455186733c1bbacae45d02a2802640c3ea93ffa49ae74644e9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_attributes.html.php"));

        // line 1
        echo "<?php if (\$disabled): ?>disabled=\"disabled\" <?php endif ?>
<?php foreach (\$choice_attr as \$k => \$v): ?>
<?php if (\$v === true): ?>
<?php printf('%s=\"%s\" ', \$view->escape(\$k), \$view->escape(\$k)) ?>
<?php elseif (\$v !== false): ?>
<?php printf('%s=\"%s\" ', \$view->escape(\$k), \$view->escape(\$v)) ?>
<?php endif ?>
<?php endforeach ?>
";
        
        $__internal_309a0b88572cf3bb80cb11a523348f1e6c1cc087a8249fd2ebb06a63fb7abfdc->leave($__internal_309a0b88572cf3bb80cb11a523348f1e6c1cc087a8249fd2ebb06a63fb7abfdc_prof);

        
        $__internal_757409557f5bde455186733c1bbacae45d02a2802640c3ea93ffa49ae74644e9->leave($__internal_757409557f5bde455186733c1bbacae45d02a2802640c3ea93ffa49ae74644e9_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/choice_attributes.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (\$disabled): ?>disabled=\"disabled\" <?php endif ?>
<?php foreach (\$choice_attr as \$k => \$v): ?>
<?php if (\$v === true): ?>
<?php printf('%s=\"%s\" ', \$view->escape(\$k), \$view->escape(\$k)) ?>
<?php elseif (\$v !== false): ?>
<?php printf('%s=\"%s\" ', \$view->escape(\$k), \$view->escape(\$v)) ?>
<?php endif ?>
<?php endforeach ?>
", "@Framework/Form/choice_attributes.html.php", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\models\\symfony\\db_action\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\choice_attributes.html.php");
    }
}
