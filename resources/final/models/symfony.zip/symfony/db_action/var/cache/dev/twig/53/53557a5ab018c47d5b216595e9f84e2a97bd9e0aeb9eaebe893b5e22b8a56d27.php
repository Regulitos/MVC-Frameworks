<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_596134ad84a45d3a703ef1c943d6679f4d623e85895794760a3bbcf0e91e4958 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9ec775eaf9d971ca499ca6b20db62ca000a63166018af0295567a5920e9473cc = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9ec775eaf9d971ca499ca6b20db62ca000a63166018af0295567a5920e9473cc->enter($__internal_9ec775eaf9d971ca499ca6b20db62ca000a63166018af0295567a5920e9473cc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $__internal_23bfb40e8255413cb258ae1fdb945611a399f1bc56547b3c8180e1c3065dcc2d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_23bfb40e8255413cb258ae1fdb945611a399f1bc56547b3c8180e1c3065dcc2d->enter($__internal_23bfb40e8255413cb258ae1fdb945611a399f1bc56547b3c8180e1c3065dcc2d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_9ec775eaf9d971ca499ca6b20db62ca000a63166018af0295567a5920e9473cc->leave($__internal_9ec775eaf9d971ca499ca6b20db62ca000a63166018af0295567a5920e9473cc_prof);

        
        $__internal_23bfb40e8255413cb258ae1fdb945611a399f1bc56547b3c8180e1c3065dcc2d->leave($__internal_23bfb40e8255413cb258ae1fdb945611a399f1bc56547b3c8180e1c3065dcc2d_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_7f3f90a793055b4f84cb8c332ec420726d420bb8d89b01d31e471697d0f4767e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_7f3f90a793055b4f84cb8c332ec420726d420bb8d89b01d31e471697d0f4767e->enter($__internal_7f3f90a793055b4f84cb8c332ec420726d420bb8d89b01d31e471697d0f4767e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        $__internal_906009e5c3fb4d9e27e646614d25b281db347381f20cc13b6b1e06687783637e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_906009e5c3fb4d9e27e646614d25b281db347381f20cc13b6b1e06687783637e->enter($__internal_906009e5c3fb4d9e27e646614d25b281db347381f20cc13b6b1e06687783637e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_906009e5c3fb4d9e27e646614d25b281db347381f20cc13b6b1e06687783637e->leave($__internal_906009e5c3fb4d9e27e646614d25b281db347381f20cc13b6b1e06687783637e_prof);

        
        $__internal_7f3f90a793055b4f84cb8c332ec420726d420bb8d89b01d31e471697d0f4767e->leave($__internal_7f3f90a793055b4f84cb8c332ec420726d420bb8d89b01d31e471697d0f4767e_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_e1683ea0ea26aaf91e709cabab551a425510d8bf2a740aa5693a972c440ab5af = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e1683ea0ea26aaf91e709cabab551a425510d8bf2a740aa5693a972c440ab5af->enter($__internal_e1683ea0ea26aaf91e709cabab551a425510d8bf2a740aa5693a972c440ab5af_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_aba3fd0d32e2f3b17bd65f6cf0b75cbfee67c12338f706c52eda21b8a9eef129 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_aba3fd0d32e2f3b17bd65f6cf0b75cbfee67c12338f706c52eda21b8a9eef129->enter($__internal_aba3fd0d32e2f3b17bd65f6cf0b75cbfee67c12338f706c52eda21b8a9eef129_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_aba3fd0d32e2f3b17bd65f6cf0b75cbfee67c12338f706c52eda21b8a9eef129->leave($__internal_aba3fd0d32e2f3b17bd65f6cf0b75cbfee67c12338f706c52eda21b8a9eef129_prof);

        
        $__internal_e1683ea0ea26aaf91e709cabab551a425510d8bf2a740aa5693a972c440ab5af->leave($__internal_e1683ea0ea26aaf91e709cabab551a425510d8bf2a740aa5693a972c440ab5af_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_c2d70d94f17a134799459c335ccf1a99959cc7e469e44c3c90b5456bf76313da = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c2d70d94f17a134799459c335ccf1a99959cc7e469e44c3c90b5456bf76313da->enter($__internal_c2d70d94f17a134799459c335ccf1a99959cc7e469e44c3c90b5456bf76313da_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_4ebfbba9df2b4f4bc6838805e83c1e084b8b0684b3e4c170be2ce04842a60620 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4ebfbba9df2b4f4bc6838805e83c1e084b8b0684b3e4c170be2ce04842a60620->enter($__internal_4ebfbba9df2b4f4bc6838805e83c1e084b8b0684b3e4c170be2ce04842a60620_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_4ebfbba9df2b4f4bc6838805e83c1e084b8b0684b3e4c170be2ce04842a60620->leave($__internal_4ebfbba9df2b4f4bc6838805e83c1e084b8b0684b3e4c170be2ce04842a60620_prof);

        
        $__internal_c2d70d94f17a134799459c335ccf1a99959cc7e469e44c3c90b5456bf76313da->leave($__internal_c2d70d94f17a134799459c335ccf1a99959cc7e469e44c3c90b5456bf76313da_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  94 => 13,  85 => 12,  71 => 7,  68 => 6,  59 => 5,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
", "@WebProfiler/Collector/router.html.twig", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\models\\symfony\\db_action\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Collector\\router.html.twig");
    }
}
