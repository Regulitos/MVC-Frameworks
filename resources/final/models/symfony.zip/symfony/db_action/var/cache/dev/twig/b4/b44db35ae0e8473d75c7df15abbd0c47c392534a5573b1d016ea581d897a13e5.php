<?php

/* TwigBundle::layout.html.twig */
class __TwigTemplate_2d509e6ad301fe6c22bef0d2697765bc7dd0afcf1211ec0f9c9417c65f3a01cd extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'head' => array($this, 'block_head'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_99003b13411db94aa7eb9a633af84231bbe1794bfd09c4250097fb84da3cc386 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_99003b13411db94aa7eb9a633af84231bbe1794bfd09c4250097fb84da3cc386->enter($__internal_99003b13411db94aa7eb9a633af84231bbe1794bfd09c4250097fb84da3cc386_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle::layout.html.twig"));

        $__internal_36a83b064e302a78abc54bd4f4eb83f1054fb6c1add2d5edbcefe85a3882e34a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_36a83b064e302a78abc54bd4f4eb83f1054fb6c1add2d5edbcefe85a3882e34a->enter($__internal_36a83b064e302a78abc54bd4f4eb83f1054fb6c1add2d5edbcefe85a3882e34a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle::layout.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"";
        // line 4
        echo twig_escape_filter($this->env, $this->env->getCharset(), "html", null, true);
        echo "\" />
        <meta name=\"robots\" content=\"noindex,nofollow\" />
        <meta name=\"viewport\" content=\"width=device-width,initial-scale=1\" />
        <title>";
        // line 7
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        <link rel=\"icon\" type=\"image/png\" href=\"";
        // line 8
        echo twig_include($this->env, $context, "@Twig/images/favicon.png.base64");
        echo "\">
        <style>";
        // line 9
        echo twig_include($this->env, $context, "@Twig/exception.css.twig");
        echo "</style>
        ";
        // line 10
        $this->displayBlock('head', $context, $blocks);
        // line 11
        echo "    </head>
    <body>
        <header>
            <div class=\"container\">
                <h1 class=\"logo\">";
        // line 15
        echo twig_include($this->env, $context, "@Twig/images/symfony-logo.svg");
        echo " Symfony Exception</h1>

                <div class=\"help-link\">
                    <a href=\"https://symfony.com/doc\">
                        <span class=\"icon\">";
        // line 19
        echo twig_include($this->env, $context, "@Twig/images/icon-book.svg");
        echo "</span>
                        <span class=\"hidden-xs-down\">Symfony</span> Docs
                    </a>
                </div>

                <div class=\"help-link\">
                    <a href=\"https://symfony.com/support\">
                        <span class=\"icon\">";
        // line 26
        echo twig_include($this->env, $context, "@Twig/images/icon-support.svg");
        echo "</span>
                        <span class=\"hidden-xs-down\">Symfony</span> Support
                    </a>
                </div>
            </div>
        </header>

        ";
        // line 33
        $this->displayBlock('body', $context, $blocks);
        // line 34
        echo "        ";
        echo twig_include($this->env, $context, "@Twig/base_js.html.twig");
        echo "
    </body>
</html>
";
        
        $__internal_99003b13411db94aa7eb9a633af84231bbe1794bfd09c4250097fb84da3cc386->leave($__internal_99003b13411db94aa7eb9a633af84231bbe1794bfd09c4250097fb84da3cc386_prof);

        
        $__internal_36a83b064e302a78abc54bd4f4eb83f1054fb6c1add2d5edbcefe85a3882e34a->leave($__internal_36a83b064e302a78abc54bd4f4eb83f1054fb6c1add2d5edbcefe85a3882e34a_prof);

    }

    // line 7
    public function block_title($context, array $blocks = array())
    {
        $__internal_6b4d02fe1d82f8e6c01e6586de3f548f7631fdcb9026b69a76ff782aeadf7dde = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6b4d02fe1d82f8e6c01e6586de3f548f7631fdcb9026b69a76ff782aeadf7dde->enter($__internal_6b4d02fe1d82f8e6c01e6586de3f548f7631fdcb9026b69a76ff782aeadf7dde_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_9d8022a00aff15d3a25a78c34b4333f767d316485c64150c6cd29f5944cc65c0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9d8022a00aff15d3a25a78c34b4333f767d316485c64150c6cd29f5944cc65c0->enter($__internal_9d8022a00aff15d3a25a78c34b4333f767d316485c64150c6cd29f5944cc65c0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        
        $__internal_9d8022a00aff15d3a25a78c34b4333f767d316485c64150c6cd29f5944cc65c0->leave($__internal_9d8022a00aff15d3a25a78c34b4333f767d316485c64150c6cd29f5944cc65c0_prof);

        
        $__internal_6b4d02fe1d82f8e6c01e6586de3f548f7631fdcb9026b69a76ff782aeadf7dde->leave($__internal_6b4d02fe1d82f8e6c01e6586de3f548f7631fdcb9026b69a76ff782aeadf7dde_prof);

    }

    // line 10
    public function block_head($context, array $blocks = array())
    {
        $__internal_8b5f67b8d49ed2e28571a0504fb18b68ba845a73e414677134a195b6026be029 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8b5f67b8d49ed2e28571a0504fb18b68ba845a73e414677134a195b6026be029->enter($__internal_8b5f67b8d49ed2e28571a0504fb18b68ba845a73e414677134a195b6026be029_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        $__internal_7c6526350090bd2c4fa98166abf5aa8a80742edb7f3e8a06c28f5e7e07052c11 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7c6526350090bd2c4fa98166abf5aa8a80742edb7f3e8a06c28f5e7e07052c11->enter($__internal_7c6526350090bd2c4fa98166abf5aa8a80742edb7f3e8a06c28f5e7e07052c11_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        
        $__internal_7c6526350090bd2c4fa98166abf5aa8a80742edb7f3e8a06c28f5e7e07052c11->leave($__internal_7c6526350090bd2c4fa98166abf5aa8a80742edb7f3e8a06c28f5e7e07052c11_prof);

        
        $__internal_8b5f67b8d49ed2e28571a0504fb18b68ba845a73e414677134a195b6026be029->leave($__internal_8b5f67b8d49ed2e28571a0504fb18b68ba845a73e414677134a195b6026be029_prof);

    }

    // line 33
    public function block_body($context, array $blocks = array())
    {
        $__internal_96f0fc301f7188c81dc976532a078cb556b31ea6dc0066b11e0231a504606bcb = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_96f0fc301f7188c81dc976532a078cb556b31ea6dc0066b11e0231a504606bcb->enter($__internal_96f0fc301f7188c81dc976532a078cb556b31ea6dc0066b11e0231a504606bcb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_316432227ee50a9040b3b35c33a85fd90841c520d80167c402b2049fbb45670e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_316432227ee50a9040b3b35c33a85fd90841c520d80167c402b2049fbb45670e->enter($__internal_316432227ee50a9040b3b35c33a85fd90841c520d80167c402b2049fbb45670e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_316432227ee50a9040b3b35c33a85fd90841c520d80167c402b2049fbb45670e->leave($__internal_316432227ee50a9040b3b35c33a85fd90841c520d80167c402b2049fbb45670e_prof);

        
        $__internal_96f0fc301f7188c81dc976532a078cb556b31ea6dc0066b11e0231a504606bcb->leave($__internal_96f0fc301f7188c81dc976532a078cb556b31ea6dc0066b11e0231a504606bcb_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle::layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  137 => 33,  120 => 10,  103 => 7,  88 => 34,  86 => 33,  76 => 26,  66 => 19,  59 => 15,  53 => 11,  51 => 10,  47 => 9,  43 => 8,  39 => 7,  33 => 4,  28 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"{{ _charset }}\" />
        <meta name=\"robots\" content=\"noindex,nofollow\" />
        <meta name=\"viewport\" content=\"width=device-width,initial-scale=1\" />
        <title>{% block title %}{% endblock %}</title>
        <link rel=\"icon\" type=\"image/png\" href=\"{{ include('@Twig/images/favicon.png.base64') }}\">
        <style>{{ include('@Twig/exception.css.twig') }}</style>
        {% block head %}{% endblock %}
    </head>
    <body>
        <header>
            <div class=\"container\">
                <h1 class=\"logo\">{{ include('@Twig/images/symfony-logo.svg') }} Symfony Exception</h1>

                <div class=\"help-link\">
                    <a href=\"https://symfony.com/doc\">
                        <span class=\"icon\">{{ include('@Twig/images/icon-book.svg') }}</span>
                        <span class=\"hidden-xs-down\">Symfony</span> Docs
                    </a>
                </div>

                <div class=\"help-link\">
                    <a href=\"https://symfony.com/support\">
                        <span class=\"icon\">{{ include('@Twig/images/icon-support.svg') }}</span>
                        <span class=\"hidden-xs-down\">Symfony</span> Support
                    </a>
                </div>
            </div>
        </header>

        {% block body %}{% endblock %}
        {{ include('@Twig/base_js.html.twig') }}
    </body>
</html>
", "TwigBundle::layout.html.twig", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\models\\symfony\\db_action\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle/Resources/views/layout.html.twig");
    }
}
