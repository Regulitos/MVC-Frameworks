<?php

/* @Framework/Form/checkbox_widget.html.php */
class __TwigTemplate_a3c36fc58f37ab307b316d6acb0f9c0c5b3e7fd05ca49c161cb826e93a96e683 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9cc57317c40cccf84e19f900527d5ced20732185ad177788d8ce4f7be4e2bfb3 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9cc57317c40cccf84e19f900527d5ced20732185ad177788d8ce4f7be4e2bfb3->enter($__internal_9cc57317c40cccf84e19f900527d5ced20732185ad177788d8ce4f7be4e2bfb3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/checkbox_widget.html.php"));

        $__internal_5144c080df3ec5940fdc6852a15fe8418e09957d42a5bf93b5895747d1ed0e17 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5144c080df3ec5940fdc6852a15fe8418e09957d42a5bf93b5895747d1ed0e17->enter($__internal_5144c080df3ec5940fdc6852a15fe8418e09957d42a5bf93b5895747d1ed0e17_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/checkbox_widget.html.php"));

        // line 1
        echo "<input type=\"checkbox\"
    <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
    <?php if (strlen(\$value) > 0): ?> value=\"<?php echo \$view->escape(\$value) ?>\"<?php endif ?>
    <?php if (\$checked): ?> checked=\"checked\"<?php endif ?>
/>
";
        
        $__internal_9cc57317c40cccf84e19f900527d5ced20732185ad177788d8ce4f7be4e2bfb3->leave($__internal_9cc57317c40cccf84e19f900527d5ced20732185ad177788d8ce4f7be4e2bfb3_prof);

        
        $__internal_5144c080df3ec5940fdc6852a15fe8418e09957d42a5bf93b5895747d1ed0e17->leave($__internal_5144c080df3ec5940fdc6852a15fe8418e09957d42a5bf93b5895747d1ed0e17_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/checkbox_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<input type=\"checkbox\"
    <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
    <?php if (strlen(\$value) > 0): ?> value=\"<?php echo \$view->escape(\$value) ?>\"<?php endif ?>
    <?php if (\$checked): ?> checked=\"checked\"<?php endif ?>
/>
", "@Framework/Form/checkbox_widget.html.php", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\models\\symfony\\db_action\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\checkbox_widget.html.php");
    }
}
