<?php

/* TwigBundle:Exception:error.json.twig */
class __TwigTemplate_3a010ab51691f963c8a75573053e9d8771d909b3dd7c9b14dbdd21839e35835b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_db56777f5168c028279c5a67de94e334f1cc485d7226a8280a0796f17c5389bc = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_db56777f5168c028279c5a67de94e334f1cc485d7226a8280a0796f17c5389bc->enter($__internal_db56777f5168c028279c5a67de94e334f1cc485d7226a8280a0796f17c5389bc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.json.twig"));

        $__internal_dc6a73eef6e58e2a3e712fa94e66bfc278fc3f1da2c0f76ea3ad1a9eb01179a2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_dc6a73eef6e58e2a3e712fa94e66bfc278fc3f1da2c0f76ea3ad1a9eb01179a2->enter($__internal_dc6a73eef6e58e2a3e712fa94e66bfc278fc3f1da2c0f76ea3ad1a9eb01179a2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.json.twig"));

        // line 1
        echo twig_jsonencode_filter(array("error" => array("code" => ($context["status_code"] ?? $this->getContext($context, "status_code")), "message" => ($context["status_text"] ?? $this->getContext($context, "status_text")))));
        echo "
";
        
        $__internal_db56777f5168c028279c5a67de94e334f1cc485d7226a8280a0796f17c5389bc->leave($__internal_db56777f5168c028279c5a67de94e334f1cc485d7226a8280a0796f17c5389bc_prof);

        
        $__internal_dc6a73eef6e58e2a3e712fa94e66bfc278fc3f1da2c0f76ea3ad1a9eb01179a2->leave($__internal_dc6a73eef6e58e2a3e712fa94e66bfc278fc3f1da2c0f76ea3ad1a9eb01179a2_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.json.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ { 'error': { 'code': status_code, 'message': status_text } }|json_encode|raw }}
", "TwigBundle:Exception:error.json.twig", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\models\\symfony\\db_action\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle/Resources/views/Exception/error.json.twig");
    }
}
