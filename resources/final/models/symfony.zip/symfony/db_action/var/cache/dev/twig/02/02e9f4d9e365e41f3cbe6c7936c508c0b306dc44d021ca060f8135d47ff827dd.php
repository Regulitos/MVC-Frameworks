<?php

/* @Twig/Exception/error.atom.twig */
class __TwigTemplate_6ae93012740d9831bf45d8eec53ec090b960cb14574cd72bfce0d741960b659b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b087ec2084b9e7c9a6c40896db7cca8d809d7b92048adf5d514f2b976a333abc = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b087ec2084b9e7c9a6c40896db7cca8d809d7b92048adf5d514f2b976a333abc->enter($__internal_b087ec2084b9e7c9a6c40896db7cca8d809d7b92048adf5d514f2b976a333abc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.atom.twig"));

        $__internal_454d887d3b556131e66edfeba6421f4e8ed7a11ad91b2d91d0cbb820c570e090 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_454d887d3b556131e66edfeba6421f4e8ed7a11ad91b2d91d0cbb820c570e090->enter($__internal_454d887d3b556131e66edfeba6421f4e8ed7a11ad91b2d91d0cbb820c570e090_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.atom.twig"));

        // line 1
        echo twig_include($this->env, $context, "@Twig/Exception/error.xml.twig");
        echo "
";
        
        $__internal_b087ec2084b9e7c9a6c40896db7cca8d809d7b92048adf5d514f2b976a333abc->leave($__internal_b087ec2084b9e7c9a6c40896db7cca8d809d7b92048adf5d514f2b976a333abc_prof);

        
        $__internal_454d887d3b556131e66edfeba6421f4e8ed7a11ad91b2d91d0cbb820c570e090->leave($__internal_454d887d3b556131e66edfeba6421f4e8ed7a11ad91b2d91d0cbb820c570e090_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/error.atom.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ include('@Twig/Exception/error.xml.twig') }}
", "@Twig/Exception/error.atom.twig", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\models\\symfony\\db_action\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\error.atom.twig");
    }
}
