<?php

/* @Framework/Form/form_widget_compound.html.php */
class __TwigTemplate_48da2b5a70dd8ebee4b5b00a21f4d66683f9829510a8297a84b97358b3a1d54d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c1945aa8f9c482a9f90d66a9c8fbea1738bb012e60c9722fb52b8ab2d7433ac8 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c1945aa8f9c482a9f90d66a9c8fbea1738bb012e60c9722fb52b8ab2d7433ac8->enter($__internal_c1945aa8f9c482a9f90d66a9c8fbea1738bb012e60c9722fb52b8ab2d7433ac8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget_compound.html.php"));

        $__internal_e13896a47cfb74a9c3f995dc94904a3bf1b38485d1926e38dcc64ed8e17a5ff0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e13896a47cfb74a9c3f995dc94904a3bf1b38485d1926e38dcc64ed8e17a5ff0->enter($__internal_e13896a47cfb74a9c3f995dc94904a3bf1b38485d1926e38dcc64ed8e17a5ff0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget_compound.html.php"));

        // line 1
        echo "<div <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
    <?php if (!\$form->parent && \$errors): ?>
    <?php echo \$view['form']->errors(\$form) ?>
    <?php endif ?>
    <?php echo \$view['form']->block(\$form, 'form_rows') ?>
    <?php echo \$view['form']->rest(\$form) ?>
</div>
";
        
        $__internal_c1945aa8f9c482a9f90d66a9c8fbea1738bb012e60c9722fb52b8ab2d7433ac8->leave($__internal_c1945aa8f9c482a9f90d66a9c8fbea1738bb012e60c9722fb52b8ab2d7433ac8_prof);

        
        $__internal_e13896a47cfb74a9c3f995dc94904a3bf1b38485d1926e38dcc64ed8e17a5ff0->leave($__internal_e13896a47cfb74a9c3f995dc94904a3bf1b38485d1926e38dcc64ed8e17a5ff0_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_widget_compound.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
    <?php if (!\$form->parent && \$errors): ?>
    <?php echo \$view['form']->errors(\$form) ?>
    <?php endif ?>
    <?php echo \$view['form']->block(\$form, 'form_rows') ?>
    <?php echo \$view['form']->rest(\$form) ?>
</div>
", "@Framework/Form/form_widget_compound.html.php", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\models\\symfony\\db_action\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\form_widget_compound.html.php");
    }
}
