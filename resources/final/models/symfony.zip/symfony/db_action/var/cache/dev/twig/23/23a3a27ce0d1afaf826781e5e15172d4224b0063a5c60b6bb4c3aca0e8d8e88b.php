<?php

/* TwigBundle:Exception:error.css.twig */
class __TwigTemplate_976ddc88dc6308d2caf5003750c021392fd3ae543a78794585911c3a52c5f7a2 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9f3aea6a5c4d128603b1f1065d8a34ecf54ef21171495e206732b46d5456f280 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9f3aea6a5c4d128603b1f1065d8a34ecf54ef21171495e206732b46d5456f280->enter($__internal_9f3aea6a5c4d128603b1f1065d8a34ecf54ef21171495e206732b46d5456f280_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.css.twig"));

        $__internal_eeb2a4c7ee2e447d24c51d170113f9a77165292323c12600bf58850ad93960cb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_eeb2a4c7ee2e447d24c51d170113f9a77165292323c12600bf58850ad93960cb->enter($__internal_eeb2a4c7ee2e447d24c51d170113f9a77165292323c12600bf58850ad93960cb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.css.twig"));

        // line 1
        echo "/*
";
        // line 2
        echo twig_escape_filter($this->env, ($context["status_code"] ?? $this->getContext($context, "status_code")), "css", null, true);
        echo " ";
        echo twig_escape_filter($this->env, ($context["status_text"] ?? $this->getContext($context, "status_text")), "css", null, true);
        echo "

*/
";
        
        $__internal_9f3aea6a5c4d128603b1f1065d8a34ecf54ef21171495e206732b46d5456f280->leave($__internal_9f3aea6a5c4d128603b1f1065d8a34ecf54ef21171495e206732b46d5456f280_prof);

        
        $__internal_eeb2a4c7ee2e447d24c51d170113f9a77165292323c12600bf58850ad93960cb->leave($__internal_eeb2a4c7ee2e447d24c51d170113f9a77165292323c12600bf58850ad93960cb_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.css.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  28 => 2,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("/*
{{ status_code }} {{ status_text }}

*/
", "TwigBundle:Exception:error.css.twig", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\models\\symfony\\db_action\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle/Resources/views/Exception/error.css.twig");
    }
}
