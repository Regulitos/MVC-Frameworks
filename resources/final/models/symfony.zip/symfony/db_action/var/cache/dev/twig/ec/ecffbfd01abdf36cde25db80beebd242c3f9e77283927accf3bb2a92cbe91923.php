<?php

/* @Framework/Form/button_row.html.php */
class __TwigTemplate_4b4bd3d6de7e2c90f067551787e44c1ef8d1bb38215839af9898f50ab5c0c5c1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_77996ad6f61ecaa1636e29df79482210adec0b7655f238ad19e33c0e90504c87 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_77996ad6f61ecaa1636e29df79482210adec0b7655f238ad19e33c0e90504c87->enter($__internal_77996ad6f61ecaa1636e29df79482210adec0b7655f238ad19e33c0e90504c87_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_row.html.php"));

        $__internal_4249c182a6790e9f2e6f4e0e3bf3ab3928f58b88582c6d38f941833a09afcf64 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4249c182a6790e9f2e6f4e0e3bf3ab3928f58b88582c6d38f941833a09afcf64->enter($__internal_4249c182a6790e9f2e6f4e0e3bf3ab3928f58b88582c6d38f941833a09afcf64_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_row.html.php"));

        // line 1
        echo "<div>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
";
        
        $__internal_77996ad6f61ecaa1636e29df79482210adec0b7655f238ad19e33c0e90504c87->leave($__internal_77996ad6f61ecaa1636e29df79482210adec0b7655f238ad19e33c0e90504c87_prof);

        
        $__internal_4249c182a6790e9f2e6f4e0e3bf3ab3928f58b88582c6d38f941833a09afcf64->leave($__internal_4249c182a6790e9f2e6f4e0e3bf3ab3928f58b88582c6d38f941833a09afcf64_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
", "@Framework/Form/button_row.html.php", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\models\\symfony\\db_action\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\button_row.html.php");
    }
}
