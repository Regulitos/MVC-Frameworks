<?php

/* @Twig/Exception/exception.rdf.twig */
class __TwigTemplate_8ab05884ce77ab2e1c1ed14109329ea8e655221064619f629c2594bb424171b5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_be395b7c57379c09daf88f4b5e71b089e613694616ffdf7ae23655eafbfb3362 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_be395b7c57379c09daf88f4b5e71b089e613694616ffdf7ae23655eafbfb3362->enter($__internal_be395b7c57379c09daf88f4b5e71b089e613694616ffdf7ae23655eafbfb3362_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.rdf.twig"));

        $__internal_911b5dfdf698a3dc85491cba0388fd26017c4a99225bf41f2f4f6068cb0031d2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_911b5dfdf698a3dc85491cba0388fd26017c4a99225bf41f2f4f6068cb0031d2->enter($__internal_911b5dfdf698a3dc85491cba0388fd26017c4a99225bf41f2f4f6068cb0031d2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.rdf.twig"));

        // line 1
        echo twig_include($this->env, $context, "@Twig/Exception/exception.xml.twig", array("exception" => ($context["exception"] ?? $this->getContext($context, "exception"))));
        echo "
";
        
        $__internal_be395b7c57379c09daf88f4b5e71b089e613694616ffdf7ae23655eafbfb3362->leave($__internal_be395b7c57379c09daf88f4b5e71b089e613694616ffdf7ae23655eafbfb3362_prof);

        
        $__internal_911b5dfdf698a3dc85491cba0388fd26017c4a99225bf41f2f4f6068cb0031d2->leave($__internal_911b5dfdf698a3dc85491cba0388fd26017c4a99225bf41f2f4f6068cb0031d2_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/exception.rdf.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ include('@Twig/Exception/exception.xml.twig', { exception: exception }) }}
", "@Twig/Exception/exception.rdf.twig", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\models\\symfony\\db_action\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\exception.rdf.twig");
    }
}
