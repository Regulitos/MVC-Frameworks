<?php

/* @Framework/Form/form_widget_simple.html.php */
class __TwigTemplate_1a47a875b481b077d24b2f8041c95c21f77eb5288a91f7d91fc70f7c07ee4ab0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8543adb4609924915c745b00c0c6a54dc30653c80184bf3494328e7a9f965356 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8543adb4609924915c745b00c0c6a54dc30653c80184bf3494328e7a9f965356->enter($__internal_8543adb4609924915c745b00c0c6a54dc30653c80184bf3494328e7a9f965356_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget_simple.html.php"));

        $__internal_bf40903077b8019c943092ccaa67436d4b3d405ceaf8833d53af0a8fd84e2c7d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_bf40903077b8019c943092ccaa67436d4b3d405ceaf8833d53af0a8fd84e2c7d->enter($__internal_bf40903077b8019c943092ccaa67436d4b3d405ceaf8833d53af0a8fd84e2c7d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget_simple.html.php"));

        // line 1
        echo "<input type=\"<?php echo isset(\$type) ? \$view->escape(\$type) : 'text' ?>\" <?php echo \$view['form']->block(\$form, 'widget_attributes') ?><?php if (!empty(\$value) || is_numeric(\$value)): ?> value=\"<?php echo \$view->escape(\$value) ?>\"<?php endif ?> />
";
        
        $__internal_8543adb4609924915c745b00c0c6a54dc30653c80184bf3494328e7a9f965356->leave($__internal_8543adb4609924915c745b00c0c6a54dc30653c80184bf3494328e7a9f965356_prof);

        
        $__internal_bf40903077b8019c943092ccaa67436d4b3d405ceaf8833d53af0a8fd84e2c7d->leave($__internal_bf40903077b8019c943092ccaa67436d4b3d405ceaf8833d53af0a8fd84e2c7d_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_widget_simple.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<input type=\"<?php echo isset(\$type) ? \$view->escape(\$type) : 'text' ?>\" <?php echo \$view['form']->block(\$form, 'widget_attributes') ?><?php if (!empty(\$value) || is_numeric(\$value)): ?> value=\"<?php echo \$view->escape(\$value) ?>\"<?php endif ?> />
", "@Framework/Form/form_widget_simple.html.php", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\models\\symfony\\db_action\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\form_widget_simple.html.php");
    }
}
