<?php

namespace AppBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Component\HttpFoundation\Response;
use Doctrine\ORM\EntityManagerInterface;


class ClientsController extends Controller
{
   
    /**
     * @Route("/clients", name="client_index")
     */
    public function clientIndex( EntityManagerInterface $em )
    {
        //return new Response('New Controller method index');
        $clients = $em  ->getRepository( 'AppBundle:Client' )
                        ->findAll();
        return $this->render('clients/index.html.twig', [ 'clients' => $clients ]);
    }

    /**
     * @Route("/clients/{id}", name="client_details")
     */
    public function clientDetails($id,  EntityManagerInterface $em)
    {
        //return new Response('Id: ' . $id);
        $clients = $em  ->getRepository( 'AppBundle:Client' )
                        ->find($id);
        return $this->render('clients/details.html.twig', [ 'client' => $clients ]);
    }
}
