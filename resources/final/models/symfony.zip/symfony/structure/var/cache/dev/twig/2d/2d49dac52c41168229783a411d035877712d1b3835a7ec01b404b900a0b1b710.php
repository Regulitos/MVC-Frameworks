<?php

/* @Twig/Exception/exception.js.twig */
class __TwigTemplate_503a724b00859d73420ea91e59716c8bb8214c1a5e6126e48cf929e0c700f40e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9d4e8a3eef024d9b5eaa2236d345c1a375aee4b0f07f56694d39f6c3280091f4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9d4e8a3eef024d9b5eaa2236d345c1a375aee4b0f07f56694d39f6c3280091f4->enter($__internal_9d4e8a3eef024d9b5eaa2236d345c1a375aee4b0f07f56694d39f6c3280091f4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.js.twig"));

        $__internal_fbde25bf07781c10bdd1afd81ee8b5fc746ea75e342719bf11bd0d3c8bdf9d9d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fbde25bf07781c10bdd1afd81ee8b5fc746ea75e342719bf11bd0d3c8bdf9d9d->enter($__internal_fbde25bf07781c10bdd1afd81ee8b5fc746ea75e342719bf11bd0d3c8bdf9d9d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.js.twig"));

        // line 1
        echo "/*
";
        // line 2
        echo twig_include($this->env, $context, "@Twig/Exception/exception.txt.twig", array("exception" => ($context["exception"] ?? $this->getContext($context, "exception"))));
        echo "
*/
";
        
        $__internal_9d4e8a3eef024d9b5eaa2236d345c1a375aee4b0f07f56694d39f6c3280091f4->leave($__internal_9d4e8a3eef024d9b5eaa2236d345c1a375aee4b0f07f56694d39f6c3280091f4_prof);

        
        $__internal_fbde25bf07781c10bdd1afd81ee8b5fc746ea75e342719bf11bd0d3c8bdf9d9d->leave($__internal_fbde25bf07781c10bdd1afd81ee8b5fc746ea75e342719bf11bd0d3c8bdf9d9d_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/exception.js.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  28 => 2,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("/*
{{ include('@Twig/Exception/exception.txt.twig', { exception: exception }) }}
*/
", "@Twig/Exception/exception.js.twig", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\models\\symfony\\structure\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\exception.js.twig");
    }
}
