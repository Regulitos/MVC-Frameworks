<?php

/* @Twig/Exception/error.atom.twig */
class __TwigTemplate_6ae93012740d9831bf45d8eec53ec090b960cb14574cd72bfce0d741960b659b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_995a244f701823f70a4e096518c47295fc6934fa751a1ccbe8ab817400c63e87 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_995a244f701823f70a4e096518c47295fc6934fa751a1ccbe8ab817400c63e87->enter($__internal_995a244f701823f70a4e096518c47295fc6934fa751a1ccbe8ab817400c63e87_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.atom.twig"));

        $__internal_93ebc7da4155b9c757e1b6e804582298570d0bf6adbeeb53dc89cd6ce977ae98 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_93ebc7da4155b9c757e1b6e804582298570d0bf6adbeeb53dc89cd6ce977ae98->enter($__internal_93ebc7da4155b9c757e1b6e804582298570d0bf6adbeeb53dc89cd6ce977ae98_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.atom.twig"));

        // line 1
        echo twig_include($this->env, $context, "@Twig/Exception/error.xml.twig");
        echo "
";
        
        $__internal_995a244f701823f70a4e096518c47295fc6934fa751a1ccbe8ab817400c63e87->leave($__internal_995a244f701823f70a4e096518c47295fc6934fa751a1ccbe8ab817400c63e87_prof);

        
        $__internal_93ebc7da4155b9c757e1b6e804582298570d0bf6adbeeb53dc89cd6ce977ae98->leave($__internal_93ebc7da4155b9c757e1b6e804582298570d0bf6adbeeb53dc89cd6ce977ae98_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/error.atom.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ include('@Twig/Exception/error.xml.twig') }}
", "@Twig/Exception/error.atom.twig", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\models\\symfony\\structure\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\error.atom.twig");
    }
}
