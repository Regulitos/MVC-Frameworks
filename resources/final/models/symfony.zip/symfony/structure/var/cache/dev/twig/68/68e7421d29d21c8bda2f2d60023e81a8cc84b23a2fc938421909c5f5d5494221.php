<?php

/* TwigBundle:Exception:exception.atom.twig */
class __TwigTemplate_8bad279752edf5670e2ecf0b4208dbc1dd1c3e31e9889cff1243f386cedd9af0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_655ca9533dd79c8d701b05b87099eccdd0183a9a99c9cafae4c8e739da75bc9a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_655ca9533dd79c8d701b05b87099eccdd0183a9a99c9cafae4c8e739da75bc9a->enter($__internal_655ca9533dd79c8d701b05b87099eccdd0183a9a99c9cafae4c8e739da75bc9a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.atom.twig"));

        $__internal_be34fc4cc9619e1a2b50ade29d60fdb1e12052b4b80bfd9b8e52e6ca841d5bb5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_be34fc4cc9619e1a2b50ade29d60fdb1e12052b4b80bfd9b8e52e6ca841d5bb5->enter($__internal_be34fc4cc9619e1a2b50ade29d60fdb1e12052b4b80bfd9b8e52e6ca841d5bb5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.atom.twig"));

        // line 1
        echo twig_include($this->env, $context, "@Twig/Exception/exception.xml.twig", array("exception" => ($context["exception"] ?? $this->getContext($context, "exception"))));
        echo "
";
        
        $__internal_655ca9533dd79c8d701b05b87099eccdd0183a9a99c9cafae4c8e739da75bc9a->leave($__internal_655ca9533dd79c8d701b05b87099eccdd0183a9a99c9cafae4c8e739da75bc9a_prof);

        
        $__internal_be34fc4cc9619e1a2b50ade29d60fdb1e12052b4b80bfd9b8e52e6ca841d5bb5->leave($__internal_be34fc4cc9619e1a2b50ade29d60fdb1e12052b4b80bfd9b8e52e6ca841d5bb5_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.atom.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ include('@Twig/Exception/exception.xml.twig', { exception: exception }) }}
", "TwigBundle:Exception:exception.atom.twig", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\models\\symfony\\structure\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle/Resources/views/Exception/exception.atom.twig");
    }
}
