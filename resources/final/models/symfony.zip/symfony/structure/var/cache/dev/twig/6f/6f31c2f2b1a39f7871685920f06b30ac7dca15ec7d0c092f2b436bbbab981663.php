<?php

/* @Framework/Form/form_widget.html.php */
class __TwigTemplate_d572ad79cf07edcbf04f8519722e71bda34fbd095c29299224d58fd7eb57d90d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_131b606d70effb65e39a9fcd8de9c40a9d22563d9d70efea4004929b8d936b3d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_131b606d70effb65e39a9fcd8de9c40a9d22563d9d70efea4004929b8d936b3d->enter($__internal_131b606d70effb65e39a9fcd8de9c40a9d22563d9d70efea4004929b8d936b3d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget.html.php"));

        $__internal_a14e4e6429423763ba99016ecbfe965daebfb747f24bdd8e97158147e749dce5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a14e4e6429423763ba99016ecbfe965daebfb747f24bdd8e97158147e749dce5->enter($__internal_a14e4e6429423763ba99016ecbfe965daebfb747f24bdd8e97158147e749dce5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget.html.php"));

        // line 1
        echo "<?php if (\$compound): ?>
<?php echo \$view['form']->block(\$form, 'form_widget_compound')?>
<?php else: ?>
<?php echo \$view['form']->block(\$form, 'form_widget_simple')?>
<?php endif ?>
";
        
        $__internal_131b606d70effb65e39a9fcd8de9c40a9d22563d9d70efea4004929b8d936b3d->leave($__internal_131b606d70effb65e39a9fcd8de9c40a9d22563d9d70efea4004929b8d936b3d_prof);

        
        $__internal_a14e4e6429423763ba99016ecbfe965daebfb747f24bdd8e97158147e749dce5->leave($__internal_a14e4e6429423763ba99016ecbfe965daebfb747f24bdd8e97158147e749dce5_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (\$compound): ?>
<?php echo \$view['form']->block(\$form, 'form_widget_compound')?>
<?php else: ?>
<?php echo \$view['form']->block(\$form, 'form_widget_simple')?>
<?php endif ?>
", "@Framework/Form/form_widget.html.php", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\models\\symfony\\structure\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\form_widget.html.php");
    }
}
