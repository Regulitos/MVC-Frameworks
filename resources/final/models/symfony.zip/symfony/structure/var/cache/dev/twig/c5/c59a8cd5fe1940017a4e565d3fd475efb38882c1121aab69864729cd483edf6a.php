<?php

/* TwigBundle:Exception:error.js.twig */
class __TwigTemplate_c03c92ad869670f18bf9afe943f604332e795d48247f03ab695a303201fc70e3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2c0a5df91b981e1ffdf8a248b21a8c17d09051fb345f69a7a4d5b07fb7b2fede = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2c0a5df91b981e1ffdf8a248b21a8c17d09051fb345f69a7a4d5b07fb7b2fede->enter($__internal_2c0a5df91b981e1ffdf8a248b21a8c17d09051fb345f69a7a4d5b07fb7b2fede_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.js.twig"));

        $__internal_8673da11aaad09046b9459b2389ed1d0ce134e0fe8d9e0bfd9e7a9d9b67f72c0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8673da11aaad09046b9459b2389ed1d0ce134e0fe8d9e0bfd9e7a9d9b67f72c0->enter($__internal_8673da11aaad09046b9459b2389ed1d0ce134e0fe8d9e0bfd9e7a9d9b67f72c0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.js.twig"));

        // line 1
        echo "/*
";
        // line 2
        echo twig_escape_filter($this->env, ($context["status_code"] ?? $this->getContext($context, "status_code")), "js", null, true);
        echo " ";
        echo twig_escape_filter($this->env, ($context["status_text"] ?? $this->getContext($context, "status_text")), "js", null, true);
        echo "

*/
";
        
        $__internal_2c0a5df91b981e1ffdf8a248b21a8c17d09051fb345f69a7a4d5b07fb7b2fede->leave($__internal_2c0a5df91b981e1ffdf8a248b21a8c17d09051fb345f69a7a4d5b07fb7b2fede_prof);

        
        $__internal_8673da11aaad09046b9459b2389ed1d0ce134e0fe8d9e0bfd9e7a9d9b67f72c0->leave($__internal_8673da11aaad09046b9459b2389ed1d0ce134e0fe8d9e0bfd9e7a9d9b67f72c0_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.js.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  28 => 2,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("/*
{{ status_code }} {{ status_text }}

*/
", "TwigBundle:Exception:error.js.twig", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\models\\symfony\\structure\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle/Resources/views/Exception/error.js.twig");
    }
}
