<?php

/* @Framework/Form/widget_attributes.html.php */
class __TwigTemplate_ec11ec67a0f14336c7d965b38e7029e8aedc276223e341b6a3651b82c566562e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_76a58a909bdb37d4fb189a97ecac2a5fcd5459c2095091ac9ff7574cc41ac282 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_76a58a909bdb37d4fb189a97ecac2a5fcd5459c2095091ac9ff7574cc41ac282->enter($__internal_76a58a909bdb37d4fb189a97ecac2a5fcd5459c2095091ac9ff7574cc41ac282_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/widget_attributes.html.php"));

        $__internal_4a7995631e6a86f303272a2cd7184b01e76a4dbece3d8d399c0cd24b110d45fe = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4a7995631e6a86f303272a2cd7184b01e76a4dbece3d8d399c0cd24b110d45fe->enter($__internal_4a7995631e6a86f303272a2cd7184b01e76a4dbece3d8d399c0cd24b110d45fe_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/widget_attributes.html.php"));

        // line 1
        echo "id=\"<?php echo \$view->escape(\$id) ?>\" name=\"<?php echo \$view->escape(\$full_name) ?>\"<?php if (\$disabled): ?> disabled=\"disabled\"<?php endif ?>
<?php if (\$required): ?> required=\"required\"<?php endif ?>
<?php echo \$attr ? ' '.\$view['form']->block(\$form, 'attributes') : '' ?>
";
        
        $__internal_76a58a909bdb37d4fb189a97ecac2a5fcd5459c2095091ac9ff7574cc41ac282->leave($__internal_76a58a909bdb37d4fb189a97ecac2a5fcd5459c2095091ac9ff7574cc41ac282_prof);

        
        $__internal_4a7995631e6a86f303272a2cd7184b01e76a4dbece3d8d399c0cd24b110d45fe->leave($__internal_4a7995631e6a86f303272a2cd7184b01e76a4dbece3d8d399c0cd24b110d45fe_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/widget_attributes.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("id=\"<?php echo \$view->escape(\$id) ?>\" name=\"<?php echo \$view->escape(\$full_name) ?>\"<?php if (\$disabled): ?> disabled=\"disabled\"<?php endif ?>
<?php if (\$required): ?> required=\"required\"<?php endif ?>
<?php echo \$attr ? ' '.\$view['form']->block(\$form, 'attributes') : '' ?>
", "@Framework/Form/widget_attributes.html.php", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\models\\symfony\\structure\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\widget_attributes.html.php");
    }
}
