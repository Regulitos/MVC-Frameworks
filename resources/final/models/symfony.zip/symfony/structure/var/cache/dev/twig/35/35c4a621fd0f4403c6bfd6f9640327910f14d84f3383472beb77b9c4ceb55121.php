<?php

/* @Framework/Form/button_attributes.html.php */
class __TwigTemplate_4c5713aaef9d3dbfe156eaec1bb89552844c1db72ad95c7eb1f850e31316f8ce extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e65af44c07570e453719c576b354152b2fdc0a733465c24a1e00dd92746058d4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e65af44c07570e453719c576b354152b2fdc0a733465c24a1e00dd92746058d4->enter($__internal_e65af44c07570e453719c576b354152b2fdc0a733465c24a1e00dd92746058d4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_attributes.html.php"));

        $__internal_dd9ba289feea71c550c53fe78e1b6349f8b64da59d83e09f7caf41b781ab9440 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_dd9ba289feea71c550c53fe78e1b6349f8b64da59d83e09f7caf41b781ab9440->enter($__internal_dd9ba289feea71c550c53fe78e1b6349f8b64da59d83e09f7caf41b781ab9440_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_attributes.html.php"));

        // line 1
        echo "id=\"<?php echo \$view->escape(\$id) ?>\" name=\"<?php echo \$view->escape(\$full_name) ?>\"<?php if (\$disabled): ?> disabled=\"disabled\"<?php endif ?>
<?php echo \$attr ? ' '.\$view['form']->block(\$form, 'attributes') : '' ?>
";
        
        $__internal_e65af44c07570e453719c576b354152b2fdc0a733465c24a1e00dd92746058d4->leave($__internal_e65af44c07570e453719c576b354152b2fdc0a733465c24a1e00dd92746058d4_prof);

        
        $__internal_dd9ba289feea71c550c53fe78e1b6349f8b64da59d83e09f7caf41b781ab9440->leave($__internal_dd9ba289feea71c550c53fe78e1b6349f8b64da59d83e09f7caf41b781ab9440_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_attributes.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("id=\"<?php echo \$view->escape(\$id) ?>\" name=\"<?php echo \$view->escape(\$full_name) ?>\"<?php if (\$disabled): ?> disabled=\"disabled\"<?php endif ?>
<?php echo \$attr ? ' '.\$view['form']->block(\$form, 'attributes') : '' ?>
", "@Framework/Form/button_attributes.html.php", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\models\\symfony\\structure\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\button_attributes.html.php");
    }
}
