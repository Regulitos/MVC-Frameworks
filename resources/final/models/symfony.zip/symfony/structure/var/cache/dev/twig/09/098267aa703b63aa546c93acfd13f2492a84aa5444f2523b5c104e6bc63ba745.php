<?php

/* @Twig/Exception/traces.xml.twig */
class __TwigTemplate_b8fb507e2dd3b68ffa7e22e09f29064696180a47b3e9e2fcaede6fc6cf6db4ca extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_138d03d5cc9760b1d61228b0f25fabfa3f21e772baaae255a4ca6c33f98666ef = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_138d03d5cc9760b1d61228b0f25fabfa3f21e772baaae255a4ca6c33f98666ef->enter($__internal_138d03d5cc9760b1d61228b0f25fabfa3f21e772baaae255a4ca6c33f98666ef_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/traces.xml.twig"));

        $__internal_bcbec4d31ef6a57519d3762e1a81153bc29d2a9f628801e48842bfbcd48047be = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_bcbec4d31ef6a57519d3762e1a81153bc29d2a9f628801e48842bfbcd48047be->enter($__internal_bcbec4d31ef6a57519d3762e1a81153bc29d2a9f628801e48842bfbcd48047be_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/traces.xml.twig"));

        // line 1
        echo "        <traces>
";
        // line 2
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute(($context["exception"] ?? $this->getContext($context, "exception")), "trace", array()));
        foreach ($context['_seq'] as $context["_key"] => $context["trace"]) {
            // line 3
            echo "            <trace>
";
            // line 4
            echo twig_include($this->env, $context, "@Twig/Exception/trace.txt.twig", array("trace" => $context["trace"]), false);
            echo "

            </trace>
";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['trace'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 8
        echo "        </traces>
";
        
        $__internal_138d03d5cc9760b1d61228b0f25fabfa3f21e772baaae255a4ca6c33f98666ef->leave($__internal_138d03d5cc9760b1d61228b0f25fabfa3f21e772baaae255a4ca6c33f98666ef_prof);

        
        $__internal_bcbec4d31ef6a57519d3762e1a81153bc29d2a9f628801e48842bfbcd48047be->leave($__internal_bcbec4d31ef6a57519d3762e1a81153bc29d2a9f628801e48842bfbcd48047be_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/traces.xml.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  45 => 8,  35 => 4,  32 => 3,  28 => 2,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("        <traces>
{% for trace in exception.trace %}
            <trace>
{{ include('@Twig/Exception/trace.txt.twig', { trace: trace }, with_context = false) }}

            </trace>
{% endfor %}
        </traces>
", "@Twig/Exception/traces.xml.twig", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\models\\symfony\\structure\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\traces.xml.twig");
    }
}
