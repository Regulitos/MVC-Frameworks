<?php

/* @Framework/Form/url_widget.html.php */
class __TwigTemplate_9b3b60e87d166ef1e5169f63264e464b079dacde68f0423f1b0171aa91e45527 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5b8f29ad97d2fe2702e7936d0ab564728c27f2acd3b0b7918379361fb8eb1288 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5b8f29ad97d2fe2702e7936d0ab564728c27f2acd3b0b7918379361fb8eb1288->enter($__internal_5b8f29ad97d2fe2702e7936d0ab564728c27f2acd3b0b7918379361fb8eb1288_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/url_widget.html.php"));

        $__internal_295ef1707f6dec65fe4c7f6eb1bc7ce30d90a05f9076ffbd23fb600e9d3dfc11 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_295ef1707f6dec65fe4c7f6eb1bc7ce30d90a05f9076ffbd23fb600e9d3dfc11->enter($__internal_295ef1707f6dec65fe4c7f6eb1bc7ce30d90a05f9076ffbd23fb600e9d3dfc11_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/url_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'url')) ?>
";
        
        $__internal_5b8f29ad97d2fe2702e7936d0ab564728c27f2acd3b0b7918379361fb8eb1288->leave($__internal_5b8f29ad97d2fe2702e7936d0ab564728c27f2acd3b0b7918379361fb8eb1288_prof);

        
        $__internal_295ef1707f6dec65fe4c7f6eb1bc7ce30d90a05f9076ffbd23fb600e9d3dfc11->leave($__internal_295ef1707f6dec65fe4c7f6eb1bc7ce30d90a05f9076ffbd23fb600e9d3dfc11_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/url_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'url')) ?>
", "@Framework/Form/url_widget.html.php", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\models\\symfony\\structure\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\url_widget.html.php");
    }
}
