<?php

/* @Twig/Exception/error.js.twig */
class __TwigTemplate_b2fe359392c0997a04c6199ebc33f0fb3a476aa27c4a552a2ea1174f5cc48be3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c46610904a4f2d403ee33ff2d9c226e133b6cf94f00f4925dba4be0ba59aa3ff = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c46610904a4f2d403ee33ff2d9c226e133b6cf94f00f4925dba4be0ba59aa3ff->enter($__internal_c46610904a4f2d403ee33ff2d9c226e133b6cf94f00f4925dba4be0ba59aa3ff_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.js.twig"));

        $__internal_0455412d2e6eb2112f37853e4542823db98e43b28e418ce5ed2ec0c212c87e40 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0455412d2e6eb2112f37853e4542823db98e43b28e418ce5ed2ec0c212c87e40->enter($__internal_0455412d2e6eb2112f37853e4542823db98e43b28e418ce5ed2ec0c212c87e40_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.js.twig"));

        // line 1
        echo "/*
";
        // line 2
        echo twig_escape_filter($this->env, ($context["status_code"] ?? $this->getContext($context, "status_code")), "js", null, true);
        echo " ";
        echo twig_escape_filter($this->env, ($context["status_text"] ?? $this->getContext($context, "status_text")), "js", null, true);
        echo "

*/
";
        
        $__internal_c46610904a4f2d403ee33ff2d9c226e133b6cf94f00f4925dba4be0ba59aa3ff->leave($__internal_c46610904a4f2d403ee33ff2d9c226e133b6cf94f00f4925dba4be0ba59aa3ff_prof);

        
        $__internal_0455412d2e6eb2112f37853e4542823db98e43b28e418ce5ed2ec0c212c87e40->leave($__internal_0455412d2e6eb2112f37853e4542823db98e43b28e418ce5ed2ec0c212c87e40_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/error.js.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  28 => 2,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("/*
{{ status_code }} {{ status_text }}

*/
", "@Twig/Exception/error.js.twig", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\models\\symfony\\structure\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\error.js.twig");
    }
}
