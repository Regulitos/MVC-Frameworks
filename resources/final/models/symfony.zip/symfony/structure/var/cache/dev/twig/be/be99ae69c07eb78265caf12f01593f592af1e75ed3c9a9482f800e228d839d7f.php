<?php

/* @Framework/Form/email_widget.html.php */
class __TwigTemplate_2f3d959d9d3903a747a22cbd389c8b17ad767e5dc1fd577fc679de2d401a013c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_29d141044fb57196dc3f6e35073809f56e148491cfbaaf5951957dfd930e81ef = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_29d141044fb57196dc3f6e35073809f56e148491cfbaaf5951957dfd930e81ef->enter($__internal_29d141044fb57196dc3f6e35073809f56e148491cfbaaf5951957dfd930e81ef_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/email_widget.html.php"));

        $__internal_1596c7f6366535b49a0c88ef26996924c5c3bde6e0b228abf6a63551d9493ed7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1596c7f6366535b49a0c88ef26996924c5c3bde6e0b228abf6a63551d9493ed7->enter($__internal_1596c7f6366535b49a0c88ef26996924c5c3bde6e0b228abf6a63551d9493ed7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/email_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'email')) ?>
";
        
        $__internal_29d141044fb57196dc3f6e35073809f56e148491cfbaaf5951957dfd930e81ef->leave($__internal_29d141044fb57196dc3f6e35073809f56e148491cfbaaf5951957dfd930e81ef_prof);

        
        $__internal_1596c7f6366535b49a0c88ef26996924c5c3bde6e0b228abf6a63551d9493ed7->leave($__internal_1596c7f6366535b49a0c88ef26996924c5c3bde6e0b228abf6a63551d9493ed7_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/email_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'email')) ?>
", "@Framework/Form/email_widget.html.php", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\models\\symfony\\structure\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\email_widget.html.php");
    }
}
