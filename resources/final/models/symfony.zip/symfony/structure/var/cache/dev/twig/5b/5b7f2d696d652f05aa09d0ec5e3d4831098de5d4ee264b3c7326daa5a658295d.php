<?php

/* @Framework/Form/checkbox_widget.html.php */
class __TwigTemplate_a3c36fc58f37ab307b316d6acb0f9c0c5b3e7fd05ca49c161cb826e93a96e683 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ff984f5091c0d5c75e40d03dda192cd4686be2405ae950bf7d5bef4b52e53ba2 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ff984f5091c0d5c75e40d03dda192cd4686be2405ae950bf7d5bef4b52e53ba2->enter($__internal_ff984f5091c0d5c75e40d03dda192cd4686be2405ae950bf7d5bef4b52e53ba2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/checkbox_widget.html.php"));

        $__internal_116c26e7590fb61153aa561bbdd0c557d11ece8f64a2c7f6e9549d277244ac82 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_116c26e7590fb61153aa561bbdd0c557d11ece8f64a2c7f6e9549d277244ac82->enter($__internal_116c26e7590fb61153aa561bbdd0c557d11ece8f64a2c7f6e9549d277244ac82_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/checkbox_widget.html.php"));

        // line 1
        echo "<input type=\"checkbox\"
    <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
    <?php if (strlen(\$value) > 0): ?> value=\"<?php echo \$view->escape(\$value) ?>\"<?php endif ?>
    <?php if (\$checked): ?> checked=\"checked\"<?php endif ?>
/>
";
        
        $__internal_ff984f5091c0d5c75e40d03dda192cd4686be2405ae950bf7d5bef4b52e53ba2->leave($__internal_ff984f5091c0d5c75e40d03dda192cd4686be2405ae950bf7d5bef4b52e53ba2_prof);

        
        $__internal_116c26e7590fb61153aa561bbdd0c557d11ece8f64a2c7f6e9549d277244ac82->leave($__internal_116c26e7590fb61153aa561bbdd0c557d11ece8f64a2c7f6e9549d277244ac82_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/checkbox_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<input type=\"checkbox\"
    <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
    <?php if (strlen(\$value) > 0): ?> value=\"<?php echo \$view->escape(\$value) ?>\"<?php endif ?>
    <?php if (\$checked): ?> checked=\"checked\"<?php endif ?>
/>
", "@Framework/Form/checkbox_widget.html.php", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\models\\symfony\\structure\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\checkbox_widget.html.php");
    }
}
