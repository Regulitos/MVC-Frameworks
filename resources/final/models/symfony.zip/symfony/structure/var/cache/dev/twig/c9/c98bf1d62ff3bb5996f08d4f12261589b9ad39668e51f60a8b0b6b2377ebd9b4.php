<?php

/* @Twig/Exception/error.rdf.twig */
class __TwigTemplate_ebf8aedd5c44f694607413aed4441f8014f0fb155687e68b832612ce09917b3e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_03349bdfac20b9c3ec816cef05b45e294648643a38581ed09d9636134a06ded5 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_03349bdfac20b9c3ec816cef05b45e294648643a38581ed09d9636134a06ded5->enter($__internal_03349bdfac20b9c3ec816cef05b45e294648643a38581ed09d9636134a06ded5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.rdf.twig"));

        $__internal_12fa9949c9b1139a7204711f95eb003663463e5a8678ac6d3d4cc8231cd03a08 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_12fa9949c9b1139a7204711f95eb003663463e5a8678ac6d3d4cc8231cd03a08->enter($__internal_12fa9949c9b1139a7204711f95eb003663463e5a8678ac6d3d4cc8231cd03a08_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.rdf.twig"));

        // line 1
        echo twig_include($this->env, $context, "@Twig/Exception/error.xml.twig");
        echo "
";
        
        $__internal_03349bdfac20b9c3ec816cef05b45e294648643a38581ed09d9636134a06ded5->leave($__internal_03349bdfac20b9c3ec816cef05b45e294648643a38581ed09d9636134a06ded5_prof);

        
        $__internal_12fa9949c9b1139a7204711f95eb003663463e5a8678ac6d3d4cc8231cd03a08->leave($__internal_12fa9949c9b1139a7204711f95eb003663463e5a8678ac6d3d4cc8231cd03a08_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/error.rdf.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ include('@Twig/Exception/error.xml.twig') }}
", "@Twig/Exception/error.rdf.twig", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\models\\symfony\\structure\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\error.rdf.twig");
    }
}
