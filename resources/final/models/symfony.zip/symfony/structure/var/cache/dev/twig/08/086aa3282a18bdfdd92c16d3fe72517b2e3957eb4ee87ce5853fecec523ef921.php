<?php

/* @WebProfiler/Collector/exception.html.twig */
class __TwigTemplate_91f23d26d1e9c4d15bd74abc1f548fe71498140eaf4fd2e477e058e8a9bd1df4 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/exception.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a44ff8e200d0e43755b7559505260f2f6163d386f77bdd93ec86f73e950e6f54 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a44ff8e200d0e43755b7559505260f2f6163d386f77bdd93ec86f73e950e6f54->enter($__internal_a44ff8e200d0e43755b7559505260f2f6163d386f77bdd93ec86f73e950e6f54_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/exception.html.twig"));

        $__internal_18473f93cfd9f9e1622a1ceb54998b3a11437505d515259220e401a37d0518e4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_18473f93cfd9f9e1622a1ceb54998b3a11437505d515259220e401a37d0518e4->enter($__internal_18473f93cfd9f9e1622a1ceb54998b3a11437505d515259220e401a37d0518e4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/exception.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_a44ff8e200d0e43755b7559505260f2f6163d386f77bdd93ec86f73e950e6f54->leave($__internal_a44ff8e200d0e43755b7559505260f2f6163d386f77bdd93ec86f73e950e6f54_prof);

        
        $__internal_18473f93cfd9f9e1622a1ceb54998b3a11437505d515259220e401a37d0518e4->leave($__internal_18473f93cfd9f9e1622a1ceb54998b3a11437505d515259220e401a37d0518e4_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_22576b50576465cc28ba947b90b381114659dd4ec4024aedd406d568c6dcd206 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_22576b50576465cc28ba947b90b381114659dd4ec4024aedd406d568c6dcd206->enter($__internal_22576b50576465cc28ba947b90b381114659dd4ec4024aedd406d568c6dcd206_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        $__internal_03d2abc6cf551c02a878f3593bb3f4eddb6c021ce83104fc39f1ae8c3f0c01a4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_03d2abc6cf551c02a878f3593bb3f4eddb6c021ce83104fc39f1ae8c3f0c01a4->enter($__internal_03d2abc6cf551c02a878f3593bb3f4eddb6c021ce83104fc39f1ae8c3f0c01a4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    ";
        if ($this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) {
            // line 5
            echo "        <style>
            ";
            // line 6
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_exception_css", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
            echo "
        </style>
    ";
        }
        // line 9
        echo "    ";
        $this->displayParentBlock("head", $context, $blocks);
        echo "
";
        
        $__internal_03d2abc6cf551c02a878f3593bb3f4eddb6c021ce83104fc39f1ae8c3f0c01a4->leave($__internal_03d2abc6cf551c02a878f3593bb3f4eddb6c021ce83104fc39f1ae8c3f0c01a4_prof);

        
        $__internal_22576b50576465cc28ba947b90b381114659dd4ec4024aedd406d568c6dcd206->leave($__internal_22576b50576465cc28ba947b90b381114659dd4ec4024aedd406d568c6dcd206_prof);

    }

    // line 12
    public function block_menu($context, array $blocks = array())
    {
        $__internal_701d5019328fd5f405c443329d994820da699063d915a3cd643c58c70cbac0fd = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_701d5019328fd5f405c443329d994820da699063d915a3cd643c58c70cbac0fd->enter($__internal_701d5019328fd5f405c443329d994820da699063d915a3cd643c58c70cbac0fd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_1aa643276477ae879b4eba61da7123032a817c138543c9922d08eb43812c7d66 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1aa643276477ae879b4eba61da7123032a817c138543c9922d08eb43812c7d66->enter($__internal_1aa643276477ae879b4eba61da7123032a817c138543c9922d08eb43812c7d66_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 13
        echo "    <span class=\"label ";
        echo (($this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) ? ("label-status-error") : ("disabled"));
        echo "\">
        <span class=\"icon\">";
        // line 14
        echo twig_include($this->env, $context, "@WebProfiler/Icon/exception.svg");
        echo "</span>
        <strong>Exception</strong>
        ";
        // line 16
        if ($this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) {
            // line 17
            echo "            <span class=\"count\">
                <span>1</span>
            </span>
        ";
        }
        // line 21
        echo "    </span>
";
        
        $__internal_1aa643276477ae879b4eba61da7123032a817c138543c9922d08eb43812c7d66->leave($__internal_1aa643276477ae879b4eba61da7123032a817c138543c9922d08eb43812c7d66_prof);

        
        $__internal_701d5019328fd5f405c443329d994820da699063d915a3cd643c58c70cbac0fd->leave($__internal_701d5019328fd5f405c443329d994820da699063d915a3cd643c58c70cbac0fd_prof);

    }

    // line 24
    public function block_panel($context, array $blocks = array())
    {
        $__internal_bf61adba1c26e316ef193e6e88f6df46e9a7e32ac554904cd3c8464801026dfb = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_bf61adba1c26e316ef193e6e88f6df46e9a7e32ac554904cd3c8464801026dfb->enter($__internal_bf61adba1c26e316ef193e6e88f6df46e9a7e32ac554904cd3c8464801026dfb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_98c4a9c8f4b18adad2568591756b3313f5f85370f7f6233897ea0b8dad27fbc2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_98c4a9c8f4b18adad2568591756b3313f5f85370f7f6233897ea0b8dad27fbc2->enter($__internal_98c4a9c8f4b18adad2568591756b3313f5f85370f7f6233897ea0b8dad27fbc2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 25
        echo "    <h2>Exceptions</h2>

    ";
        // line 27
        if ( !$this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) {
            // line 28
            echo "        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    ";
        } else {
            // line 32
            echo "        <div class=\"sf-reset\">
            ";
            // line 33
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_exception", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
            echo "
        </div>
    ";
        }
        
        $__internal_98c4a9c8f4b18adad2568591756b3313f5f85370f7f6233897ea0b8dad27fbc2->leave($__internal_98c4a9c8f4b18adad2568591756b3313f5f85370f7f6233897ea0b8dad27fbc2_prof);

        
        $__internal_bf61adba1c26e316ef193e6e88f6df46e9a7e32ac554904cd3c8464801026dfb->leave($__internal_bf61adba1c26e316ef193e6e88f6df46e9a7e32ac554904cd3c8464801026dfb_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/exception.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  138 => 33,  135 => 32,  129 => 28,  127 => 27,  123 => 25,  114 => 24,  103 => 21,  97 => 17,  95 => 16,  90 => 14,  85 => 13,  76 => 12,  63 => 9,  57 => 6,  54 => 5,  51 => 4,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block head %}
    {% if collector.hasexception %}
        <style>
            {{ render(path('_profiler_exception_css', { token: token })) }}
        </style>
    {% endif %}
    {{ parent() }}
{% endblock %}

{% block menu %}
    <span class=\"label {{ collector.hasexception ? 'label-status-error' : 'disabled' }}\">
        <span class=\"icon\">{{ include('@WebProfiler/Icon/exception.svg') }}</span>
        <strong>Exception</strong>
        {% if collector.hasexception %}
            <span class=\"count\">
                <span>1</span>
            </span>
        {% endif %}
    </span>
{% endblock %}

{% block panel %}
    <h2>Exceptions</h2>

    {% if not collector.hasexception %}
        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    {% else %}
        <div class=\"sf-reset\">
            {{ render(path('_profiler_exception', { token: token })) }}
        </div>
    {% endif %}
{% endblock %}
", "@WebProfiler/Collector/exception.html.twig", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\models\\symfony\\structure\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Collector\\exception.html.twig");
    }
}
