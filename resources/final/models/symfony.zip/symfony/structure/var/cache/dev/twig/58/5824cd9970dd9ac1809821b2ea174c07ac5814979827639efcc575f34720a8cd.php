<?php

/* @Framework/Form/password_widget.html.php */
class __TwigTemplate_5a5f5c2e94ae3444b03cc7931e0df645efc015df2af71eb52a9f5db0e75b716f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5b77606968679f2d668a38a1a0d7a92e2056d6d90970195b7d2fcb20420c7ba1 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5b77606968679f2d668a38a1a0d7a92e2056d6d90970195b7d2fcb20420c7ba1->enter($__internal_5b77606968679f2d668a38a1a0d7a92e2056d6d90970195b7d2fcb20420c7ba1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/password_widget.html.php"));

        $__internal_f76caa8573baf38d148477566323e49a77a7b55088285f6303fbfa403478cae4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f76caa8573baf38d148477566323e49a77a7b55088285f6303fbfa403478cae4->enter($__internal_f76caa8573baf38d148477566323e49a77a7b55088285f6303fbfa403478cae4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/password_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'password')) ?>
";
        
        $__internal_5b77606968679f2d668a38a1a0d7a92e2056d6d90970195b7d2fcb20420c7ba1->leave($__internal_5b77606968679f2d668a38a1a0d7a92e2056d6d90970195b7d2fcb20420c7ba1_prof);

        
        $__internal_f76caa8573baf38d148477566323e49a77a7b55088285f6303fbfa403478cae4->leave($__internal_f76caa8573baf38d148477566323e49a77a7b55088285f6303fbfa403478cae4_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/password_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'password')) ?>
", "@Framework/Form/password_widget.html.php", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\models\\symfony\\structure\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\password_widget.html.php");
    }
}
