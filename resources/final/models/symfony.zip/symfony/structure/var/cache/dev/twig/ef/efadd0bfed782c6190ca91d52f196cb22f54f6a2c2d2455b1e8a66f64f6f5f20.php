<?php

/* @Framework/Form/choice_options.html.php */
class __TwigTemplate_32699e087196b13f160cc7596ce48296a3737bb211057b369df885a37d7145a1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9aa6e4d7777a7c37fc80eec5da979246269eb83901c44888356cd4505ee3e05c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9aa6e4d7777a7c37fc80eec5da979246269eb83901c44888356cd4505ee3e05c->enter($__internal_9aa6e4d7777a7c37fc80eec5da979246269eb83901c44888356cd4505ee3e05c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_options.html.php"));

        $__internal_ae4ef68df276eaf4424693bc3466392c0e21de5ea138edb95454abf137547042 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ae4ef68df276eaf4424693bc3466392c0e21de5ea138edb95454abf137547042->enter($__internal_ae4ef68df276eaf4424693bc3466392c0e21de5ea138edb95454abf137547042_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_options.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'choice_widget_options') ?>
";
        
        $__internal_9aa6e4d7777a7c37fc80eec5da979246269eb83901c44888356cd4505ee3e05c->leave($__internal_9aa6e4d7777a7c37fc80eec5da979246269eb83901c44888356cd4505ee3e05c_prof);

        
        $__internal_ae4ef68df276eaf4424693bc3466392c0e21de5ea138edb95454abf137547042->leave($__internal_ae4ef68df276eaf4424693bc3466392c0e21de5ea138edb95454abf137547042_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/choice_options.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'choice_widget_options') ?>
", "@Framework/Form/choice_options.html.php", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\models\\symfony\\structure\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\choice_options.html.php");
    }
}
