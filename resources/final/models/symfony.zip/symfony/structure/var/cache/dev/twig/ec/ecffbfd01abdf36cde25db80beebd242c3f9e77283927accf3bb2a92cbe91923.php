<?php

/* @Framework/Form/button_row.html.php */
class __TwigTemplate_4b4bd3d6de7e2c90f067551787e44c1ef8d1bb38215839af9898f50ab5c0c5c1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9fe23348eb636025640e878d22025422dcb5fcd7292ec8569e8d4e09a2baf0e0 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9fe23348eb636025640e878d22025422dcb5fcd7292ec8569e8d4e09a2baf0e0->enter($__internal_9fe23348eb636025640e878d22025422dcb5fcd7292ec8569e8d4e09a2baf0e0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_row.html.php"));

        $__internal_662aedf0fb88aea8a990feee1a938f3b748baf7625b07148d7803ec235e2a2c7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_662aedf0fb88aea8a990feee1a938f3b748baf7625b07148d7803ec235e2a2c7->enter($__internal_662aedf0fb88aea8a990feee1a938f3b748baf7625b07148d7803ec235e2a2c7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_row.html.php"));

        // line 1
        echo "<div>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
";
        
        $__internal_9fe23348eb636025640e878d22025422dcb5fcd7292ec8569e8d4e09a2baf0e0->leave($__internal_9fe23348eb636025640e878d22025422dcb5fcd7292ec8569e8d4e09a2baf0e0_prof);

        
        $__internal_662aedf0fb88aea8a990feee1a938f3b748baf7625b07148d7803ec235e2a2c7->leave($__internal_662aedf0fb88aea8a990feee1a938f3b748baf7625b07148d7803ec235e2a2c7_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
", "@Framework/Form/button_row.html.php", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\models\\symfony\\structure\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\button_row.html.php");
    }
}
