<?php

/* @Framework/Form/form_end.html.php */
class __TwigTemplate_5ee73d688fa8b6c409e69bb7c04b302e75378599d646093b00f9e26b1596d0f9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_83610a3542e60841de53554e6997d00d6a7e64c38c9bf121b46915afe32b782c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_83610a3542e60841de53554e6997d00d6a7e64c38c9bf121b46915afe32b782c->enter($__internal_83610a3542e60841de53554e6997d00d6a7e64c38c9bf121b46915afe32b782c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_end.html.php"));

        $__internal_181c4132d092cd9ca3a97589e8ec78d7ff03dcabd31124d167344e3f5b3ff3e8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_181c4132d092cd9ca3a97589e8ec78d7ff03dcabd31124d167344e3f5b3ff3e8->enter($__internal_181c4132d092cd9ca3a97589e8ec78d7ff03dcabd31124d167344e3f5b3ff3e8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_end.html.php"));

        // line 1
        echo "<?php if (!isset(\$render_rest) || \$render_rest): ?>
<?php echo \$view['form']->rest(\$form) ?>
<?php endif ?>
</form>
";
        
        $__internal_83610a3542e60841de53554e6997d00d6a7e64c38c9bf121b46915afe32b782c->leave($__internal_83610a3542e60841de53554e6997d00d6a7e64c38c9bf121b46915afe32b782c_prof);

        
        $__internal_181c4132d092cd9ca3a97589e8ec78d7ff03dcabd31124d167344e3f5b3ff3e8->leave($__internal_181c4132d092cd9ca3a97589e8ec78d7ff03dcabd31124d167344e3f5b3ff3e8_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_end.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (!isset(\$render_rest) || \$render_rest): ?>
<?php echo \$view['form']->rest(\$form) ?>
<?php endif ?>
</form>
", "@Framework/Form/form_end.html.php", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\models\\symfony\\structure\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\form_end.html.php");
    }
}
