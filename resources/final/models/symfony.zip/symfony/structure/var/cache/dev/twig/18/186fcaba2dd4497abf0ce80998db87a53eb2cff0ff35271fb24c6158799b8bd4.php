<?php

/* TwigBundle:Exception:exception.json.twig */
class __TwigTemplate_9288100d8334098eb8c275861fc64d9d89cf92d90e88e781d43c3626d822db1f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2c17585e5da885f705ae365d654f0802c1c0869f02a7e8759b886c6f13cd0efa = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2c17585e5da885f705ae365d654f0802c1c0869f02a7e8759b886c6f13cd0efa->enter($__internal_2c17585e5da885f705ae365d654f0802c1c0869f02a7e8759b886c6f13cd0efa_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.json.twig"));

        $__internal_24d62d2d35681532648b4c7a94689fcf610ef496a4a6c6150a851aff5c0eaa63 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_24d62d2d35681532648b4c7a94689fcf610ef496a4a6c6150a851aff5c0eaa63->enter($__internal_24d62d2d35681532648b4c7a94689fcf610ef496a4a6c6150a851aff5c0eaa63_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.json.twig"));

        // line 1
        echo twig_jsonencode_filter(array("error" => array("code" => ($context["status_code"] ?? $this->getContext($context, "status_code")), "message" => ($context["status_text"] ?? $this->getContext($context, "status_text")), "exception" => $this->getAttribute(($context["exception"] ?? $this->getContext($context, "exception")), "toarray", array()))));
        echo "
";
        
        $__internal_2c17585e5da885f705ae365d654f0802c1c0869f02a7e8759b886c6f13cd0efa->leave($__internal_2c17585e5da885f705ae365d654f0802c1c0869f02a7e8759b886c6f13cd0efa_prof);

        
        $__internal_24d62d2d35681532648b4c7a94689fcf610ef496a4a6c6150a851aff5c0eaa63->leave($__internal_24d62d2d35681532648b4c7a94689fcf610ef496a4a6c6150a851aff5c0eaa63_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.json.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ { 'error': { 'code': status_code, 'message': status_text, 'exception': exception.toarray } }|json_encode|raw }}
", "TwigBundle:Exception:exception.json.twig", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\models\\symfony\\structure\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle/Resources/views/Exception/exception.json.twig");
    }
}
