<?php

/* @Twig/Exception/exception.json.twig */
class __TwigTemplate_6189972f088ee8570f6a09a6e68bd48237b462530423d97deec254d5ef311f70 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_18b37393ae43960309e59cbb6316b4b1a2818b32f51e921574c11e30befb41c9 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_18b37393ae43960309e59cbb6316b4b1a2818b32f51e921574c11e30befb41c9->enter($__internal_18b37393ae43960309e59cbb6316b4b1a2818b32f51e921574c11e30befb41c9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.json.twig"));

        $__internal_44a082da575b766d2b83900033ed435fb16b27f36a2e943f1ee9e3710fc7f454 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_44a082da575b766d2b83900033ed435fb16b27f36a2e943f1ee9e3710fc7f454->enter($__internal_44a082da575b766d2b83900033ed435fb16b27f36a2e943f1ee9e3710fc7f454_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.json.twig"));

        // line 1
        echo twig_jsonencode_filter(array("error" => array("code" => ($context["status_code"] ?? $this->getContext($context, "status_code")), "message" => ($context["status_text"] ?? $this->getContext($context, "status_text")), "exception" => $this->getAttribute(($context["exception"] ?? $this->getContext($context, "exception")), "toarray", array()))));
        echo "
";
        
        $__internal_18b37393ae43960309e59cbb6316b4b1a2818b32f51e921574c11e30befb41c9->leave($__internal_18b37393ae43960309e59cbb6316b4b1a2818b32f51e921574c11e30befb41c9_prof);

        
        $__internal_44a082da575b766d2b83900033ed435fb16b27f36a2e943f1ee9e3710fc7f454->leave($__internal_44a082da575b766d2b83900033ed435fb16b27f36a2e943f1ee9e3710fc7f454_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/exception.json.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ { 'error': { 'code': status_code, 'message': status_text, 'exception': exception.toarray } }|json_encode|raw }}
", "@Twig/Exception/exception.json.twig", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\models\\symfony\\structure\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\exception.json.twig");
    }
}
