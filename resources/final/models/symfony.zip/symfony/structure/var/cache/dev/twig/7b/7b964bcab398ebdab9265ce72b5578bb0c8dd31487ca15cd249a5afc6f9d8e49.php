<?php

/* @Framework/Form/form_widget_compound.html.php */
class __TwigTemplate_48da2b5a70dd8ebee4b5b00a21f4d66683f9829510a8297a84b97358b3a1d54d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ad6a85ef5f2c01b4ddc7011fb4a82efc25e65a08ba65caa46135d9d60794c381 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ad6a85ef5f2c01b4ddc7011fb4a82efc25e65a08ba65caa46135d9d60794c381->enter($__internal_ad6a85ef5f2c01b4ddc7011fb4a82efc25e65a08ba65caa46135d9d60794c381_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget_compound.html.php"));

        $__internal_a4312df964439a01f2ced5eae29bd8d1eb1822b9878d0073744d8d09d56fd411 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a4312df964439a01f2ced5eae29bd8d1eb1822b9878d0073744d8d09d56fd411->enter($__internal_a4312df964439a01f2ced5eae29bd8d1eb1822b9878d0073744d8d09d56fd411_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget_compound.html.php"));

        // line 1
        echo "<div <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
    <?php if (!\$form->parent && \$errors): ?>
    <?php echo \$view['form']->errors(\$form) ?>
    <?php endif ?>
    <?php echo \$view['form']->block(\$form, 'form_rows') ?>
    <?php echo \$view['form']->rest(\$form) ?>
</div>
";
        
        $__internal_ad6a85ef5f2c01b4ddc7011fb4a82efc25e65a08ba65caa46135d9d60794c381->leave($__internal_ad6a85ef5f2c01b4ddc7011fb4a82efc25e65a08ba65caa46135d9d60794c381_prof);

        
        $__internal_a4312df964439a01f2ced5eae29bd8d1eb1822b9878d0073744d8d09d56fd411->leave($__internal_a4312df964439a01f2ced5eae29bd8d1eb1822b9878d0073744d8d09d56fd411_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_widget_compound.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
    <?php if (!\$form->parent && \$errors): ?>
    <?php echo \$view['form']->errors(\$form) ?>
    <?php endif ?>
    <?php echo \$view['form']->block(\$form, 'form_rows') ?>
    <?php echo \$view['form']->rest(\$form) ?>
</div>
", "@Framework/Form/form_widget_compound.html.php", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\models\\symfony\\structure\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\form_widget_compound.html.php");
    }
}
