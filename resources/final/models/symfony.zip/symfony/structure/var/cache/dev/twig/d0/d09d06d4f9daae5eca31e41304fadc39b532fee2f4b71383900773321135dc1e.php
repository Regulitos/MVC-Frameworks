<?php

/* @Framework/Form/form_rows.html.php */
class __TwigTemplate_cc6c901cdef63566eb911ff579d162bdf1c429ff439dacd25386ab6f285f8d8f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9b8fa6e9268ea6e7fa0e8641ab79e47b5a354d6e5a74cc734a8921e63a25b5df = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9b8fa6e9268ea6e7fa0e8641ab79e47b5a354d6e5a74cc734a8921e63a25b5df->enter($__internal_9b8fa6e9268ea6e7fa0e8641ab79e47b5a354d6e5a74cc734a8921e63a25b5df_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_rows.html.php"));

        $__internal_ca58a28d2121302d590d6bc00f2ad125d7029fd5b02ee50b81391cb12f6a6a03 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ca58a28d2121302d590d6bc00f2ad125d7029fd5b02ee50b81391cb12f6a6a03->enter($__internal_ca58a28d2121302d590d6bc00f2ad125d7029fd5b02ee50b81391cb12f6a6a03_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_rows.html.php"));

        // line 1
        echo "<?php foreach (\$form as \$child) : ?>
    <?php echo \$view['form']->row(\$child) ?>
<?php endforeach; ?>
";
        
        $__internal_9b8fa6e9268ea6e7fa0e8641ab79e47b5a354d6e5a74cc734a8921e63a25b5df->leave($__internal_9b8fa6e9268ea6e7fa0e8641ab79e47b5a354d6e5a74cc734a8921e63a25b5df_prof);

        
        $__internal_ca58a28d2121302d590d6bc00f2ad125d7029fd5b02ee50b81391cb12f6a6a03->leave($__internal_ca58a28d2121302d590d6bc00f2ad125d7029fd5b02ee50b81391cb12f6a6a03_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_rows.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php foreach (\$form as \$child) : ?>
    <?php echo \$view['form']->row(\$child) ?>
<?php endforeach; ?>
", "@Framework/Form/form_rows.html.php", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\models\\symfony\\structure\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\form_rows.html.php");
    }
}
