<?php

/* @Framework/Form/form_widget_simple.html.php */
class __TwigTemplate_1a47a875b481b077d24b2f8041c95c21f77eb5288a91f7d91fc70f7c07ee4ab0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3b96f32994173fe73d2b99479131faa272f404ed69efb858a2814146e7d7e04b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3b96f32994173fe73d2b99479131faa272f404ed69efb858a2814146e7d7e04b->enter($__internal_3b96f32994173fe73d2b99479131faa272f404ed69efb858a2814146e7d7e04b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget_simple.html.php"));

        $__internal_7aaeb3cea0a40a1171eb16356c426dcf3ea453e8ae125a1799d6cba472aa3187 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7aaeb3cea0a40a1171eb16356c426dcf3ea453e8ae125a1799d6cba472aa3187->enter($__internal_7aaeb3cea0a40a1171eb16356c426dcf3ea453e8ae125a1799d6cba472aa3187_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget_simple.html.php"));

        // line 1
        echo "<input type=\"<?php echo isset(\$type) ? \$view->escape(\$type) : 'text' ?>\" <?php echo \$view['form']->block(\$form, 'widget_attributes') ?><?php if (!empty(\$value) || is_numeric(\$value)): ?> value=\"<?php echo \$view->escape(\$value) ?>\"<?php endif ?> />
";
        
        $__internal_3b96f32994173fe73d2b99479131faa272f404ed69efb858a2814146e7d7e04b->leave($__internal_3b96f32994173fe73d2b99479131faa272f404ed69efb858a2814146e7d7e04b_prof);

        
        $__internal_7aaeb3cea0a40a1171eb16356c426dcf3ea453e8ae125a1799d6cba472aa3187->leave($__internal_7aaeb3cea0a40a1171eb16356c426dcf3ea453e8ae125a1799d6cba472aa3187_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_widget_simple.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<input type=\"<?php echo isset(\$type) ? \$view->escape(\$type) : 'text' ?>\" <?php echo \$view['form']->block(\$form, 'widget_attributes') ?><?php if (!empty(\$value) || is_numeric(\$value)): ?> value=\"<?php echo \$view->escape(\$value) ?>\"<?php endif ?> />
", "@Framework/Form/form_widget_simple.html.php", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\models\\symfony\\structure\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\form_widget_simple.html.php");
    }
}
