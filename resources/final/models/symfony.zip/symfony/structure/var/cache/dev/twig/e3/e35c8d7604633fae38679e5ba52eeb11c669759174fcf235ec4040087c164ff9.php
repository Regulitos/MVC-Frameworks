<?php

/* @Framework/Form/hidden_row.html.php */
class __TwigTemplate_3b66698657688110c1d99f82d8dc6c391d6b0a988ea590935983182a60dfccc5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ad1ff4bb50d60e16d6de788bd4128a48f32dcbb97d607c0274d4ad5b5b4b072d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ad1ff4bb50d60e16d6de788bd4128a48f32dcbb97d607c0274d4ad5b5b4b072d->enter($__internal_ad1ff4bb50d60e16d6de788bd4128a48f32dcbb97d607c0274d4ad5b5b4b072d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/hidden_row.html.php"));

        $__internal_950958609cd663850a87682a52e8f36d0f900b39e2e75a2db9af9249ae35f758 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_950958609cd663850a87682a52e8f36d0f900b39e2e75a2db9af9249ae35f758->enter($__internal_950958609cd663850a87682a52e8f36d0f900b39e2e75a2db9af9249ae35f758_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/hidden_row.html.php"));

        // line 1
        echo "<?php echo \$view['form']->widget(\$form) ?>
";
        
        $__internal_ad1ff4bb50d60e16d6de788bd4128a48f32dcbb97d607c0274d4ad5b5b4b072d->leave($__internal_ad1ff4bb50d60e16d6de788bd4128a48f32dcbb97d607c0274d4ad5b5b4b072d_prof);

        
        $__internal_950958609cd663850a87682a52e8f36d0f900b39e2e75a2db9af9249ae35f758->leave($__internal_950958609cd663850a87682a52e8f36d0f900b39e2e75a2db9af9249ae35f758_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/hidden_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->widget(\$form) ?>
", "@Framework/Form/hidden_row.html.php", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\models\\symfony\\structure\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\hidden_row.html.php");
    }
}
