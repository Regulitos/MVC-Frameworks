<?php

/* WebProfilerBundle:Profiler:ajax_layout.html.twig */
class __TwigTemplate_ea5546ba30baf4b586e3d8de7ea5609933e843ee1c480e8a1618a0e56cbaf936 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f93181f24105cc26a7f2579a206330006c077ff2ad4dae07354e6ed1bd3043bb = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f93181f24105cc26a7f2579a206330006c077ff2ad4dae07354e6ed1bd3043bb->enter($__internal_f93181f24105cc26a7f2579a206330006c077ff2ad4dae07354e6ed1bd3043bb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:ajax_layout.html.twig"));

        $__internal_dd2f06c803a8e1ffbbb2ff6c69503f5bf823231b4ae0e87db63f46bc5c7b54e0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_dd2f06c803a8e1ffbbb2ff6c69503f5bf823231b4ae0e87db63f46bc5c7b54e0->enter($__internal_dd2f06c803a8e1ffbbb2ff6c69503f5bf823231b4ae0e87db63f46bc5c7b54e0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:ajax_layout.html.twig"));

        // line 1
        $this->displayBlock('panel', $context, $blocks);
        
        $__internal_f93181f24105cc26a7f2579a206330006c077ff2ad4dae07354e6ed1bd3043bb->leave($__internal_f93181f24105cc26a7f2579a206330006c077ff2ad4dae07354e6ed1bd3043bb_prof);

        
        $__internal_dd2f06c803a8e1ffbbb2ff6c69503f5bf823231b4ae0e87db63f46bc5c7b54e0->leave($__internal_dd2f06c803a8e1ffbbb2ff6c69503f5bf823231b4ae0e87db63f46bc5c7b54e0_prof);

    }

    public function block_panel($context, array $blocks = array())
    {
        $__internal_883c735fbeb9125454419f8b0b7c7bec8603613177cbc1eb5141bed266d3247a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_883c735fbeb9125454419f8b0b7c7bec8603613177cbc1eb5141bed266d3247a->enter($__internal_883c735fbeb9125454419f8b0b7c7bec8603613177cbc1eb5141bed266d3247a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_8cc556b550b8395b36433b1e1376d706d3b206fde6a5ebba4f44a97c2735208e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8cc556b550b8395b36433b1e1376d706d3b206fde6a5ebba4f44a97c2735208e->enter($__internal_8cc556b550b8395b36433b1e1376d706d3b206fde6a5ebba4f44a97c2735208e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        echo "";
        
        $__internal_8cc556b550b8395b36433b1e1376d706d3b206fde6a5ebba4f44a97c2735208e->leave($__internal_8cc556b550b8395b36433b1e1376d706d3b206fde6a5ebba4f44a97c2735208e_prof);

        
        $__internal_883c735fbeb9125454419f8b0b7c7bec8603613177cbc1eb5141bed266d3247a->leave($__internal_883c735fbeb9125454419f8b0b7c7bec8603613177cbc1eb5141bed266d3247a_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:ajax_layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  26 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% block panel '' %}
", "WebProfilerBundle:Profiler:ajax_layout.html.twig", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\models\\symfony\\structure\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle/Resources/views/Profiler/ajax_layout.html.twig");
    }
}
