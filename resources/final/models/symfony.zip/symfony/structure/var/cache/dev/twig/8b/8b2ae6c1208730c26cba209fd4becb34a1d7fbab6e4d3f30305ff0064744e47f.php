<?php

/* @Framework/Form/reset_widget.html.php */
class __TwigTemplate_58940593f855337d9d75604ee90768a3352995d21a47aa79598ce8f367b6c809 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_11d344af3d67cf8c35e06e8e6851d2a84d173a339cb54921f53e62c704327e10 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_11d344af3d67cf8c35e06e8e6851d2a84d173a339cb54921f53e62c704327e10->enter($__internal_11d344af3d67cf8c35e06e8e6851d2a84d173a339cb54921f53e62c704327e10_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/reset_widget.html.php"));

        $__internal_8b7e0594bfae32d09ee10183374c91b685e1067da0dd79bfbce2c2cf6f19ca06 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8b7e0594bfae32d09ee10183374c91b685e1067da0dd79bfbce2c2cf6f19ca06->enter($__internal_8b7e0594bfae32d09ee10183374c91b685e1067da0dd79bfbce2c2cf6f19ca06_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/reset_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'button_widget', array('type' => isset(\$type) ? \$type : 'reset')) ?>
";
        
        $__internal_11d344af3d67cf8c35e06e8e6851d2a84d173a339cb54921f53e62c704327e10->leave($__internal_11d344af3d67cf8c35e06e8e6851d2a84d173a339cb54921f53e62c704327e10_prof);

        
        $__internal_8b7e0594bfae32d09ee10183374c91b685e1067da0dd79bfbce2c2cf6f19ca06->leave($__internal_8b7e0594bfae32d09ee10183374c91b685e1067da0dd79bfbce2c2cf6f19ca06_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/reset_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'button_widget', array('type' => isset(\$type) ? \$type : 'reset')) ?>
", "@Framework/Form/reset_widget.html.php", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\models\\symfony\\structure\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\reset_widget.html.php");
    }
}
