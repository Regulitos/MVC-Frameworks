<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_596134ad84a45d3a703ef1c943d6679f4d623e85895794760a3bbcf0e91e4958 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ff568e8603424db7024679a413f8d21c96920eb894765a91edb3e975a6c9f50a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ff568e8603424db7024679a413f8d21c96920eb894765a91edb3e975a6c9f50a->enter($__internal_ff568e8603424db7024679a413f8d21c96920eb894765a91edb3e975a6c9f50a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $__internal_223d43d852df84b584e9fec5475d96153557f78b0d441ff776709391a4db2617 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_223d43d852df84b584e9fec5475d96153557f78b0d441ff776709391a4db2617->enter($__internal_223d43d852df84b584e9fec5475d96153557f78b0d441ff776709391a4db2617_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_ff568e8603424db7024679a413f8d21c96920eb894765a91edb3e975a6c9f50a->leave($__internal_ff568e8603424db7024679a413f8d21c96920eb894765a91edb3e975a6c9f50a_prof);

        
        $__internal_223d43d852df84b584e9fec5475d96153557f78b0d441ff776709391a4db2617->leave($__internal_223d43d852df84b584e9fec5475d96153557f78b0d441ff776709391a4db2617_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_ecc0f5d627beb062bb3e44ae608bce667684b8684f5f9d2d6a152178409d358b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ecc0f5d627beb062bb3e44ae608bce667684b8684f5f9d2d6a152178409d358b->enter($__internal_ecc0f5d627beb062bb3e44ae608bce667684b8684f5f9d2d6a152178409d358b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        $__internal_fd138e711d5bac7d5b963c03f97cde97cd17f61e2910f1a2cb2f84841eb6498a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fd138e711d5bac7d5b963c03f97cde97cd17f61e2910f1a2cb2f84841eb6498a->enter($__internal_fd138e711d5bac7d5b963c03f97cde97cd17f61e2910f1a2cb2f84841eb6498a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_fd138e711d5bac7d5b963c03f97cde97cd17f61e2910f1a2cb2f84841eb6498a->leave($__internal_fd138e711d5bac7d5b963c03f97cde97cd17f61e2910f1a2cb2f84841eb6498a_prof);

        
        $__internal_ecc0f5d627beb062bb3e44ae608bce667684b8684f5f9d2d6a152178409d358b->leave($__internal_ecc0f5d627beb062bb3e44ae608bce667684b8684f5f9d2d6a152178409d358b_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_3ef0f4839ce8f75dd6164383676b430e44f5f07c5d71af3c974ad644f48f23c4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3ef0f4839ce8f75dd6164383676b430e44f5f07c5d71af3c974ad644f48f23c4->enter($__internal_3ef0f4839ce8f75dd6164383676b430e44f5f07c5d71af3c974ad644f48f23c4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_036a7fad66db4f9658153736f0cc4ceff0359ca28bc76d7b55d919c1bfc8dfbe = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_036a7fad66db4f9658153736f0cc4ceff0359ca28bc76d7b55d919c1bfc8dfbe->enter($__internal_036a7fad66db4f9658153736f0cc4ceff0359ca28bc76d7b55d919c1bfc8dfbe_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_036a7fad66db4f9658153736f0cc4ceff0359ca28bc76d7b55d919c1bfc8dfbe->leave($__internal_036a7fad66db4f9658153736f0cc4ceff0359ca28bc76d7b55d919c1bfc8dfbe_prof);

        
        $__internal_3ef0f4839ce8f75dd6164383676b430e44f5f07c5d71af3c974ad644f48f23c4->leave($__internal_3ef0f4839ce8f75dd6164383676b430e44f5f07c5d71af3c974ad644f48f23c4_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_06c98fef4a172e4480ce469f75c428fd4262306b0fb9cf39e813ae68b1e5f026 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_06c98fef4a172e4480ce469f75c428fd4262306b0fb9cf39e813ae68b1e5f026->enter($__internal_06c98fef4a172e4480ce469f75c428fd4262306b0fb9cf39e813ae68b1e5f026_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_1616a50e3800aa482dd175a4bea8e7f3edd3aa0399f1e267427961d7769400c3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1616a50e3800aa482dd175a4bea8e7f3edd3aa0399f1e267427961d7769400c3->enter($__internal_1616a50e3800aa482dd175a4bea8e7f3edd3aa0399f1e267427961d7769400c3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_1616a50e3800aa482dd175a4bea8e7f3edd3aa0399f1e267427961d7769400c3->leave($__internal_1616a50e3800aa482dd175a4bea8e7f3edd3aa0399f1e267427961d7769400c3_prof);

        
        $__internal_06c98fef4a172e4480ce469f75c428fd4262306b0fb9cf39e813ae68b1e5f026->leave($__internal_06c98fef4a172e4480ce469f75c428fd4262306b0fb9cf39e813ae68b1e5f026_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  94 => 13,  85 => 12,  71 => 7,  68 => 6,  59 => 5,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
", "@WebProfiler/Collector/router.html.twig", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\models\\symfony\\structure\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Collector\\router.html.twig");
    }
}
