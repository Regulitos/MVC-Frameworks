<?php

/* @Framework/Form/button_label.html.php */
class __TwigTemplate_0710a0509677fc0eb5b818cff1fe5c815f5c29a8028b78066672fae900340f03 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_53f8ded4444dcc58742e7d565d63dee76f436b543aaeeb68905cebb9c52a459c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_53f8ded4444dcc58742e7d565d63dee76f436b543aaeeb68905cebb9c52a459c->enter($__internal_53f8ded4444dcc58742e7d565d63dee76f436b543aaeeb68905cebb9c52a459c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_label.html.php"));

        $__internal_261c1a754a21ab3bb870030c2784a5ccca632e9c894bc2da6afd2cc9675d22a7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_261c1a754a21ab3bb870030c2784a5ccca632e9c894bc2da6afd2cc9675d22a7->enter($__internal_261c1a754a21ab3bb870030c2784a5ccca632e9c894bc2da6afd2cc9675d22a7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_label.html.php"));

        
        $__internal_53f8ded4444dcc58742e7d565d63dee76f436b543aaeeb68905cebb9c52a459c->leave($__internal_53f8ded4444dcc58742e7d565d63dee76f436b543aaeeb68905cebb9c52a459c_prof);

        
        $__internal_261c1a754a21ab3bb870030c2784a5ccca632e9c894bc2da6afd2cc9675d22a7->leave($__internal_261c1a754a21ab3bb870030c2784a5ccca632e9c894bc2da6afd2cc9675d22a7_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_label.html.php";
    }

    public function getDebugInfo()
    {
        return array ();
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "@Framework/Form/button_label.html.php", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\models\\symfony\\structure\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\button_label.html.php");
    }
}
