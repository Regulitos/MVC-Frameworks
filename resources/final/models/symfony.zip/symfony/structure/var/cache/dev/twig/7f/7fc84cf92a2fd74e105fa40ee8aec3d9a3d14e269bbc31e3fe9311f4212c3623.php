<?php

/* @Framework/Form/widget_container_attributes.html.php */
class __TwigTemplate_1b6e41835f4598fb72cb484202e6decba551bbdec1fc800033620f1eac72e899 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_fb5bbe4c1ad9050392e365473484f12580acc4b8c1e84606bc8831992bda950b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_fb5bbe4c1ad9050392e365473484f12580acc4b8c1e84606bc8831992bda950b->enter($__internal_fb5bbe4c1ad9050392e365473484f12580acc4b8c1e84606bc8831992bda950b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/widget_container_attributes.html.php"));

        $__internal_09a24db2abfb61f79c5ec3a9b62dc1beff12dd8b16fa2c329d5cd920405c38eb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_09a24db2abfb61f79c5ec3a9b62dc1beff12dd8b16fa2c329d5cd920405c38eb->enter($__internal_09a24db2abfb61f79c5ec3a9b62dc1beff12dd8b16fa2c329d5cd920405c38eb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/widget_container_attributes.html.php"));

        // line 1
        echo "<?php if (!empty(\$id)): ?>id=\"<?php echo \$view->escape(\$id) ?>\"<?php endif ?>
<?php echo \$attr ? ' '.\$view['form']->block(\$form, 'attributes') : '' ?>
";
        
        $__internal_fb5bbe4c1ad9050392e365473484f12580acc4b8c1e84606bc8831992bda950b->leave($__internal_fb5bbe4c1ad9050392e365473484f12580acc4b8c1e84606bc8831992bda950b_prof);

        
        $__internal_09a24db2abfb61f79c5ec3a9b62dc1beff12dd8b16fa2c329d5cd920405c38eb->leave($__internal_09a24db2abfb61f79c5ec3a9b62dc1beff12dd8b16fa2c329d5cd920405c38eb_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/widget_container_attributes.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (!empty(\$id)): ?>id=\"<?php echo \$view->escape(\$id) ?>\"<?php endif ?>
<?php echo \$attr ? ' '.\$view['form']->block(\$form, 'attributes') : '' ?>
", "@Framework/Form/widget_container_attributes.html.php", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\models\\symfony\\structure\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\widget_container_attributes.html.php");
    }
}
