<?php

/* @Framework/FormTable/hidden_row.html.php */
class __TwigTemplate_cf2596bacc63137065402920d774b5256063187a65f51591cf623dd87798c29d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1b9032797c68d3131dc2140fa530d3d1ef29ef33765ae88a442570198e7d5a87 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1b9032797c68d3131dc2140fa530d3d1ef29ef33765ae88a442570198e7d5a87->enter($__internal_1b9032797c68d3131dc2140fa530d3d1ef29ef33765ae88a442570198e7d5a87_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/hidden_row.html.php"));

        $__internal_bc316ac9d6bb9957b767617de2bb7eb5b389e3d50f63352eeef0a73110567047 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_bc316ac9d6bb9957b767617de2bb7eb5b389e3d50f63352eeef0a73110567047->enter($__internal_bc316ac9d6bb9957b767617de2bb7eb5b389e3d50f63352eeef0a73110567047_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/hidden_row.html.php"));

        // line 1
        echo "<tr style=\"display: none\">
    <td colspan=\"2\">
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
";
        
        $__internal_1b9032797c68d3131dc2140fa530d3d1ef29ef33765ae88a442570198e7d5a87->leave($__internal_1b9032797c68d3131dc2140fa530d3d1ef29ef33765ae88a442570198e7d5a87_prof);

        
        $__internal_bc316ac9d6bb9957b767617de2bb7eb5b389e3d50f63352eeef0a73110567047->leave($__internal_bc316ac9d6bb9957b767617de2bb7eb5b389e3d50f63352eeef0a73110567047_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/hidden_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<tr style=\"display: none\">
    <td colspan=\"2\">
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
", "@Framework/FormTable/hidden_row.html.php", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\models\\symfony\\structure\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\FormTable\\hidden_row.html.php");
    }
}
