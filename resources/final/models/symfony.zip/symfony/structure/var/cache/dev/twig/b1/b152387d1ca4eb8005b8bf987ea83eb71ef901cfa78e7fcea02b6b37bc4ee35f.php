<?php

/* @WebProfiler/Profiler/toolbar_redirect.html.twig */
class __TwigTemplate_b3bc6c61daa78099703cd636bf909b5a35b1e5a72efb9a36c4125b567accfaa0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@Twig/layout.html.twig", "@WebProfiler/Profiler/toolbar_redirect.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@Twig/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3dab3b72148dd04ac7bdecb2792ef4af4dff8461956f3c6197f58d198dcf7080 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3dab3b72148dd04ac7bdecb2792ef4af4dff8461956f3c6197f58d198dcf7080->enter($__internal_3dab3b72148dd04ac7bdecb2792ef4af4dff8461956f3c6197f58d198dcf7080_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/toolbar_redirect.html.twig"));

        $__internal_b4c09bdabe833635ddfba46097a435551ce7ada1154cc364cf241fe83d21aa1f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b4c09bdabe833635ddfba46097a435551ce7ada1154cc364cf241fe83d21aa1f->enter($__internal_b4c09bdabe833635ddfba46097a435551ce7ada1154cc364cf241fe83d21aa1f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/toolbar_redirect.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_3dab3b72148dd04ac7bdecb2792ef4af4dff8461956f3c6197f58d198dcf7080->leave($__internal_3dab3b72148dd04ac7bdecb2792ef4af4dff8461956f3c6197f58d198dcf7080_prof);

        
        $__internal_b4c09bdabe833635ddfba46097a435551ce7ada1154cc364cf241fe83d21aa1f->leave($__internal_b4c09bdabe833635ddfba46097a435551ce7ada1154cc364cf241fe83d21aa1f_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_a96c395cdd6984ee54d385522f22ec52564022dc8a3c1d169c5f0c45e5a7e539 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a96c395cdd6984ee54d385522f22ec52564022dc8a3c1d169c5f0c45e5a7e539->enter($__internal_a96c395cdd6984ee54d385522f22ec52564022dc8a3c1d169c5f0c45e5a7e539_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_f0ee5f80f63356e1b3f283ae2b8ebf223517a8dcdd3f24f37844d8720374a4a7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f0ee5f80f63356e1b3f283ae2b8ebf223517a8dcdd3f24f37844d8720374a4a7->enter($__internal_f0ee5f80f63356e1b3f283ae2b8ebf223517a8dcdd3f24f37844d8720374a4a7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Redirection Intercepted";
        
        $__internal_f0ee5f80f63356e1b3f283ae2b8ebf223517a8dcdd3f24f37844d8720374a4a7->leave($__internal_f0ee5f80f63356e1b3f283ae2b8ebf223517a8dcdd3f24f37844d8720374a4a7_prof);

        
        $__internal_a96c395cdd6984ee54d385522f22ec52564022dc8a3c1d169c5f0c45e5a7e539->leave($__internal_a96c395cdd6984ee54d385522f22ec52564022dc8a3c1d169c5f0c45e5a7e539_prof);

    }

    // line 5
    public function block_body($context, array $blocks = array())
    {
        $__internal_7140b0a2ef26800eca22c80c552a61fa1a07d5530e4a18c1e8c3135bb1282d75 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_7140b0a2ef26800eca22c80c552a61fa1a07d5530e4a18c1e8c3135bb1282d75->enter($__internal_7140b0a2ef26800eca22c80c552a61fa1a07d5530e4a18c1e8c3135bb1282d75_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_d519ae586cc7b7438c45d5efbcea22ce3129b4eecdb9e8fb8d833b81735ea4ad = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d519ae586cc7b7438c45d5efbcea22ce3129b4eecdb9e8fb8d833b81735ea4ad->enter($__internal_d519ae586cc7b7438c45d5efbcea22ce3129b4eecdb9e8fb8d833b81735ea4ad_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "    <div class=\"sf-reset\">
        <div class=\"block-exception\">
            <h1>This request redirects to <a href=\"";
        // line 8
        echo twig_escape_filter($this->env, ($context["location"] ?? $this->getContext($context, "location")), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, ($context["location"] ?? $this->getContext($context, "location")), "html", null, true);
        echo "</a>.</h1>

            <p>
                <small>
                    The redirect was intercepted by the web debug toolbar to help debugging.
                    For more information, see the \"intercept-redirects\" option of the Profiler.
                </small>
            </p>
        </div>
    </div>
";
        
        $__internal_d519ae586cc7b7438c45d5efbcea22ce3129b4eecdb9e8fb8d833b81735ea4ad->leave($__internal_d519ae586cc7b7438c45d5efbcea22ce3129b4eecdb9e8fb8d833b81735ea4ad_prof);

        
        $__internal_7140b0a2ef26800eca22c80c552a61fa1a07d5530e4a18c1e8c3135bb1282d75->leave($__internal_7140b0a2ef26800eca22c80c552a61fa1a07d5530e4a18c1e8c3135bb1282d75_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Profiler/toolbar_redirect.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  72 => 8,  68 => 6,  59 => 5,  41 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@Twig/layout.html.twig' %}

{% block title 'Redirection Intercepted' %}

{% block body %}
    <div class=\"sf-reset\">
        <div class=\"block-exception\">
            <h1>This request redirects to <a href=\"{{ location }}\">{{ location }}</a>.</h1>

            <p>
                <small>
                    The redirect was intercepted by the web debug toolbar to help debugging.
                    For more information, see the \"intercept-redirects\" option of the Profiler.
                </small>
            </p>
        </div>
    </div>
{% endblock %}
", "@WebProfiler/Profiler/toolbar_redirect.html.twig", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\models\\symfony\\structure\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Profiler\\toolbar_redirect.html.twig");
    }
}
