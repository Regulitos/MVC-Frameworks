<?php

/* @Framework/Form/hidden_widget.html.php */
class __TwigTemplate_ef0e02473280788a3697a14c8764ae33e7774eed4d262bda3aac5633e3cefc7d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_12b05502a110275c2f43701767f4d08c556d86f3c0109d1097abb72cc62a07d3 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_12b05502a110275c2f43701767f4d08c556d86f3c0109d1097abb72cc62a07d3->enter($__internal_12b05502a110275c2f43701767f4d08c556d86f3c0109d1097abb72cc62a07d3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/hidden_widget.html.php"));

        $__internal_3006ec106469ff340f8dad66204a66a2ca54b617e627533fe180b623ae0789f6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3006ec106469ff340f8dad66204a66a2ca54b617e627533fe180b623ae0789f6->enter($__internal_3006ec106469ff340f8dad66204a66a2ca54b617e627533fe180b623ae0789f6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/hidden_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'hidden')) ?>
";
        
        $__internal_12b05502a110275c2f43701767f4d08c556d86f3c0109d1097abb72cc62a07d3->leave($__internal_12b05502a110275c2f43701767f4d08c556d86f3c0109d1097abb72cc62a07d3_prof);

        
        $__internal_3006ec106469ff340f8dad66204a66a2ca54b617e627533fe180b623ae0789f6->leave($__internal_3006ec106469ff340f8dad66204a66a2ca54b617e627533fe180b623ae0789f6_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/hidden_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'hidden')) ?>
", "@Framework/Form/hidden_widget.html.php", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\models\\symfony\\structure\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\hidden_widget.html.php");
    }
}
