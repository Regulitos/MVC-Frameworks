<?php

/* @Framework/Form/form_rest.html.php */
class __TwigTemplate_d93b5124d1343930b9de507e1d72d484371ea043cf13b9586b3e65790345dd86 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_991166eb397d46c2b627e4b833b055169245cfd6ec10d2b228e5dbac086c2f51 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_991166eb397d46c2b627e4b833b055169245cfd6ec10d2b228e5dbac086c2f51->enter($__internal_991166eb397d46c2b627e4b833b055169245cfd6ec10d2b228e5dbac086c2f51_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_rest.html.php"));

        $__internal_88291b1b984ab8a3318cfd2f4719282d9987de4dde4353c867bd5e8d13289a9e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_88291b1b984ab8a3318cfd2f4719282d9987de4dde4353c867bd5e8d13289a9e->enter($__internal_88291b1b984ab8a3318cfd2f4719282d9987de4dde4353c867bd5e8d13289a9e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_rest.html.php"));

        // line 1
        echo "<?php foreach (\$form as \$child): ?>
    <?php if (!\$child->isRendered()): ?>
        <?php echo \$view['form']->row(\$child) ?>
    <?php endif; ?>
<?php endforeach; ?>
";
        
        $__internal_991166eb397d46c2b627e4b833b055169245cfd6ec10d2b228e5dbac086c2f51->leave($__internal_991166eb397d46c2b627e4b833b055169245cfd6ec10d2b228e5dbac086c2f51_prof);

        
        $__internal_88291b1b984ab8a3318cfd2f4719282d9987de4dde4353c867bd5e8d13289a9e->leave($__internal_88291b1b984ab8a3318cfd2f4719282d9987de4dde4353c867bd5e8d13289a9e_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_rest.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php foreach (\$form as \$child): ?>
    <?php if (!\$child->isRendered()): ?>
        <?php echo \$view['form']->row(\$child) ?>
    <?php endif; ?>
<?php endforeach; ?>
", "@Framework/Form/form_rest.html.php", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\models\\symfony\\structure\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\form_rest.html.php");
    }
}
