<?php

/* @Framework/Form/choice_attributes.html.php */
class __TwigTemplate_082a7da862c6e8763bec466c7e10b27f3ea4498bbe37edd1b2a4c7d01af07aa0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7b6ffbcb1094bc4d2026a5853f9e7adf0b3063c4dc8401a4d79bab6e7c6a6032 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_7b6ffbcb1094bc4d2026a5853f9e7adf0b3063c4dc8401a4d79bab6e7c6a6032->enter($__internal_7b6ffbcb1094bc4d2026a5853f9e7adf0b3063c4dc8401a4d79bab6e7c6a6032_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_attributes.html.php"));

        $__internal_825ed961eadd14a71267242e14998d3d859c27f5075f5b573d16ffa978a4ce6c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_825ed961eadd14a71267242e14998d3d859c27f5075f5b573d16ffa978a4ce6c->enter($__internal_825ed961eadd14a71267242e14998d3d859c27f5075f5b573d16ffa978a4ce6c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_attributes.html.php"));

        // line 1
        echo "<?php if (\$disabled): ?>disabled=\"disabled\" <?php endif ?>
<?php foreach (\$choice_attr as \$k => \$v): ?>
<?php if (\$v === true): ?>
<?php printf('%s=\"%s\" ', \$view->escape(\$k), \$view->escape(\$k)) ?>
<?php elseif (\$v !== false): ?>
<?php printf('%s=\"%s\" ', \$view->escape(\$k), \$view->escape(\$v)) ?>
<?php endif ?>
<?php endforeach ?>
";
        
        $__internal_7b6ffbcb1094bc4d2026a5853f9e7adf0b3063c4dc8401a4d79bab6e7c6a6032->leave($__internal_7b6ffbcb1094bc4d2026a5853f9e7adf0b3063c4dc8401a4d79bab6e7c6a6032_prof);

        
        $__internal_825ed961eadd14a71267242e14998d3d859c27f5075f5b573d16ffa978a4ce6c->leave($__internal_825ed961eadd14a71267242e14998d3d859c27f5075f5b573d16ffa978a4ce6c_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/choice_attributes.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (\$disabled): ?>disabled=\"disabled\" <?php endif ?>
<?php foreach (\$choice_attr as \$k => \$v): ?>
<?php if (\$v === true): ?>
<?php printf('%s=\"%s\" ', \$view->escape(\$k), \$view->escape(\$k)) ?>
<?php elseif (\$v !== false): ?>
<?php printf('%s=\"%s\" ', \$view->escape(\$k), \$view->escape(\$v)) ?>
<?php endif ?>
<?php endforeach ?>
", "@Framework/Form/choice_attributes.html.php", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\models\\symfony\\structure\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\choice_attributes.html.php");
    }
}
