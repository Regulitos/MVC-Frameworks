<?php

/* @Framework/Form/repeated_row.html.php */
class __TwigTemplate_3d206093c01bde614dd5f7f2051942fddf01f2a533f1e9edcb39b5be2ec6f34e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_acfba2be6fff745eb02a4c0f52b6953d711c33108e45ecfdcf339331ff5a4d07 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_acfba2be6fff745eb02a4c0f52b6953d711c33108e45ecfdcf339331ff5a4d07->enter($__internal_acfba2be6fff745eb02a4c0f52b6953d711c33108e45ecfdcf339331ff5a4d07_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/repeated_row.html.php"));

        $__internal_3db6e4129a4779d4b510fc4920bd4e29d4d5b3aa72bda83d63786722d9fd4c06 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3db6e4129a4779d4b510fc4920bd4e29d4d5b3aa72bda83d63786722d9fd4c06->enter($__internal_3db6e4129a4779d4b510fc4920bd4e29d4d5b3aa72bda83d63786722d9fd4c06_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/repeated_row.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_rows') ?>
";
        
        $__internal_acfba2be6fff745eb02a4c0f52b6953d711c33108e45ecfdcf339331ff5a4d07->leave($__internal_acfba2be6fff745eb02a4c0f52b6953d711c33108e45ecfdcf339331ff5a4d07_prof);

        
        $__internal_3db6e4129a4779d4b510fc4920bd4e29d4d5b3aa72bda83d63786722d9fd4c06->leave($__internal_3db6e4129a4779d4b510fc4920bd4e29d4d5b3aa72bda83d63786722d9fd4c06_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/repeated_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_rows') ?>
", "@Framework/Form/repeated_row.html.php", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\models\\symfony\\structure\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\repeated_row.html.php");
    }
}
