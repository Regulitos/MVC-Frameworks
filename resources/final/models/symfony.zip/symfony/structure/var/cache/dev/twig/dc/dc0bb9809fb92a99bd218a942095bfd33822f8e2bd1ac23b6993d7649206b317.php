<?php

/* ::base.html.twig */
class __TwigTemplate_aaa161c310dcecf2b0607299d5353c510065f9384a93e27c9013c98e455d9322 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_61163a767d4e8bef763d3741e815f6e038103e5d31c6a0d107b2e37029536734 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_61163a767d4e8bef763d3741e815f6e038103e5d31c6a0d107b2e37029536734->enter($__internal_61163a767d4e8bef763d3741e815f6e038103e5d31c6a0d107b2e37029536734_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::base.html.twig"));

        $__internal_f7fd7d2a61a99ec681d2533fc85dcf356064b1c699132de9d8c1277821bcdb53 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f7fd7d2a61a99ec681d2533fc85dcf356064b1c699132de9d8c1277821bcdb53->enter($__internal_f7fd7d2a61a99ec681d2533fc85dcf356064b1c699132de9d8c1277821bcdb53_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>";
        // line 5
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        ";
        // line 6
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 7
        echo "        <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />
    </head>
    <body>
        ";
        // line 10
        $this->displayBlock('body', $context, $blocks);
        // line 11
        echo "        ";
        $this->displayBlock('javascripts', $context, $blocks);
        // line 12
        echo "    </body>
</html>
";
        
        $__internal_61163a767d4e8bef763d3741e815f6e038103e5d31c6a0d107b2e37029536734->leave($__internal_61163a767d4e8bef763d3741e815f6e038103e5d31c6a0d107b2e37029536734_prof);

        
        $__internal_f7fd7d2a61a99ec681d2533fc85dcf356064b1c699132de9d8c1277821bcdb53->leave($__internal_f7fd7d2a61a99ec681d2533fc85dcf356064b1c699132de9d8c1277821bcdb53_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_1762d05c9e585f11e959e76c9192d3cecfde4864290126c2c7eef7d26a13ffde = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1762d05c9e585f11e959e76c9192d3cecfde4864290126c2c7eef7d26a13ffde->enter($__internal_1762d05c9e585f11e959e76c9192d3cecfde4864290126c2c7eef7d26a13ffde_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_e7c9afba96e28706234eed5775172ac66c0d23d773520581d6fc99f61f12f687 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e7c9afba96e28706234eed5775172ac66c0d23d773520581d6fc99f61f12f687->enter($__internal_e7c9afba96e28706234eed5775172ac66c0d23d773520581d6fc99f61f12f687_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Welcome!";
        
        $__internal_e7c9afba96e28706234eed5775172ac66c0d23d773520581d6fc99f61f12f687->leave($__internal_e7c9afba96e28706234eed5775172ac66c0d23d773520581d6fc99f61f12f687_prof);

        
        $__internal_1762d05c9e585f11e959e76c9192d3cecfde4864290126c2c7eef7d26a13ffde->leave($__internal_1762d05c9e585f11e959e76c9192d3cecfde4864290126c2c7eef7d26a13ffde_prof);

    }

    // line 6
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_e372674272a1f9ea7709de093aabcc4c8c330b7a402d47bf4686d2c99dfae8f4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e372674272a1f9ea7709de093aabcc4c8c330b7a402d47bf4686d2c99dfae8f4->enter($__internal_e372674272a1f9ea7709de093aabcc4c8c330b7a402d47bf4686d2c99dfae8f4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_700aa97f1f83b0a76f697fe67487917356f04d05a32cce682583482befeeee61 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_700aa97f1f83b0a76f697fe67487917356f04d05a32cce682583482befeeee61->enter($__internal_700aa97f1f83b0a76f697fe67487917356f04d05a32cce682583482befeeee61_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_700aa97f1f83b0a76f697fe67487917356f04d05a32cce682583482befeeee61->leave($__internal_700aa97f1f83b0a76f697fe67487917356f04d05a32cce682583482befeeee61_prof);

        
        $__internal_e372674272a1f9ea7709de093aabcc4c8c330b7a402d47bf4686d2c99dfae8f4->leave($__internal_e372674272a1f9ea7709de093aabcc4c8c330b7a402d47bf4686d2c99dfae8f4_prof);

    }

    // line 10
    public function block_body($context, array $blocks = array())
    {
        $__internal_bc0722d66250fde1b049cf73e50f6610cf0819eaf566a03cc6156027de6496b4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_bc0722d66250fde1b049cf73e50f6610cf0819eaf566a03cc6156027de6496b4->enter($__internal_bc0722d66250fde1b049cf73e50f6610cf0819eaf566a03cc6156027de6496b4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_e3efa5c6926a4b7f9658497f6b5312ba4bdeaa91d62e402964f47176baf32358 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e3efa5c6926a4b7f9658497f6b5312ba4bdeaa91d62e402964f47176baf32358->enter($__internal_e3efa5c6926a4b7f9658497f6b5312ba4bdeaa91d62e402964f47176baf32358_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_e3efa5c6926a4b7f9658497f6b5312ba4bdeaa91d62e402964f47176baf32358->leave($__internal_e3efa5c6926a4b7f9658497f6b5312ba4bdeaa91d62e402964f47176baf32358_prof);

        
        $__internal_bc0722d66250fde1b049cf73e50f6610cf0819eaf566a03cc6156027de6496b4->leave($__internal_bc0722d66250fde1b049cf73e50f6610cf0819eaf566a03cc6156027de6496b4_prof);

    }

    // line 11
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_83510e0efa5c42369d31f284aac9989bbaf01c6b016b9302083873c4cb023662 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_83510e0efa5c42369d31f284aac9989bbaf01c6b016b9302083873c4cb023662->enter($__internal_83510e0efa5c42369d31f284aac9989bbaf01c6b016b9302083873c4cb023662_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_0ba0913342669e1cffcdee46979328f723e8135313a7b32a9ab5c5da44533172 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0ba0913342669e1cffcdee46979328f723e8135313a7b32a9ab5c5da44533172->enter($__internal_0ba0913342669e1cffcdee46979328f723e8135313a7b32a9ab5c5da44533172_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_0ba0913342669e1cffcdee46979328f723e8135313a7b32a9ab5c5da44533172->leave($__internal_0ba0913342669e1cffcdee46979328f723e8135313a7b32a9ab5c5da44533172_prof);

        
        $__internal_83510e0efa5c42369d31f284aac9989bbaf01c6b016b9302083873c4cb023662->leave($__internal_83510e0efa5c42369d31f284aac9989bbaf01c6b016b9302083873c4cb023662_prof);

    }

    public function getTemplateName()
    {
        return "::base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  117 => 11,  100 => 10,  83 => 6,  65 => 5,  53 => 12,  50 => 11,  48 => 10,  41 => 7,  39 => 6,  35 => 5,  29 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>{% block title %}Welcome!{% endblock %}</title>
        {% block stylesheets %}{% endblock %}
        <link rel=\"icon\" type=\"image/x-icon\" href=\"{{ asset('favicon.ico') }}\" />
    </head>
    <body>
        {% block body %}{% endblock %}
        {% block javascripts %}{% endblock %}
    </body>
</html>
", "::base.html.twig", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\models\\symfony\\structure\\app/Resources\\views/base.html.twig");
    }
}
