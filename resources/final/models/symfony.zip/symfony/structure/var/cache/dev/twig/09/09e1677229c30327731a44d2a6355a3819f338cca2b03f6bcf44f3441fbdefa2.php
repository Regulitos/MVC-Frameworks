<?php

/* TwigBundle:Exception:exception.rdf.twig */
class __TwigTemplate_179cbaea0a8bb4615471c354ca9447064c125c526a4b8e1012b95aeec811cf13 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3061bf84ba798213e3ded1b5eccba7755887ed8a9b2ad97c1c2f39320a13bade = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3061bf84ba798213e3ded1b5eccba7755887ed8a9b2ad97c1c2f39320a13bade->enter($__internal_3061bf84ba798213e3ded1b5eccba7755887ed8a9b2ad97c1c2f39320a13bade_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.rdf.twig"));

        $__internal_8bcc2bffe862aac6faa973fc42d63d4a54f9fde5d4ba716980fee943b381b5e8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8bcc2bffe862aac6faa973fc42d63d4a54f9fde5d4ba716980fee943b381b5e8->enter($__internal_8bcc2bffe862aac6faa973fc42d63d4a54f9fde5d4ba716980fee943b381b5e8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.rdf.twig"));

        // line 1
        echo twig_include($this->env, $context, "@Twig/Exception/exception.xml.twig", array("exception" => ($context["exception"] ?? $this->getContext($context, "exception"))));
        echo "
";
        
        $__internal_3061bf84ba798213e3ded1b5eccba7755887ed8a9b2ad97c1c2f39320a13bade->leave($__internal_3061bf84ba798213e3ded1b5eccba7755887ed8a9b2ad97c1c2f39320a13bade_prof);

        
        $__internal_8bcc2bffe862aac6faa973fc42d63d4a54f9fde5d4ba716980fee943b381b5e8->leave($__internal_8bcc2bffe862aac6faa973fc42d63d4a54f9fde5d4ba716980fee943b381b5e8_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.rdf.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ include('@Twig/Exception/exception.xml.twig', { exception: exception }) }}
", "TwigBundle:Exception:exception.rdf.twig", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\models\\symfony\\structure\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle/Resources/views/Exception/exception.rdf.twig");
    }
}
