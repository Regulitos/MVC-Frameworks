<?php

/* @Framework/Form/number_widget.html.php */
class __TwigTemplate_2d8e03f09f06232ce97d21b9a7e8f5cce9993c8f2c736bf4529a6c1282500ab3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7f91e2cdf9a6b2a992a707237693d4e24453272ae516f4a6e587fb35ccff0313 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_7f91e2cdf9a6b2a992a707237693d4e24453272ae516f4a6e587fb35ccff0313->enter($__internal_7f91e2cdf9a6b2a992a707237693d4e24453272ae516f4a6e587fb35ccff0313_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/number_widget.html.php"));

        $__internal_7f8ad15ec9e5ec051b7c8d9479a730770057c75cf3fc9e4d57fdc126681d3669 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7f8ad15ec9e5ec051b7c8d9479a730770057c75cf3fc9e4d57fdc126681d3669->enter($__internal_7f8ad15ec9e5ec051b7c8d9479a730770057c75cf3fc9e4d57fdc126681d3669_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/number_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'text')) ?>
";
        
        $__internal_7f91e2cdf9a6b2a992a707237693d4e24453272ae516f4a6e587fb35ccff0313->leave($__internal_7f91e2cdf9a6b2a992a707237693d4e24453272ae516f4a6e587fb35ccff0313_prof);

        
        $__internal_7f8ad15ec9e5ec051b7c8d9479a730770057c75cf3fc9e4d57fdc126681d3669->leave($__internal_7f8ad15ec9e5ec051b7c8d9479a730770057c75cf3fc9e4d57fdc126681d3669_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/number_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'text')) ?>
", "@Framework/Form/number_widget.html.php", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\models\\symfony\\structure\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\number_widget.html.php");
    }
}
