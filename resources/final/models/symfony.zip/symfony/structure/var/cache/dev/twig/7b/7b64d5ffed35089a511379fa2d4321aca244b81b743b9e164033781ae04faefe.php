<?php

/* @WebProfiler/Profiler/open.html.twig */
class __TwigTemplate_02a887d4589b168b4292e6617e38c6962d99bad21ae0097b64a11bc6d3bf9a91 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/base.html.twig", "@WebProfiler/Profiler/open.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2e326e8585516f05c34445df9fa51f8cd91064fbc53f74623e51b89ef4be4bfb = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2e326e8585516f05c34445df9fa51f8cd91064fbc53f74623e51b89ef4be4bfb->enter($__internal_2e326e8585516f05c34445df9fa51f8cd91064fbc53f74623e51b89ef4be4bfb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/open.html.twig"));

        $__internal_fb43b9421f6d70df01243d4013314897222940622dfb2add5215be9894aa6e4d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fb43b9421f6d70df01243d4013314897222940622dfb2add5215be9894aa6e4d->enter($__internal_fb43b9421f6d70df01243d4013314897222940622dfb2add5215be9894aa6e4d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/open.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_2e326e8585516f05c34445df9fa51f8cd91064fbc53f74623e51b89ef4be4bfb->leave($__internal_2e326e8585516f05c34445df9fa51f8cd91064fbc53f74623e51b89ef4be4bfb_prof);

        
        $__internal_fb43b9421f6d70df01243d4013314897222940622dfb2add5215be9894aa6e4d->leave($__internal_fb43b9421f6d70df01243d4013314897222940622dfb2add5215be9894aa6e4d_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_e6d33a2d025d0940c99d68ff05044d41e1ef6c76964126c5c10b99a872feadd0 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e6d33a2d025d0940c99d68ff05044d41e1ef6c76964126c5c10b99a872feadd0->enter($__internal_e6d33a2d025d0940c99d68ff05044d41e1ef6c76964126c5c10b99a872feadd0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        $__internal_b2821a16bdeeafa85b83a61700e68f96c63c51f0d89fb645ff33f86873f9dfb9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b2821a16bdeeafa85b83a61700e68f96c63c51f0d89fb645ff33f86873f9dfb9->enter($__internal_b2821a16bdeeafa85b83a61700e68f96c63c51f0d89fb645ff33f86873f9dfb9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    <style>
        ";
        // line 5
        echo twig_include($this->env, $context, "@WebProfiler/Profiler/open.css.twig");
        echo "
    </style>
";
        
        $__internal_b2821a16bdeeafa85b83a61700e68f96c63c51f0d89fb645ff33f86873f9dfb9->leave($__internal_b2821a16bdeeafa85b83a61700e68f96c63c51f0d89fb645ff33f86873f9dfb9_prof);

        
        $__internal_e6d33a2d025d0940c99d68ff05044d41e1ef6c76964126c5c10b99a872feadd0->leave($__internal_e6d33a2d025d0940c99d68ff05044d41e1ef6c76964126c5c10b99a872feadd0_prof);

    }

    // line 9
    public function block_body($context, array $blocks = array())
    {
        $__internal_e69d20ee9c25c5e001d8d414e9ab66bff3aa9e2c7225f56191c850aeb18bdde5 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e69d20ee9c25c5e001d8d414e9ab66bff3aa9e2c7225f56191c850aeb18bdde5->enter($__internal_e69d20ee9c25c5e001d8d414e9ab66bff3aa9e2c7225f56191c850aeb18bdde5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_07ac881f4c13977600447b3fd617298d5f00c01bcfdca4fce31072ca33679d5a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_07ac881f4c13977600447b3fd617298d5f00c01bcfdca4fce31072ca33679d5a->enter($__internal_07ac881f4c13977600447b3fd617298d5f00c01bcfdca4fce31072ca33679d5a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 10
        echo "<div class=\"header\">
    <h1>";
        // line 11
        echo twig_escape_filter($this->env, ($context["file"] ?? $this->getContext($context, "file")), "html", null, true);
        echo " <small>line ";
        echo twig_escape_filter($this->env, ($context["line"] ?? $this->getContext($context, "line")), "html", null, true);
        echo "</small></h1>
    <a class=\"doc\" href=\"https://symfony.com/doc/";
        // line 12
        echo twig_escape_filter($this->env, twig_constant("Symfony\\Component\\HttpKernel\\Kernel::VERSION"), "html", null, true);
        echo "/reference/configuration/framework.html#ide\" rel=\"help\">Open in your IDE?</a>
</div>
<div class=\"source\">
    ";
        // line 15
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\CodeExtension')->fileExcerpt(($context["filename"] ?? $this->getContext($context, "filename")), ($context["line"] ?? $this->getContext($context, "line")),  -1);
        echo "
</div>
";
        
        $__internal_07ac881f4c13977600447b3fd617298d5f00c01bcfdca4fce31072ca33679d5a->leave($__internal_07ac881f4c13977600447b3fd617298d5f00c01bcfdca4fce31072ca33679d5a_prof);

        
        $__internal_e69d20ee9c25c5e001d8d414e9ab66bff3aa9e2c7225f56191c850aeb18bdde5->leave($__internal_e69d20ee9c25c5e001d8d414e9ab66bff3aa9e2c7225f56191c850aeb18bdde5_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Profiler/open.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  90 => 15,  84 => 12,  78 => 11,  75 => 10,  66 => 9,  53 => 5,  50 => 4,  41 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/base.html.twig' %}

{% block head %}
    <style>
        {{ include('@WebProfiler/Profiler/open.css.twig') }}
    </style>
{% endblock %}

{% block body %}
<div class=\"header\">
    <h1>{{ file }} <small>line {{ line }}</small></h1>
    <a class=\"doc\" href=\"https://symfony.com/doc/{{ constant('Symfony\\\\Component\\\\HttpKernel\\\\Kernel::VERSION') }}/reference/configuration/framework.html#ide\" rel=\"help\">Open in your IDE?</a>
</div>
<div class=\"source\">
    {{ filename|file_excerpt(line, -1) }}
</div>
{% endblock %}
", "@WebProfiler/Profiler/open.html.twig", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\models\\symfony\\structure\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Profiler\\open.html.twig");
    }
}
