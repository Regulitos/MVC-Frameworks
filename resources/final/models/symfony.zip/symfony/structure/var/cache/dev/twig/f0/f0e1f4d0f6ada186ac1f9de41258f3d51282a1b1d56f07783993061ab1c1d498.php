<?php

/* WebProfilerBundle:Collector:router.html.twig */
class __TwigTemplate_afa9d77af99b48c2619f3c3857d2b04f85db861a56de9ca9c3f17809fac7a49b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "WebProfilerBundle:Collector:router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a697d96cfeb1510f4badd177a01f614d6d1bfff6d9680ddbc33eaff9891f66d1 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a697d96cfeb1510f4badd177a01f614d6d1bfff6d9680ddbc33eaff9891f66d1->enter($__internal_a697d96cfeb1510f4badd177a01f614d6d1bfff6d9680ddbc33eaff9891f66d1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Collector:router.html.twig"));

        $__internal_77f3ed1d63547cb3ed822a28bc257f5480c17fe70a4c3aabcdd96955f0fcf6f4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_77f3ed1d63547cb3ed822a28bc257f5480c17fe70a4c3aabcdd96955f0fcf6f4->enter($__internal_77f3ed1d63547cb3ed822a28bc257f5480c17fe70a4c3aabcdd96955f0fcf6f4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Collector:router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_a697d96cfeb1510f4badd177a01f614d6d1bfff6d9680ddbc33eaff9891f66d1->leave($__internal_a697d96cfeb1510f4badd177a01f614d6d1bfff6d9680ddbc33eaff9891f66d1_prof);

        
        $__internal_77f3ed1d63547cb3ed822a28bc257f5480c17fe70a4c3aabcdd96955f0fcf6f4->leave($__internal_77f3ed1d63547cb3ed822a28bc257f5480c17fe70a4c3aabcdd96955f0fcf6f4_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_b8884b9649b3f4b7a66eeef702a9d88bc75b9201a2cceaf241673089c125cb2f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b8884b9649b3f4b7a66eeef702a9d88bc75b9201a2cceaf241673089c125cb2f->enter($__internal_b8884b9649b3f4b7a66eeef702a9d88bc75b9201a2cceaf241673089c125cb2f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        $__internal_c8a71bfe586f36230c845de3ab556d7bb329b376ff96ef427e89e1ae6127e320 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c8a71bfe586f36230c845de3ab556d7bb329b376ff96ef427e89e1ae6127e320->enter($__internal_c8a71bfe586f36230c845de3ab556d7bb329b376ff96ef427e89e1ae6127e320_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_c8a71bfe586f36230c845de3ab556d7bb329b376ff96ef427e89e1ae6127e320->leave($__internal_c8a71bfe586f36230c845de3ab556d7bb329b376ff96ef427e89e1ae6127e320_prof);

        
        $__internal_b8884b9649b3f4b7a66eeef702a9d88bc75b9201a2cceaf241673089c125cb2f->leave($__internal_b8884b9649b3f4b7a66eeef702a9d88bc75b9201a2cceaf241673089c125cb2f_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_cc9a93b6de84a8da16e728c45daa4e3af4e8fab4375bc2748fa8217ce09b8070 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_cc9a93b6de84a8da16e728c45daa4e3af4e8fab4375bc2748fa8217ce09b8070->enter($__internal_cc9a93b6de84a8da16e728c45daa4e3af4e8fab4375bc2748fa8217ce09b8070_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_7da8f684adace49110d0035d316c332e379218da18747c16a031c55488e5e857 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7da8f684adace49110d0035d316c332e379218da18747c16a031c55488e5e857->enter($__internal_7da8f684adace49110d0035d316c332e379218da18747c16a031c55488e5e857_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_7da8f684adace49110d0035d316c332e379218da18747c16a031c55488e5e857->leave($__internal_7da8f684adace49110d0035d316c332e379218da18747c16a031c55488e5e857_prof);

        
        $__internal_cc9a93b6de84a8da16e728c45daa4e3af4e8fab4375bc2748fa8217ce09b8070->leave($__internal_cc9a93b6de84a8da16e728c45daa4e3af4e8fab4375bc2748fa8217ce09b8070_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_01d15fe33d4f0d177f0e347e273d391120d65d1bdd69de64950ca8046b45f0ed = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_01d15fe33d4f0d177f0e347e273d391120d65d1bdd69de64950ca8046b45f0ed->enter($__internal_01d15fe33d4f0d177f0e347e273d391120d65d1bdd69de64950ca8046b45f0ed_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_6f928106b65b0cce3b41d0ea4a3d997af4317306cf3f1872462aa69027d9e70e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6f928106b65b0cce3b41d0ea4a3d997af4317306cf3f1872462aa69027d9e70e->enter($__internal_6f928106b65b0cce3b41d0ea4a3d997af4317306cf3f1872462aa69027d9e70e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_6f928106b65b0cce3b41d0ea4a3d997af4317306cf3f1872462aa69027d9e70e->leave($__internal_6f928106b65b0cce3b41d0ea4a3d997af4317306cf3f1872462aa69027d9e70e_prof);

        
        $__internal_01d15fe33d4f0d177f0e347e273d391120d65d1bdd69de64950ca8046b45f0ed->leave($__internal_01d15fe33d4f0d177f0e347e273d391120d65d1bdd69de64950ca8046b45f0ed_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Collector:router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  94 => 13,  85 => 12,  71 => 7,  68 => 6,  59 => 5,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
", "WebProfilerBundle:Collector:router.html.twig", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\models\\symfony\\structure\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle/Resources/views/Collector/router.html.twig");
    }
}
