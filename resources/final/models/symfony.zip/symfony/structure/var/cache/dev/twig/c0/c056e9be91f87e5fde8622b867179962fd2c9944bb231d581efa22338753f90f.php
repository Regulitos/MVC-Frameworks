<?php

/* TwigBundle:Exception:error.rdf.twig */
class __TwigTemplate_26edb4916903690e4fa175d2997e52784c4ac4cddc89b07f3700cfc3850459e3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b30ab6b16e574be57f1dc5a82a8050a936f678731d0a7cbfbeab69dfee12f5f7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b30ab6b16e574be57f1dc5a82a8050a936f678731d0a7cbfbeab69dfee12f5f7->enter($__internal_b30ab6b16e574be57f1dc5a82a8050a936f678731d0a7cbfbeab69dfee12f5f7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.rdf.twig"));

        $__internal_db7e257925aad4ebe4228f9d67081ef7faa6cad88b37d4e1660d30a1b2739ff1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_db7e257925aad4ebe4228f9d67081ef7faa6cad88b37d4e1660d30a1b2739ff1->enter($__internal_db7e257925aad4ebe4228f9d67081ef7faa6cad88b37d4e1660d30a1b2739ff1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.rdf.twig"));

        // line 1
        echo twig_include($this->env, $context, "@Twig/Exception/error.xml.twig");
        echo "
";
        
        $__internal_b30ab6b16e574be57f1dc5a82a8050a936f678731d0a7cbfbeab69dfee12f5f7->leave($__internal_b30ab6b16e574be57f1dc5a82a8050a936f678731d0a7cbfbeab69dfee12f5f7_prof);

        
        $__internal_db7e257925aad4ebe4228f9d67081ef7faa6cad88b37d4e1660d30a1b2739ff1->leave($__internal_db7e257925aad4ebe4228f9d67081ef7faa6cad88b37d4e1660d30a1b2739ff1_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.rdf.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ include('@Twig/Exception/error.xml.twig') }}
", "TwigBundle:Exception:error.rdf.twig", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\models\\symfony\\structure\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle/Resources/views/Exception/error.rdf.twig");
    }
}
