<?php
class Client_model extends CI_Model 
{

        public $table = 'clients';

        public function __construct()
        {

                parent::__construct();

        }


        public function all()
        {
                $query = $this->db->get($this->table);
                return $query->result_array();
        }

        public function find( $id )
        {
                $query = $this->db
                ->where('id', $id)
                ->get($this->table);
                return $query->row_array();
        }

}