<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Clients extends CI_Controller {

	public function __construct()
        {

                parent::__construct();
				$this->load->model('Client_model');

        }

	var $clients = [ 
                    [ 'id' => 0 , 'name' => 'Emmett', 'last_name' => 'Brown', 'email' => 'emmett@domain.com' ] ,
                    [ 'id' => 1 , 'name' => 'Jennifer', 'last_name' => 'Parker', 'email' => 'jennifer@domain.com' ] ,
                ];

	public function index()
	{
		//echo 'New controller index method';
		$clients = $this->Client_model->all();
		$this->load->view('clients/index', [ 'clients' => $clients ] );
	}

	public function details($id)
	{

		//echo 'Id: ' . $id;
		$clients = $this->Client_model->find($id);
		$this->load->view('clients/details', [ 'client' => $clients  ]);

	}
}
