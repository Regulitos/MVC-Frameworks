<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ClientsController extends Controller
{
    var $clients = [ 
                    [ 'id' => 0 , 'name' => 'Emmett', 'last_name' => 'Brown', 'email' => 'emmett@domain.com' ] ,
                    [ 'id' => 1 , 'name' => 'Jennifer', 'last_name' => 'Parker', 'email' => 'jennifer@domain.com' ] ,
                ];
    //
    public function index()
    {
        //return 'New Controller method index';

        return view('clients/index', [ 'clients' => $this->clients ]  );
    }

    public function details( $id )
    {
        //return 'Id: ' . $id;
        return view('clients/details');
    }
}
