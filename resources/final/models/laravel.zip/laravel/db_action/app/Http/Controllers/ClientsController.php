<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Client as Client;

class ClientsController extends Controller
{

    //
    public function index()
    {
        //return 'New Controller method index';
        $client = new Client;
        $clients = $client->all();

        return view('clients/index', [ 'clients' => $clients ]  );
    }

    public function details( $id )
    {
        //return 'Id: ' . $id;
        $client = new Client;
        $clients = $client->find( $id );
        return view('clients/details', [ 'client' => $clients ]);
    }
}
