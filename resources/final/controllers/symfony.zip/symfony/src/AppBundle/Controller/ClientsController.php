<?php

namespace AppBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Component\HttpFoundation\Response;


class ClientsController extends Controller
{
    /**
     * @Route("/clients", name="client_index")
     */
    public function clientIndex()
    {
        return new Response('New Controller method index');
    }

    /**
     * @Route("/clients/{id}", name="client_details")
     */
    public function clientDetails($id)
    {
        return new Response('Id: ' . $id);
    }
}
