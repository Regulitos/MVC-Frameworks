<?php

/* base.html.twig */
class __TwigTemplate_cf276ec5c8aeca8007e33ee25c4885ab60c5782e044b68c641db76c6879257f8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_69e2416804a2d2715e73251c7040ff01b73604cc9f9aa113056e5bfa0c63d6ae = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_69e2416804a2d2715e73251c7040ff01b73604cc9f9aa113056e5bfa0c63d6ae->enter($__internal_69e2416804a2d2715e73251c7040ff01b73604cc9f9aa113056e5bfa0c63d6ae_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        $__internal_298dcbf1c63a4546c6922abf42ec84e10bfa990f358a21e26ae7034bcadfc91a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_298dcbf1c63a4546c6922abf42ec84e10bfa990f358a21e26ae7034bcadfc91a->enter($__internal_298dcbf1c63a4546c6922abf42ec84e10bfa990f358a21e26ae7034bcadfc91a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>";
        // line 5
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        ";
        // line 6
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 7
        echo "        <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />
    </head>
    <body>
        ";
        // line 10
        $this->displayBlock('body', $context, $blocks);
        // line 11
        echo "        ";
        $this->displayBlock('javascripts', $context, $blocks);
        // line 12
        echo "    </body>
</html>
";
        
        $__internal_69e2416804a2d2715e73251c7040ff01b73604cc9f9aa113056e5bfa0c63d6ae->leave($__internal_69e2416804a2d2715e73251c7040ff01b73604cc9f9aa113056e5bfa0c63d6ae_prof);

        
        $__internal_298dcbf1c63a4546c6922abf42ec84e10bfa990f358a21e26ae7034bcadfc91a->leave($__internal_298dcbf1c63a4546c6922abf42ec84e10bfa990f358a21e26ae7034bcadfc91a_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_0662febf852eedcbfc3de9da534e783445c122cbca684eb37a4a5dd37ffce548 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0662febf852eedcbfc3de9da534e783445c122cbca684eb37a4a5dd37ffce548->enter($__internal_0662febf852eedcbfc3de9da534e783445c122cbca684eb37a4a5dd37ffce548_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_e991257a6976aba44087d198c75570c0eba220fc501f06f130a3b2ee8ce0801f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e991257a6976aba44087d198c75570c0eba220fc501f06f130a3b2ee8ce0801f->enter($__internal_e991257a6976aba44087d198c75570c0eba220fc501f06f130a3b2ee8ce0801f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Welcome!";
        
        $__internal_e991257a6976aba44087d198c75570c0eba220fc501f06f130a3b2ee8ce0801f->leave($__internal_e991257a6976aba44087d198c75570c0eba220fc501f06f130a3b2ee8ce0801f_prof);

        
        $__internal_0662febf852eedcbfc3de9da534e783445c122cbca684eb37a4a5dd37ffce548->leave($__internal_0662febf852eedcbfc3de9da534e783445c122cbca684eb37a4a5dd37ffce548_prof);

    }

    // line 6
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_a9cd997e5148cf12cb65db6139213d650b3d3dc1000d526413ce2952af267fe7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a9cd997e5148cf12cb65db6139213d650b3d3dc1000d526413ce2952af267fe7->enter($__internal_a9cd997e5148cf12cb65db6139213d650b3d3dc1000d526413ce2952af267fe7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_1be91001a0c0cd34966b978b9b21a8181d942f8cb6ba2d4905bbd69283a02642 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1be91001a0c0cd34966b978b9b21a8181d942f8cb6ba2d4905bbd69283a02642->enter($__internal_1be91001a0c0cd34966b978b9b21a8181d942f8cb6ba2d4905bbd69283a02642_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_1be91001a0c0cd34966b978b9b21a8181d942f8cb6ba2d4905bbd69283a02642->leave($__internal_1be91001a0c0cd34966b978b9b21a8181d942f8cb6ba2d4905bbd69283a02642_prof);

        
        $__internal_a9cd997e5148cf12cb65db6139213d650b3d3dc1000d526413ce2952af267fe7->leave($__internal_a9cd997e5148cf12cb65db6139213d650b3d3dc1000d526413ce2952af267fe7_prof);

    }

    // line 10
    public function block_body($context, array $blocks = array())
    {
        $__internal_46850505c73748d83815d893049e5a0b76ac9effe969d8ca3bac039df4c59a0a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_46850505c73748d83815d893049e5a0b76ac9effe969d8ca3bac039df4c59a0a->enter($__internal_46850505c73748d83815d893049e5a0b76ac9effe969d8ca3bac039df4c59a0a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_6de3839c1dbddf6a29848b2518d08d3e9e117bc7a724e33a35829697432f48c8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6de3839c1dbddf6a29848b2518d08d3e9e117bc7a724e33a35829697432f48c8->enter($__internal_6de3839c1dbddf6a29848b2518d08d3e9e117bc7a724e33a35829697432f48c8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_6de3839c1dbddf6a29848b2518d08d3e9e117bc7a724e33a35829697432f48c8->leave($__internal_6de3839c1dbddf6a29848b2518d08d3e9e117bc7a724e33a35829697432f48c8_prof);

        
        $__internal_46850505c73748d83815d893049e5a0b76ac9effe969d8ca3bac039df4c59a0a->leave($__internal_46850505c73748d83815d893049e5a0b76ac9effe969d8ca3bac039df4c59a0a_prof);

    }

    // line 11
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_3e07189c50a504146bd742a7f31dd4ff2442ffc69d5755389794a9654f06c79d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3e07189c50a504146bd742a7f31dd4ff2442ffc69d5755389794a9654f06c79d->enter($__internal_3e07189c50a504146bd742a7f31dd4ff2442ffc69d5755389794a9654f06c79d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_3c949f91e083e4660069154cfacb8ccdba88788b5d55082f1b12402036228d3d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3c949f91e083e4660069154cfacb8ccdba88788b5d55082f1b12402036228d3d->enter($__internal_3c949f91e083e4660069154cfacb8ccdba88788b5d55082f1b12402036228d3d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_3c949f91e083e4660069154cfacb8ccdba88788b5d55082f1b12402036228d3d->leave($__internal_3c949f91e083e4660069154cfacb8ccdba88788b5d55082f1b12402036228d3d_prof);

        
        $__internal_3e07189c50a504146bd742a7f31dd4ff2442ffc69d5755389794a9654f06c79d->leave($__internal_3e07189c50a504146bd742a7f31dd4ff2442ffc69d5755389794a9654f06c79d_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  117 => 11,  100 => 10,  83 => 6,  65 => 5,  53 => 12,  50 => 11,  48 => 10,  41 => 7,  39 => 6,  35 => 5,  29 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>{% block title %}Welcome!{% endblock %}</title>
        {% block stylesheets %}{% endblock %}
        <link rel=\"icon\" type=\"image/x-icon\" href=\"{{ asset('favicon.ico') }}\" />
    </head>
    <body>
        {% block body %}{% endblock %}
        {% block javascripts %}{% endblock %}
    </body>
</html>
", "base.html.twig", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\controllers\\symfony\\app\\Resources\\views\\base.html.twig");
    }
}
