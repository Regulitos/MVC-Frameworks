<?php

/* @Framework/Form/reset_widget.html.php */
class __TwigTemplate_58940593f855337d9d75604ee90768a3352995d21a47aa79598ce8f367b6c809 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b21dc9bd94f988d7935ec90583e433493641f4f3f8839bd25d3d1233906e818f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b21dc9bd94f988d7935ec90583e433493641f4f3f8839bd25d3d1233906e818f->enter($__internal_b21dc9bd94f988d7935ec90583e433493641f4f3f8839bd25d3d1233906e818f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/reset_widget.html.php"));

        $__internal_7f17a9332b8bce90a340d28fe78e194162b5a93d9a5ff24ac845e0483c34052d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7f17a9332b8bce90a340d28fe78e194162b5a93d9a5ff24ac845e0483c34052d->enter($__internal_7f17a9332b8bce90a340d28fe78e194162b5a93d9a5ff24ac845e0483c34052d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/reset_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'button_widget', array('type' => isset(\$type) ? \$type : 'reset')) ?>
";
        
        $__internal_b21dc9bd94f988d7935ec90583e433493641f4f3f8839bd25d3d1233906e818f->leave($__internal_b21dc9bd94f988d7935ec90583e433493641f4f3f8839bd25d3d1233906e818f_prof);

        
        $__internal_7f17a9332b8bce90a340d28fe78e194162b5a93d9a5ff24ac845e0483c34052d->leave($__internal_7f17a9332b8bce90a340d28fe78e194162b5a93d9a5ff24ac845e0483c34052d_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/reset_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'button_widget', array('type' => isset(\$type) ? \$type : 'reset')) ?>
", "@Framework/Form/reset_widget.html.php", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\controllers\\symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\reset_widget.html.php");
    }
}
