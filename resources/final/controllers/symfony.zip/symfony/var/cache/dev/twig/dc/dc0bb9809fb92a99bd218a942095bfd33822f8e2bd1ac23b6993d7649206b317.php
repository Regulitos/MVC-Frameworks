<?php

/* ::base.html.twig */
class __TwigTemplate_aaa161c310dcecf2b0607299d5353c510065f9384a93e27c9013c98e455d9322 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2bf665813119b84a61e0abe584455c15c94ee38b354704c3fc9368fac918ba9d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2bf665813119b84a61e0abe584455c15c94ee38b354704c3fc9368fac918ba9d->enter($__internal_2bf665813119b84a61e0abe584455c15c94ee38b354704c3fc9368fac918ba9d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::base.html.twig"));

        $__internal_7e78b0b73f3a9233dc25071737d6c40da6a4ef876f5d7d4dcbcb5da93193dd74 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7e78b0b73f3a9233dc25071737d6c40da6a4ef876f5d7d4dcbcb5da93193dd74->enter($__internal_7e78b0b73f3a9233dc25071737d6c40da6a4ef876f5d7d4dcbcb5da93193dd74_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>";
        // line 5
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        ";
        // line 6
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 7
        echo "        <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />
    </head>
    <body>
        ";
        // line 10
        $this->displayBlock('body', $context, $blocks);
        // line 11
        echo "        ";
        $this->displayBlock('javascripts', $context, $blocks);
        // line 12
        echo "    </body>
</html>
";
        
        $__internal_2bf665813119b84a61e0abe584455c15c94ee38b354704c3fc9368fac918ba9d->leave($__internal_2bf665813119b84a61e0abe584455c15c94ee38b354704c3fc9368fac918ba9d_prof);

        
        $__internal_7e78b0b73f3a9233dc25071737d6c40da6a4ef876f5d7d4dcbcb5da93193dd74->leave($__internal_7e78b0b73f3a9233dc25071737d6c40da6a4ef876f5d7d4dcbcb5da93193dd74_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_f59e8a9e9d0c705548002b1c1f5a09660af2439ebbce3f002b7e685a58c1222c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f59e8a9e9d0c705548002b1c1f5a09660af2439ebbce3f002b7e685a58c1222c->enter($__internal_f59e8a9e9d0c705548002b1c1f5a09660af2439ebbce3f002b7e685a58c1222c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_5a78ee54c438a8eaec1bde8d45e39c07af3de56b508a30f6ef334299091104e3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5a78ee54c438a8eaec1bde8d45e39c07af3de56b508a30f6ef334299091104e3->enter($__internal_5a78ee54c438a8eaec1bde8d45e39c07af3de56b508a30f6ef334299091104e3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Welcome!";
        
        $__internal_5a78ee54c438a8eaec1bde8d45e39c07af3de56b508a30f6ef334299091104e3->leave($__internal_5a78ee54c438a8eaec1bde8d45e39c07af3de56b508a30f6ef334299091104e3_prof);

        
        $__internal_f59e8a9e9d0c705548002b1c1f5a09660af2439ebbce3f002b7e685a58c1222c->leave($__internal_f59e8a9e9d0c705548002b1c1f5a09660af2439ebbce3f002b7e685a58c1222c_prof);

    }

    // line 6
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_6499008dc103bdf22df4d2e96229229961a980f11034b768108b5e2b29ea6862 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6499008dc103bdf22df4d2e96229229961a980f11034b768108b5e2b29ea6862->enter($__internal_6499008dc103bdf22df4d2e96229229961a980f11034b768108b5e2b29ea6862_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_19a597a5f3c120e9e8f8beff38a4865d0ee07b2729770b637b49afa058700909 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_19a597a5f3c120e9e8f8beff38a4865d0ee07b2729770b637b49afa058700909->enter($__internal_19a597a5f3c120e9e8f8beff38a4865d0ee07b2729770b637b49afa058700909_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_19a597a5f3c120e9e8f8beff38a4865d0ee07b2729770b637b49afa058700909->leave($__internal_19a597a5f3c120e9e8f8beff38a4865d0ee07b2729770b637b49afa058700909_prof);

        
        $__internal_6499008dc103bdf22df4d2e96229229961a980f11034b768108b5e2b29ea6862->leave($__internal_6499008dc103bdf22df4d2e96229229961a980f11034b768108b5e2b29ea6862_prof);

    }

    // line 10
    public function block_body($context, array $blocks = array())
    {
        $__internal_9a77e13d2da7a065111a0c448a587469ff9a2587553ef0ce9122e5fa8387891b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9a77e13d2da7a065111a0c448a587469ff9a2587553ef0ce9122e5fa8387891b->enter($__internal_9a77e13d2da7a065111a0c448a587469ff9a2587553ef0ce9122e5fa8387891b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_f5651fae0069e28b3148fd606fd03a7e3cfdf56442f806818211cfd4023753cb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f5651fae0069e28b3148fd606fd03a7e3cfdf56442f806818211cfd4023753cb->enter($__internal_f5651fae0069e28b3148fd606fd03a7e3cfdf56442f806818211cfd4023753cb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_f5651fae0069e28b3148fd606fd03a7e3cfdf56442f806818211cfd4023753cb->leave($__internal_f5651fae0069e28b3148fd606fd03a7e3cfdf56442f806818211cfd4023753cb_prof);

        
        $__internal_9a77e13d2da7a065111a0c448a587469ff9a2587553ef0ce9122e5fa8387891b->leave($__internal_9a77e13d2da7a065111a0c448a587469ff9a2587553ef0ce9122e5fa8387891b_prof);

    }

    // line 11
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_8f35521890df50d8e03090af2c98683a1726f1dc0b90a9effc9e406efe4fdaa6 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8f35521890df50d8e03090af2c98683a1726f1dc0b90a9effc9e406efe4fdaa6->enter($__internal_8f35521890df50d8e03090af2c98683a1726f1dc0b90a9effc9e406efe4fdaa6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_489f3a00415039ec498279f7032361c7ba4d933d5b77218129be28e1441a4660 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_489f3a00415039ec498279f7032361c7ba4d933d5b77218129be28e1441a4660->enter($__internal_489f3a00415039ec498279f7032361c7ba4d933d5b77218129be28e1441a4660_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_489f3a00415039ec498279f7032361c7ba4d933d5b77218129be28e1441a4660->leave($__internal_489f3a00415039ec498279f7032361c7ba4d933d5b77218129be28e1441a4660_prof);

        
        $__internal_8f35521890df50d8e03090af2c98683a1726f1dc0b90a9effc9e406efe4fdaa6->leave($__internal_8f35521890df50d8e03090af2c98683a1726f1dc0b90a9effc9e406efe4fdaa6_prof);

    }

    public function getTemplateName()
    {
        return "::base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  117 => 11,  100 => 10,  83 => 6,  65 => 5,  53 => 12,  50 => 11,  48 => 10,  41 => 7,  39 => 6,  35 => 5,  29 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>{% block title %}Welcome!{% endblock %}</title>
        {% block stylesheets %}{% endblock %}
        <link rel=\"icon\" type=\"image/x-icon\" href=\"{{ asset('favicon.ico') }}\" />
    </head>
    <body>
        {% block body %}{% endblock %}
        {% block javascripts %}{% endblock %}
    </body>
</html>
", "::base.html.twig", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\controllers\\symfony\\app/Resources\\views/base.html.twig");
    }
}
