<?php

/* TwigBundle:Exception:error.js.twig */
class __TwigTemplate_c03c92ad869670f18bf9afe943f604332e795d48247f03ab695a303201fc70e3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_83108f5cb256ebce2c9c3f468f6727cb3d0eec853645bf7159ee34622367c14a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_83108f5cb256ebce2c9c3f468f6727cb3d0eec853645bf7159ee34622367c14a->enter($__internal_83108f5cb256ebce2c9c3f468f6727cb3d0eec853645bf7159ee34622367c14a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.js.twig"));

        $__internal_3aa915b5498faed356b791cecfa256b411e7b29f60488ad7379b10864e51c0ac = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3aa915b5498faed356b791cecfa256b411e7b29f60488ad7379b10864e51c0ac->enter($__internal_3aa915b5498faed356b791cecfa256b411e7b29f60488ad7379b10864e51c0ac_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.js.twig"));

        // line 1
        echo "/*
";
        // line 2
        echo twig_escape_filter($this->env, ($context["status_code"] ?? $this->getContext($context, "status_code")), "js", null, true);
        echo " ";
        echo twig_escape_filter($this->env, ($context["status_text"] ?? $this->getContext($context, "status_text")), "js", null, true);
        echo "

*/
";
        
        $__internal_83108f5cb256ebce2c9c3f468f6727cb3d0eec853645bf7159ee34622367c14a->leave($__internal_83108f5cb256ebce2c9c3f468f6727cb3d0eec853645bf7159ee34622367c14a_prof);

        
        $__internal_3aa915b5498faed356b791cecfa256b411e7b29f60488ad7379b10864e51c0ac->leave($__internal_3aa915b5498faed356b791cecfa256b411e7b29f60488ad7379b10864e51c0ac_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.js.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  28 => 2,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("/*
{{ status_code }} {{ status_text }}

*/
", "TwigBundle:Exception:error.js.twig", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\controllers\\symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle/Resources/views/Exception/error.js.twig");
    }
}
