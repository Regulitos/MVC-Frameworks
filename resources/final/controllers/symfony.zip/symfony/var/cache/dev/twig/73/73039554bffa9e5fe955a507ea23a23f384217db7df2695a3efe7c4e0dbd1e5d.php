<?php

/* @Framework/Form/button_label.html.php */
class __TwigTemplate_0710a0509677fc0eb5b818cff1fe5c815f5c29a8028b78066672fae900340f03 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_bf178f7b558208e5ad09d977e6662e1dc696b317bc0fcf798ba18025155a9bd2 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_bf178f7b558208e5ad09d977e6662e1dc696b317bc0fcf798ba18025155a9bd2->enter($__internal_bf178f7b558208e5ad09d977e6662e1dc696b317bc0fcf798ba18025155a9bd2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_label.html.php"));

        $__internal_2054b39b195d7f6917e0e0aaaa5270ec82c732c7405235ba0e8d1e1bd4ceb62a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2054b39b195d7f6917e0e0aaaa5270ec82c732c7405235ba0e8d1e1bd4ceb62a->enter($__internal_2054b39b195d7f6917e0e0aaaa5270ec82c732c7405235ba0e8d1e1bd4ceb62a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_label.html.php"));

        
        $__internal_bf178f7b558208e5ad09d977e6662e1dc696b317bc0fcf798ba18025155a9bd2->leave($__internal_bf178f7b558208e5ad09d977e6662e1dc696b317bc0fcf798ba18025155a9bd2_prof);

        
        $__internal_2054b39b195d7f6917e0e0aaaa5270ec82c732c7405235ba0e8d1e1bd4ceb62a->leave($__internal_2054b39b195d7f6917e0e0aaaa5270ec82c732c7405235ba0e8d1e1bd4ceb62a_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_label.html.php";
    }

    public function getDebugInfo()
    {
        return array ();
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "@Framework/Form/button_label.html.php", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\controllers\\symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\button_label.html.php");
    }
}
