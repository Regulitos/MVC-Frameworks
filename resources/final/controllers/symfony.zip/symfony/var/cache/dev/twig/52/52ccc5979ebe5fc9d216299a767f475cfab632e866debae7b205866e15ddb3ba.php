<?php

/* @Framework/Form/radio_widget.html.php */
class __TwigTemplate_de4109765a9af087da3d5e729e2c8a0137a15deeb1f70611aa50efcd0b8649fa extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_fa14f4d908b2c04134b8dd757b836395e5ffeec4278947a3696774507f18282f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_fa14f4d908b2c04134b8dd757b836395e5ffeec4278947a3696774507f18282f->enter($__internal_fa14f4d908b2c04134b8dd757b836395e5ffeec4278947a3696774507f18282f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/radio_widget.html.php"));

        $__internal_b7e787d100d321c381b95c45a93e758aaa21c93ff7248e8ca84fd1079258e62e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b7e787d100d321c381b95c45a93e758aaa21c93ff7248e8ca84fd1079258e62e->enter($__internal_b7e787d100d321c381b95c45a93e758aaa21c93ff7248e8ca84fd1079258e62e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/radio_widget.html.php"));

        // line 1
        echo "<input type=\"radio\"
    <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
    value=\"<?php echo \$view->escape(\$value) ?>\"
    <?php if (\$checked): ?> checked=\"checked\"<?php endif ?>
/>
";
        
        $__internal_fa14f4d908b2c04134b8dd757b836395e5ffeec4278947a3696774507f18282f->leave($__internal_fa14f4d908b2c04134b8dd757b836395e5ffeec4278947a3696774507f18282f_prof);

        
        $__internal_b7e787d100d321c381b95c45a93e758aaa21c93ff7248e8ca84fd1079258e62e->leave($__internal_b7e787d100d321c381b95c45a93e758aaa21c93ff7248e8ca84fd1079258e62e_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/radio_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<input type=\"radio\"
    <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
    value=\"<?php echo \$view->escape(\$value) ?>\"
    <?php if (\$checked): ?> checked=\"checked\"<?php endif ?>
/>
", "@Framework/Form/radio_widget.html.php", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\controllers\\symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\radio_widget.html.php");
    }
}
