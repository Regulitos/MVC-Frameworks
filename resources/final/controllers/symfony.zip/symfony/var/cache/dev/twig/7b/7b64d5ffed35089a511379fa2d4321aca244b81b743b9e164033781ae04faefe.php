<?php

/* @WebProfiler/Profiler/open.html.twig */
class __TwigTemplate_02a887d4589b168b4292e6617e38c6962d99bad21ae0097b64a11bc6d3bf9a91 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/base.html.twig", "@WebProfiler/Profiler/open.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4ee0689787b2e76647da769cc2285b0c4100374efd48683791e749275b24dab3 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4ee0689787b2e76647da769cc2285b0c4100374efd48683791e749275b24dab3->enter($__internal_4ee0689787b2e76647da769cc2285b0c4100374efd48683791e749275b24dab3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/open.html.twig"));

        $__internal_cae26ddab7facbadc6f4736a7467d91c965c8482b2c904c71edd49c98eff0b51 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_cae26ddab7facbadc6f4736a7467d91c965c8482b2c904c71edd49c98eff0b51->enter($__internal_cae26ddab7facbadc6f4736a7467d91c965c8482b2c904c71edd49c98eff0b51_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/open.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_4ee0689787b2e76647da769cc2285b0c4100374efd48683791e749275b24dab3->leave($__internal_4ee0689787b2e76647da769cc2285b0c4100374efd48683791e749275b24dab3_prof);

        
        $__internal_cae26ddab7facbadc6f4736a7467d91c965c8482b2c904c71edd49c98eff0b51->leave($__internal_cae26ddab7facbadc6f4736a7467d91c965c8482b2c904c71edd49c98eff0b51_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_57fbc00d941b3432cfeef0a2a61bce299f199f068dc07fabd3de7d86020f4fee = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_57fbc00d941b3432cfeef0a2a61bce299f199f068dc07fabd3de7d86020f4fee->enter($__internal_57fbc00d941b3432cfeef0a2a61bce299f199f068dc07fabd3de7d86020f4fee_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        $__internal_e7210125ed4ff0c54e2a63d20ba7f189383d0cf9392a6d33c2438a75cd116517 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e7210125ed4ff0c54e2a63d20ba7f189383d0cf9392a6d33c2438a75cd116517->enter($__internal_e7210125ed4ff0c54e2a63d20ba7f189383d0cf9392a6d33c2438a75cd116517_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    <style>
        ";
        // line 5
        echo twig_include($this->env, $context, "@WebProfiler/Profiler/open.css.twig");
        echo "
    </style>
";
        
        $__internal_e7210125ed4ff0c54e2a63d20ba7f189383d0cf9392a6d33c2438a75cd116517->leave($__internal_e7210125ed4ff0c54e2a63d20ba7f189383d0cf9392a6d33c2438a75cd116517_prof);

        
        $__internal_57fbc00d941b3432cfeef0a2a61bce299f199f068dc07fabd3de7d86020f4fee->leave($__internal_57fbc00d941b3432cfeef0a2a61bce299f199f068dc07fabd3de7d86020f4fee_prof);

    }

    // line 9
    public function block_body($context, array $blocks = array())
    {
        $__internal_b4624228f82512b8f90d14af6d8d8b631f1a4a4cb5a8134e4208bee810333204 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b4624228f82512b8f90d14af6d8d8b631f1a4a4cb5a8134e4208bee810333204->enter($__internal_b4624228f82512b8f90d14af6d8d8b631f1a4a4cb5a8134e4208bee810333204_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_0522420e4dc49bcc3531d9aac08468e24171a932bf3b0b3dd7680fee3e00f0de = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0522420e4dc49bcc3531d9aac08468e24171a932bf3b0b3dd7680fee3e00f0de->enter($__internal_0522420e4dc49bcc3531d9aac08468e24171a932bf3b0b3dd7680fee3e00f0de_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 10
        echo "<div class=\"header\">
    <h1>";
        // line 11
        echo twig_escape_filter($this->env, ($context["file"] ?? $this->getContext($context, "file")), "html", null, true);
        echo " <small>line ";
        echo twig_escape_filter($this->env, ($context["line"] ?? $this->getContext($context, "line")), "html", null, true);
        echo "</small></h1>
    <a class=\"doc\" href=\"https://symfony.com/doc/";
        // line 12
        echo twig_escape_filter($this->env, twig_constant("Symfony\\Component\\HttpKernel\\Kernel::VERSION"), "html", null, true);
        echo "/reference/configuration/framework.html#ide\" rel=\"help\">Open in your IDE?</a>
</div>
<div class=\"source\">
    ";
        // line 15
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\CodeExtension')->fileExcerpt(($context["filename"] ?? $this->getContext($context, "filename")), ($context["line"] ?? $this->getContext($context, "line")),  -1);
        echo "
</div>
";
        
        $__internal_0522420e4dc49bcc3531d9aac08468e24171a932bf3b0b3dd7680fee3e00f0de->leave($__internal_0522420e4dc49bcc3531d9aac08468e24171a932bf3b0b3dd7680fee3e00f0de_prof);

        
        $__internal_b4624228f82512b8f90d14af6d8d8b631f1a4a4cb5a8134e4208bee810333204->leave($__internal_b4624228f82512b8f90d14af6d8d8b631f1a4a4cb5a8134e4208bee810333204_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Profiler/open.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  90 => 15,  84 => 12,  78 => 11,  75 => 10,  66 => 9,  53 => 5,  50 => 4,  41 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/base.html.twig' %}

{% block head %}
    <style>
        {{ include('@WebProfiler/Profiler/open.css.twig') }}
    </style>
{% endblock %}

{% block body %}
<div class=\"header\">
    <h1>{{ file }} <small>line {{ line }}</small></h1>
    <a class=\"doc\" href=\"https://symfony.com/doc/{{ constant('Symfony\\\\Component\\\\HttpKernel\\\\Kernel::VERSION') }}/reference/configuration/framework.html#ide\" rel=\"help\">Open in your IDE?</a>
</div>
<div class=\"source\">
    {{ filename|file_excerpt(line, -1) }}
</div>
{% endblock %}
", "@WebProfiler/Profiler/open.html.twig", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\controllers\\symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Profiler\\open.html.twig");
    }
}
