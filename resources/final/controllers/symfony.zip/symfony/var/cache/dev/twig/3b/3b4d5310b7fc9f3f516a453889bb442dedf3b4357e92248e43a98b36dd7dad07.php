<?php

/* WebProfilerBundle:Profiler:ajax_layout.html.twig */
class __TwigTemplate_ea5546ba30baf4b586e3d8de7ea5609933e843ee1c480e8a1618a0e56cbaf936 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2ba86c2de6f39ecfccff01d0268e530fac31e6521815b9b6a28632c7b439bbef = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2ba86c2de6f39ecfccff01d0268e530fac31e6521815b9b6a28632c7b439bbef->enter($__internal_2ba86c2de6f39ecfccff01d0268e530fac31e6521815b9b6a28632c7b439bbef_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:ajax_layout.html.twig"));

        $__internal_9b49663298f3e9da53176247777d60149239920865e9713d59c2916e2379e113 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9b49663298f3e9da53176247777d60149239920865e9713d59c2916e2379e113->enter($__internal_9b49663298f3e9da53176247777d60149239920865e9713d59c2916e2379e113_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:ajax_layout.html.twig"));

        // line 1
        $this->displayBlock('panel', $context, $blocks);
        
        $__internal_2ba86c2de6f39ecfccff01d0268e530fac31e6521815b9b6a28632c7b439bbef->leave($__internal_2ba86c2de6f39ecfccff01d0268e530fac31e6521815b9b6a28632c7b439bbef_prof);

        
        $__internal_9b49663298f3e9da53176247777d60149239920865e9713d59c2916e2379e113->leave($__internal_9b49663298f3e9da53176247777d60149239920865e9713d59c2916e2379e113_prof);

    }

    public function block_panel($context, array $blocks = array())
    {
        $__internal_45bde8bb10378847d94a88e27e58bbd00801b0c0498bcce950ca4e1e339cc702 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_45bde8bb10378847d94a88e27e58bbd00801b0c0498bcce950ca4e1e339cc702->enter($__internal_45bde8bb10378847d94a88e27e58bbd00801b0c0498bcce950ca4e1e339cc702_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_14386889ea409c524332e1fe0e4a3bfd03642f2ad6434a7768581207787c2b9c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_14386889ea409c524332e1fe0e4a3bfd03642f2ad6434a7768581207787c2b9c->enter($__internal_14386889ea409c524332e1fe0e4a3bfd03642f2ad6434a7768581207787c2b9c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        echo "";
        
        $__internal_14386889ea409c524332e1fe0e4a3bfd03642f2ad6434a7768581207787c2b9c->leave($__internal_14386889ea409c524332e1fe0e4a3bfd03642f2ad6434a7768581207787c2b9c_prof);

        
        $__internal_45bde8bb10378847d94a88e27e58bbd00801b0c0498bcce950ca4e1e339cc702->leave($__internal_45bde8bb10378847d94a88e27e58bbd00801b0c0498bcce950ca4e1e339cc702_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:ajax_layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  26 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% block panel '' %}
", "WebProfilerBundle:Profiler:ajax_layout.html.twig", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\controllers\\symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle/Resources/views/Profiler/ajax_layout.html.twig");
    }
}
