<?php

/* @Twig/Exception/error.css.twig */
class __TwigTemplate_43e207f99fe2921cfe350cdef0e238b6199e42ae5461d651cd38238c2d0b4230 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_28ca0251748677bd9ed4ff640110892a89c89d28eae653ff5c2e48309d75b011 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_28ca0251748677bd9ed4ff640110892a89c89d28eae653ff5c2e48309d75b011->enter($__internal_28ca0251748677bd9ed4ff640110892a89c89d28eae653ff5c2e48309d75b011_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.css.twig"));

        $__internal_3c1ef94ba1bf6cad24ac329f1254c174ab4bbf79db9cca1dcfb98ef3b88df5b4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3c1ef94ba1bf6cad24ac329f1254c174ab4bbf79db9cca1dcfb98ef3b88df5b4->enter($__internal_3c1ef94ba1bf6cad24ac329f1254c174ab4bbf79db9cca1dcfb98ef3b88df5b4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.css.twig"));

        // line 1
        echo "/*
";
        // line 2
        echo twig_escape_filter($this->env, ($context["status_code"] ?? $this->getContext($context, "status_code")), "css", null, true);
        echo " ";
        echo twig_escape_filter($this->env, ($context["status_text"] ?? $this->getContext($context, "status_text")), "css", null, true);
        echo "

*/
";
        
        $__internal_28ca0251748677bd9ed4ff640110892a89c89d28eae653ff5c2e48309d75b011->leave($__internal_28ca0251748677bd9ed4ff640110892a89c89d28eae653ff5c2e48309d75b011_prof);

        
        $__internal_3c1ef94ba1bf6cad24ac329f1254c174ab4bbf79db9cca1dcfb98ef3b88df5b4->leave($__internal_3c1ef94ba1bf6cad24ac329f1254c174ab4bbf79db9cca1dcfb98ef3b88df5b4_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/error.css.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  28 => 2,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("/*
{{ status_code }} {{ status_text }}

*/
", "@Twig/Exception/error.css.twig", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\controllers\\symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\error.css.twig");
    }
}
