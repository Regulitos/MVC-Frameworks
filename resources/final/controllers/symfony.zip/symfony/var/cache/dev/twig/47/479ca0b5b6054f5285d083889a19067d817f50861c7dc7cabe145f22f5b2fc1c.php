<?php

/* @Framework/Form/submit_widget.html.php */
class __TwigTemplate_c731e6a0ca590251c73aa92c3534eb9fb1c2732dc8dfaee985c957d1403fbb83 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_99dbadae9e5504578fcc477781752e67616bce131aab22b926be94904bcf4535 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_99dbadae9e5504578fcc477781752e67616bce131aab22b926be94904bcf4535->enter($__internal_99dbadae9e5504578fcc477781752e67616bce131aab22b926be94904bcf4535_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/submit_widget.html.php"));

        $__internal_a52a431e89601acabe437ffc3a58097942137cc471da5dbeaa5f084fb6d9e082 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a52a431e89601acabe437ffc3a58097942137cc471da5dbeaa5f084fb6d9e082->enter($__internal_a52a431e89601acabe437ffc3a58097942137cc471da5dbeaa5f084fb6d9e082_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/submit_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'button_widget', array('type' => isset(\$type) ? \$type : 'submit')) ?>
";
        
        $__internal_99dbadae9e5504578fcc477781752e67616bce131aab22b926be94904bcf4535->leave($__internal_99dbadae9e5504578fcc477781752e67616bce131aab22b926be94904bcf4535_prof);

        
        $__internal_a52a431e89601acabe437ffc3a58097942137cc471da5dbeaa5f084fb6d9e082->leave($__internal_a52a431e89601acabe437ffc3a58097942137cc471da5dbeaa5f084fb6d9e082_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/submit_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'button_widget', array('type' => isset(\$type) ? \$type : 'submit')) ?>
", "@Framework/Form/submit_widget.html.php", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\controllers\\symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\submit_widget.html.php");
    }
}
