<?php

/* @Framework/Form/form_widget_simple.html.php */
class __TwigTemplate_1a47a875b481b077d24b2f8041c95c21f77eb5288a91f7d91fc70f7c07ee4ab0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2868e07267ae56db022ccc6a9084ecd8fca9ff00c0337c77f0e98c19069c6386 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2868e07267ae56db022ccc6a9084ecd8fca9ff00c0337c77f0e98c19069c6386->enter($__internal_2868e07267ae56db022ccc6a9084ecd8fca9ff00c0337c77f0e98c19069c6386_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget_simple.html.php"));

        $__internal_77e5994386a0afbfd0e5fda6905df78defadf6373190a2eef5d2d1fc45a27402 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_77e5994386a0afbfd0e5fda6905df78defadf6373190a2eef5d2d1fc45a27402->enter($__internal_77e5994386a0afbfd0e5fda6905df78defadf6373190a2eef5d2d1fc45a27402_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget_simple.html.php"));

        // line 1
        echo "<input type=\"<?php echo isset(\$type) ? \$view->escape(\$type) : 'text' ?>\" <?php echo \$view['form']->block(\$form, 'widget_attributes') ?><?php if (!empty(\$value) || is_numeric(\$value)): ?> value=\"<?php echo \$view->escape(\$value) ?>\"<?php endif ?> />
";
        
        $__internal_2868e07267ae56db022ccc6a9084ecd8fca9ff00c0337c77f0e98c19069c6386->leave($__internal_2868e07267ae56db022ccc6a9084ecd8fca9ff00c0337c77f0e98c19069c6386_prof);

        
        $__internal_77e5994386a0afbfd0e5fda6905df78defadf6373190a2eef5d2d1fc45a27402->leave($__internal_77e5994386a0afbfd0e5fda6905df78defadf6373190a2eef5d2d1fc45a27402_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_widget_simple.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<input type=\"<?php echo isset(\$type) ? \$view->escape(\$type) : 'text' ?>\" <?php echo \$view['form']->block(\$form, 'widget_attributes') ?><?php if (!empty(\$value) || is_numeric(\$value)): ?> value=\"<?php echo \$view->escape(\$value) ?>\"<?php endif ?> />
", "@Framework/Form/form_widget_simple.html.php", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\controllers\\symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\form_widget_simple.html.php");
    }
}
