<?php

/* @Framework/Form/choice_options.html.php */
class __TwigTemplate_32699e087196b13f160cc7596ce48296a3737bb211057b369df885a37d7145a1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c96c7e0d789bece557e2951bab1f64e5610cd2b9e23746e8c22414f7f33e484c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c96c7e0d789bece557e2951bab1f64e5610cd2b9e23746e8c22414f7f33e484c->enter($__internal_c96c7e0d789bece557e2951bab1f64e5610cd2b9e23746e8c22414f7f33e484c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_options.html.php"));

        $__internal_ac4f29e59d0fce8bd2f338c3fee35bd1a7e83723a32349919852f19fe74fff11 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ac4f29e59d0fce8bd2f338c3fee35bd1a7e83723a32349919852f19fe74fff11->enter($__internal_ac4f29e59d0fce8bd2f338c3fee35bd1a7e83723a32349919852f19fe74fff11_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_options.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'choice_widget_options') ?>
";
        
        $__internal_c96c7e0d789bece557e2951bab1f64e5610cd2b9e23746e8c22414f7f33e484c->leave($__internal_c96c7e0d789bece557e2951bab1f64e5610cd2b9e23746e8c22414f7f33e484c_prof);

        
        $__internal_ac4f29e59d0fce8bd2f338c3fee35bd1a7e83723a32349919852f19fe74fff11->leave($__internal_ac4f29e59d0fce8bd2f338c3fee35bd1a7e83723a32349919852f19fe74fff11_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/choice_options.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'choice_widget_options') ?>
", "@Framework/Form/choice_options.html.php", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\controllers\\symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\choice_options.html.php");
    }
}
