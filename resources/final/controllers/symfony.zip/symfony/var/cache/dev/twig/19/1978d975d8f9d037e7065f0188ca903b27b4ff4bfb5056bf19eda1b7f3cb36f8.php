<?php

/* WebProfilerBundle:Profiler:open.html.twig */
class __TwigTemplate_43a02ceeb6778dc7ff7e163a71b1e8225e8c8cc9de4b59e80973d9804aa2b22a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/base.html.twig", "WebProfilerBundle:Profiler:open.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_db4801e8c655fcc791509255863f6fdd5d21961c5e63a2ac45d5b4fc32c42418 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_db4801e8c655fcc791509255863f6fdd5d21961c5e63a2ac45d5b4fc32c42418->enter($__internal_db4801e8c655fcc791509255863f6fdd5d21961c5e63a2ac45d5b4fc32c42418_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:open.html.twig"));

        $__internal_5be5d2ca0abfff52f8878aaf24e7eea05ffacf97acc53fe8052263bad881b2b9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5be5d2ca0abfff52f8878aaf24e7eea05ffacf97acc53fe8052263bad881b2b9->enter($__internal_5be5d2ca0abfff52f8878aaf24e7eea05ffacf97acc53fe8052263bad881b2b9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:open.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_db4801e8c655fcc791509255863f6fdd5d21961c5e63a2ac45d5b4fc32c42418->leave($__internal_db4801e8c655fcc791509255863f6fdd5d21961c5e63a2ac45d5b4fc32c42418_prof);

        
        $__internal_5be5d2ca0abfff52f8878aaf24e7eea05ffacf97acc53fe8052263bad881b2b9->leave($__internal_5be5d2ca0abfff52f8878aaf24e7eea05ffacf97acc53fe8052263bad881b2b9_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_a25cf964892e724a87dcd2dad2ea31c1edb1853f702b7ba3bc0d217e1a7f49d5 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a25cf964892e724a87dcd2dad2ea31c1edb1853f702b7ba3bc0d217e1a7f49d5->enter($__internal_a25cf964892e724a87dcd2dad2ea31c1edb1853f702b7ba3bc0d217e1a7f49d5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        $__internal_b7710a32864a697c2722280dc3fd6e5e1ecc2919c532762ce6950b646acab506 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b7710a32864a697c2722280dc3fd6e5e1ecc2919c532762ce6950b646acab506->enter($__internal_b7710a32864a697c2722280dc3fd6e5e1ecc2919c532762ce6950b646acab506_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    <style>
        ";
        // line 5
        echo twig_include($this->env, $context, "@WebProfiler/Profiler/open.css.twig");
        echo "
    </style>
";
        
        $__internal_b7710a32864a697c2722280dc3fd6e5e1ecc2919c532762ce6950b646acab506->leave($__internal_b7710a32864a697c2722280dc3fd6e5e1ecc2919c532762ce6950b646acab506_prof);

        
        $__internal_a25cf964892e724a87dcd2dad2ea31c1edb1853f702b7ba3bc0d217e1a7f49d5->leave($__internal_a25cf964892e724a87dcd2dad2ea31c1edb1853f702b7ba3bc0d217e1a7f49d5_prof);

    }

    // line 9
    public function block_body($context, array $blocks = array())
    {
        $__internal_86a90880396d330571a7fccda9051944a08fec245d7c264922208d2540fd54ac = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_86a90880396d330571a7fccda9051944a08fec245d7c264922208d2540fd54ac->enter($__internal_86a90880396d330571a7fccda9051944a08fec245d7c264922208d2540fd54ac_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_6840a6971aa425ff9b119fe074f976a21d6d45a3ad8d24c6d3572514cb9e061c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6840a6971aa425ff9b119fe074f976a21d6d45a3ad8d24c6d3572514cb9e061c->enter($__internal_6840a6971aa425ff9b119fe074f976a21d6d45a3ad8d24c6d3572514cb9e061c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 10
        echo "<div class=\"header\">
    <h1>";
        // line 11
        echo twig_escape_filter($this->env, ($context["file"] ?? $this->getContext($context, "file")), "html", null, true);
        echo " <small>line ";
        echo twig_escape_filter($this->env, ($context["line"] ?? $this->getContext($context, "line")), "html", null, true);
        echo "</small></h1>
    <a class=\"doc\" href=\"https://symfony.com/doc/";
        // line 12
        echo twig_escape_filter($this->env, twig_constant("Symfony\\Component\\HttpKernel\\Kernel::VERSION"), "html", null, true);
        echo "/reference/configuration/framework.html#ide\" rel=\"help\">Open in your IDE?</a>
</div>
<div class=\"source\">
    ";
        // line 15
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\CodeExtension')->fileExcerpt(($context["filename"] ?? $this->getContext($context, "filename")), ($context["line"] ?? $this->getContext($context, "line")),  -1);
        echo "
</div>
";
        
        $__internal_6840a6971aa425ff9b119fe074f976a21d6d45a3ad8d24c6d3572514cb9e061c->leave($__internal_6840a6971aa425ff9b119fe074f976a21d6d45a3ad8d24c6d3572514cb9e061c_prof);

        
        $__internal_86a90880396d330571a7fccda9051944a08fec245d7c264922208d2540fd54ac->leave($__internal_86a90880396d330571a7fccda9051944a08fec245d7c264922208d2540fd54ac_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:open.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  90 => 15,  84 => 12,  78 => 11,  75 => 10,  66 => 9,  53 => 5,  50 => 4,  41 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/base.html.twig' %}

{% block head %}
    <style>
        {{ include('@WebProfiler/Profiler/open.css.twig') }}
    </style>
{% endblock %}

{% block body %}
<div class=\"header\">
    <h1>{{ file }} <small>line {{ line }}</small></h1>
    <a class=\"doc\" href=\"https://symfony.com/doc/{{ constant('Symfony\\\\Component\\\\HttpKernel\\\\Kernel::VERSION') }}/reference/configuration/framework.html#ide\" rel=\"help\">Open in your IDE?</a>
</div>
<div class=\"source\">
    {{ filename|file_excerpt(line, -1) }}
</div>
{% endblock %}
", "WebProfilerBundle:Profiler:open.html.twig", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\controllers\\symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle/Resources/views/Profiler/open.html.twig");
    }
}
