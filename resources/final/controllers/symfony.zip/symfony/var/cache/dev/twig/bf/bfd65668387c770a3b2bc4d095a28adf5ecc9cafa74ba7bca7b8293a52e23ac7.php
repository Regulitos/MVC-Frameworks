<?php

/* @Framework/Form/form_enctype.html.php */
class __TwigTemplate_c54de38a96336fc8c264fa5246cffcb1f77d7fbae541c8075c040282d209c2fd extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_246a1f008e73c092332f2587cc27060d8356d2ba88927363e865c61e3065d090 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_246a1f008e73c092332f2587cc27060d8356d2ba88927363e865c61e3065d090->enter($__internal_246a1f008e73c092332f2587cc27060d8356d2ba88927363e865c61e3065d090_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_enctype.html.php"));

        $__internal_54822d0a01dc5714c34b71fbf8bdcf4a8886d98e4275e9721cc478b42b0a7893 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_54822d0a01dc5714c34b71fbf8bdcf4a8886d98e4275e9721cc478b42b0a7893->enter($__internal_54822d0a01dc5714c34b71fbf8bdcf4a8886d98e4275e9721cc478b42b0a7893_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_enctype.html.php"));

        // line 1
        echo "<?php if (\$form->vars['multipart']): ?>enctype=\"multipart/form-data\"<?php endif ?>
";
        
        $__internal_246a1f008e73c092332f2587cc27060d8356d2ba88927363e865c61e3065d090->leave($__internal_246a1f008e73c092332f2587cc27060d8356d2ba88927363e865c61e3065d090_prof);

        
        $__internal_54822d0a01dc5714c34b71fbf8bdcf4a8886d98e4275e9721cc478b42b0a7893->leave($__internal_54822d0a01dc5714c34b71fbf8bdcf4a8886d98e4275e9721cc478b42b0a7893_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_enctype.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (\$form->vars['multipart']): ?>enctype=\"multipart/form-data\"<?php endif ?>
", "@Framework/Form/form_enctype.html.php", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\controllers\\symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\form_enctype.html.php");
    }
}
