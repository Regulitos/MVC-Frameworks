<?php

/* TwigBundle:Exception:exception.js.twig */
class __TwigTemplate_b8abb0eb73b136d8efa53cdaca99e6dcdacfbf93297656837016661dd03ef842 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8e6200016b8b1c023449319663f451a3bed7f417e88bdd7dcc2044bd2d5a927a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8e6200016b8b1c023449319663f451a3bed7f417e88bdd7dcc2044bd2d5a927a->enter($__internal_8e6200016b8b1c023449319663f451a3bed7f417e88bdd7dcc2044bd2d5a927a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.js.twig"));

        $__internal_ada38a2d66591649944d122105af4016ff4d391bbdeb4ff0606f0a5d7974152d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ada38a2d66591649944d122105af4016ff4d391bbdeb4ff0606f0a5d7974152d->enter($__internal_ada38a2d66591649944d122105af4016ff4d391bbdeb4ff0606f0a5d7974152d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.js.twig"));

        // line 1
        echo "/*
";
        // line 2
        echo twig_include($this->env, $context, "@Twig/Exception/exception.txt.twig", array("exception" => ($context["exception"] ?? $this->getContext($context, "exception"))));
        echo "
*/
";
        
        $__internal_8e6200016b8b1c023449319663f451a3bed7f417e88bdd7dcc2044bd2d5a927a->leave($__internal_8e6200016b8b1c023449319663f451a3bed7f417e88bdd7dcc2044bd2d5a927a_prof);

        
        $__internal_ada38a2d66591649944d122105af4016ff4d391bbdeb4ff0606f0a5d7974152d->leave($__internal_ada38a2d66591649944d122105af4016ff4d391bbdeb4ff0606f0a5d7974152d_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.js.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  28 => 2,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("/*
{{ include('@Twig/Exception/exception.txt.twig', { exception: exception }) }}
*/
", "TwigBundle:Exception:exception.js.twig", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\controllers\\symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle/Resources/views/Exception/exception.js.twig");
    }
}
