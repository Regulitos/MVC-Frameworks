<?php

/* @Framework/Form/form_row.html.php */
class __TwigTemplate_71f85e5b30b4aa0015add95fdf2e935f230ba8438e56b4bfc4a827ede9341e12 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8b92247a39049f21f51642eeb9471537a36667746a729ce06f71dda37d16cb5a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8b92247a39049f21f51642eeb9471537a36667746a729ce06f71dda37d16cb5a->enter($__internal_8b92247a39049f21f51642eeb9471537a36667746a729ce06f71dda37d16cb5a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_row.html.php"));

        $__internal_3fc2c7a0f5604b4efd269707017247d16c4590db59e85afaadd63daa7944e2cb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3fc2c7a0f5604b4efd269707017247d16c4590db59e85afaadd63daa7944e2cb->enter($__internal_3fc2c7a0f5604b4efd269707017247d16c4590db59e85afaadd63daa7944e2cb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_row.html.php"));

        // line 1
        echo "<div>
    <?php echo \$view['form']->label(\$form) ?>
    <?php echo \$view['form']->errors(\$form) ?>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
";
        
        $__internal_8b92247a39049f21f51642eeb9471537a36667746a729ce06f71dda37d16cb5a->leave($__internal_8b92247a39049f21f51642eeb9471537a36667746a729ce06f71dda37d16cb5a_prof);

        
        $__internal_3fc2c7a0f5604b4efd269707017247d16c4590db59e85afaadd63daa7944e2cb->leave($__internal_3fc2c7a0f5604b4efd269707017247d16c4590db59e85afaadd63daa7944e2cb_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div>
    <?php echo \$view['form']->label(\$form) ?>
    <?php echo \$view['form']->errors(\$form) ?>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
", "@Framework/Form/form_row.html.php", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\controllers\\symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\form_row.html.php");
    }
}
