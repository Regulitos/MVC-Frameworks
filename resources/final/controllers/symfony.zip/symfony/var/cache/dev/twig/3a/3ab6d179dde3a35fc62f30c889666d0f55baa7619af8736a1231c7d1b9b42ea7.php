<?php

/* @Framework/Form/repeated_row.html.php */
class __TwigTemplate_3d206093c01bde614dd5f7f2051942fddf01f2a533f1e9edcb39b5be2ec6f34e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3d0c0e2b32386dc4c6f648ad6839f175239b643889f029b82aaa24f6e8e7e0c9 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3d0c0e2b32386dc4c6f648ad6839f175239b643889f029b82aaa24f6e8e7e0c9->enter($__internal_3d0c0e2b32386dc4c6f648ad6839f175239b643889f029b82aaa24f6e8e7e0c9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/repeated_row.html.php"));

        $__internal_bac5017671c13d934706ef4fbe3e80f5a2589cdfabe3a2aadb7cb7ca6a9e56f9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_bac5017671c13d934706ef4fbe3e80f5a2589cdfabe3a2aadb7cb7ca6a9e56f9->enter($__internal_bac5017671c13d934706ef4fbe3e80f5a2589cdfabe3a2aadb7cb7ca6a9e56f9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/repeated_row.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_rows') ?>
";
        
        $__internal_3d0c0e2b32386dc4c6f648ad6839f175239b643889f029b82aaa24f6e8e7e0c9->leave($__internal_3d0c0e2b32386dc4c6f648ad6839f175239b643889f029b82aaa24f6e8e7e0c9_prof);

        
        $__internal_bac5017671c13d934706ef4fbe3e80f5a2589cdfabe3a2aadb7cb7ca6a9e56f9->leave($__internal_bac5017671c13d934706ef4fbe3e80f5a2589cdfabe3a2aadb7cb7ca6a9e56f9_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/repeated_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_rows') ?>
", "@Framework/Form/repeated_row.html.php", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\controllers\\symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\repeated_row.html.php");
    }
}
