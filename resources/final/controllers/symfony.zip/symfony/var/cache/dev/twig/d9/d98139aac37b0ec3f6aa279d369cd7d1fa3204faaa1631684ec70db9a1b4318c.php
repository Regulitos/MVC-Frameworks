<?php

/* WebProfilerBundle:Profiler:toolbar_redirect.html.twig */
class __TwigTemplate_89852ac4f07d073d0f759aa1e3412d3ebf9e7c813906aa031a054819504545c0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@Twig/layout.html.twig", "WebProfilerBundle:Profiler:toolbar_redirect.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@Twig/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_267c607d05908cefb45afd3c3654311d4114bcb38c18ceb0de87754633c68cdf = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_267c607d05908cefb45afd3c3654311d4114bcb38c18ceb0de87754633c68cdf->enter($__internal_267c607d05908cefb45afd3c3654311d4114bcb38c18ceb0de87754633c68cdf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:toolbar_redirect.html.twig"));

        $__internal_9086d4c97f799891038c51a37252de967fbbda9e86be6c60dc77555b27215b5c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9086d4c97f799891038c51a37252de967fbbda9e86be6c60dc77555b27215b5c->enter($__internal_9086d4c97f799891038c51a37252de967fbbda9e86be6c60dc77555b27215b5c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:toolbar_redirect.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_267c607d05908cefb45afd3c3654311d4114bcb38c18ceb0de87754633c68cdf->leave($__internal_267c607d05908cefb45afd3c3654311d4114bcb38c18ceb0de87754633c68cdf_prof);

        
        $__internal_9086d4c97f799891038c51a37252de967fbbda9e86be6c60dc77555b27215b5c->leave($__internal_9086d4c97f799891038c51a37252de967fbbda9e86be6c60dc77555b27215b5c_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_3db2496501772893084d811dee5bcec072e4c42d5ce49f4ac12b9717e8de40ba = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3db2496501772893084d811dee5bcec072e4c42d5ce49f4ac12b9717e8de40ba->enter($__internal_3db2496501772893084d811dee5bcec072e4c42d5ce49f4ac12b9717e8de40ba_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_bedbd62c34166fa2d6d1244db83a42a04031282719daa3d53da1982eed9f1524 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_bedbd62c34166fa2d6d1244db83a42a04031282719daa3d53da1982eed9f1524->enter($__internal_bedbd62c34166fa2d6d1244db83a42a04031282719daa3d53da1982eed9f1524_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Redirection Intercepted";
        
        $__internal_bedbd62c34166fa2d6d1244db83a42a04031282719daa3d53da1982eed9f1524->leave($__internal_bedbd62c34166fa2d6d1244db83a42a04031282719daa3d53da1982eed9f1524_prof);

        
        $__internal_3db2496501772893084d811dee5bcec072e4c42d5ce49f4ac12b9717e8de40ba->leave($__internal_3db2496501772893084d811dee5bcec072e4c42d5ce49f4ac12b9717e8de40ba_prof);

    }

    // line 5
    public function block_body($context, array $blocks = array())
    {
        $__internal_5628e3a5f7c0b00dbb75183e20a026e5d405613451c3a7eb1b1f24ccf6a2aefd = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5628e3a5f7c0b00dbb75183e20a026e5d405613451c3a7eb1b1f24ccf6a2aefd->enter($__internal_5628e3a5f7c0b00dbb75183e20a026e5d405613451c3a7eb1b1f24ccf6a2aefd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_dee1b5e015b46b049977d1e31514eed72ec41e16f19f9a7f3cab70561f8b9127 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_dee1b5e015b46b049977d1e31514eed72ec41e16f19f9a7f3cab70561f8b9127->enter($__internal_dee1b5e015b46b049977d1e31514eed72ec41e16f19f9a7f3cab70561f8b9127_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "    <div class=\"sf-reset\">
        <div class=\"block-exception\">
            <h1>This request redirects to <a href=\"";
        // line 8
        echo twig_escape_filter($this->env, ($context["location"] ?? $this->getContext($context, "location")), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, ($context["location"] ?? $this->getContext($context, "location")), "html", null, true);
        echo "</a>.</h1>

            <p>
                <small>
                    The redirect was intercepted by the web debug toolbar to help debugging.
                    For more information, see the \"intercept-redirects\" option of the Profiler.
                </small>
            </p>
        </div>
    </div>
";
        
        $__internal_dee1b5e015b46b049977d1e31514eed72ec41e16f19f9a7f3cab70561f8b9127->leave($__internal_dee1b5e015b46b049977d1e31514eed72ec41e16f19f9a7f3cab70561f8b9127_prof);

        
        $__internal_5628e3a5f7c0b00dbb75183e20a026e5d405613451c3a7eb1b1f24ccf6a2aefd->leave($__internal_5628e3a5f7c0b00dbb75183e20a026e5d405613451c3a7eb1b1f24ccf6a2aefd_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:toolbar_redirect.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  72 => 8,  68 => 6,  59 => 5,  41 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@Twig/layout.html.twig' %}

{% block title 'Redirection Intercepted' %}

{% block body %}
    <div class=\"sf-reset\">
        <div class=\"block-exception\">
            <h1>This request redirects to <a href=\"{{ location }}\">{{ location }}</a>.</h1>

            <p>
                <small>
                    The redirect was intercepted by the web debug toolbar to help debugging.
                    For more information, see the \"intercept-redirects\" option of the Profiler.
                </small>
            </p>
        </div>
    </div>
{% endblock %}
", "WebProfilerBundle:Profiler:toolbar_redirect.html.twig", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\controllers\\symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle/Resources/views/Profiler/toolbar_redirect.html.twig");
    }
}
