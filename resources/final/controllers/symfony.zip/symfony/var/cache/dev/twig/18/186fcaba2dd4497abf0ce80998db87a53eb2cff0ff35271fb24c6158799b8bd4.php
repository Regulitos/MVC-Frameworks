<?php

/* TwigBundle:Exception:exception.json.twig */
class __TwigTemplate_9288100d8334098eb8c275861fc64d9d89cf92d90e88e781d43c3626d822db1f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_14b6447702031339f914713d0f1b9f796a418500b686a97b75887bace602ed37 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_14b6447702031339f914713d0f1b9f796a418500b686a97b75887bace602ed37->enter($__internal_14b6447702031339f914713d0f1b9f796a418500b686a97b75887bace602ed37_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.json.twig"));

        $__internal_963e70282eb47a36ecd9f61599783aea52e06874346d725cecf182849afffd24 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_963e70282eb47a36ecd9f61599783aea52e06874346d725cecf182849afffd24->enter($__internal_963e70282eb47a36ecd9f61599783aea52e06874346d725cecf182849afffd24_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.json.twig"));

        // line 1
        echo twig_jsonencode_filter(array("error" => array("code" => ($context["status_code"] ?? $this->getContext($context, "status_code")), "message" => ($context["status_text"] ?? $this->getContext($context, "status_text")), "exception" => $this->getAttribute(($context["exception"] ?? $this->getContext($context, "exception")), "toarray", array()))));
        echo "
";
        
        $__internal_14b6447702031339f914713d0f1b9f796a418500b686a97b75887bace602ed37->leave($__internal_14b6447702031339f914713d0f1b9f796a418500b686a97b75887bace602ed37_prof);

        
        $__internal_963e70282eb47a36ecd9f61599783aea52e06874346d725cecf182849afffd24->leave($__internal_963e70282eb47a36ecd9f61599783aea52e06874346d725cecf182849afffd24_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.json.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ { 'error': { 'code': status_code, 'message': status_text, 'exception': exception.toarray } }|json_encode|raw }}
", "TwigBundle:Exception:exception.json.twig", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\controllers\\symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle/Resources/views/Exception/exception.json.twig");
    }
}
