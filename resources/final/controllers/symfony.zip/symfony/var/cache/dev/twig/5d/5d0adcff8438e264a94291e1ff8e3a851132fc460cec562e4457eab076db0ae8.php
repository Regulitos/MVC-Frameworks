<?php

/* @Framework/FormTable/hidden_row.html.php */
class __TwigTemplate_cf2596bacc63137065402920d774b5256063187a65f51591cf623dd87798c29d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_72c267fbbacbe1ebdfcd9792430447ad6063a201b4476de52a7c28af43125baf = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_72c267fbbacbe1ebdfcd9792430447ad6063a201b4476de52a7c28af43125baf->enter($__internal_72c267fbbacbe1ebdfcd9792430447ad6063a201b4476de52a7c28af43125baf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/hidden_row.html.php"));

        $__internal_15c4d916681a3b3967597e3a39b739f9df2708a48d564b332a790268ecaf2f46 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_15c4d916681a3b3967597e3a39b739f9df2708a48d564b332a790268ecaf2f46->enter($__internal_15c4d916681a3b3967597e3a39b739f9df2708a48d564b332a790268ecaf2f46_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/hidden_row.html.php"));

        // line 1
        echo "<tr style=\"display: none\">
    <td colspan=\"2\">
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
";
        
        $__internal_72c267fbbacbe1ebdfcd9792430447ad6063a201b4476de52a7c28af43125baf->leave($__internal_72c267fbbacbe1ebdfcd9792430447ad6063a201b4476de52a7c28af43125baf_prof);

        
        $__internal_15c4d916681a3b3967597e3a39b739f9df2708a48d564b332a790268ecaf2f46->leave($__internal_15c4d916681a3b3967597e3a39b739f9df2708a48d564b332a790268ecaf2f46_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/hidden_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<tr style=\"display: none\">
    <td colspan=\"2\">
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
", "@Framework/FormTable/hidden_row.html.php", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\controllers\\symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\FormTable\\hidden_row.html.php");
    }
}
