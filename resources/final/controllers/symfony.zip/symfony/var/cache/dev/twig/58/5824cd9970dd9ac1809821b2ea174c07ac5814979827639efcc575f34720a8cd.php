<?php

/* @Framework/Form/password_widget.html.php */
class __TwigTemplate_5a5f5c2e94ae3444b03cc7931e0df645efc015df2af71eb52a9f5db0e75b716f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8e879e107bdc77264895f34463720e36d30ad6d59e3ed2c82f8c7e7e0289aa4a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8e879e107bdc77264895f34463720e36d30ad6d59e3ed2c82f8c7e7e0289aa4a->enter($__internal_8e879e107bdc77264895f34463720e36d30ad6d59e3ed2c82f8c7e7e0289aa4a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/password_widget.html.php"));

        $__internal_88461a6b703c1e2bdce2513d38ef448f7c87653147c32f4d0f1446724c25ed91 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_88461a6b703c1e2bdce2513d38ef448f7c87653147c32f4d0f1446724c25ed91->enter($__internal_88461a6b703c1e2bdce2513d38ef448f7c87653147c32f4d0f1446724c25ed91_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/password_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'password')) ?>
";
        
        $__internal_8e879e107bdc77264895f34463720e36d30ad6d59e3ed2c82f8c7e7e0289aa4a->leave($__internal_8e879e107bdc77264895f34463720e36d30ad6d59e3ed2c82f8c7e7e0289aa4a_prof);

        
        $__internal_88461a6b703c1e2bdce2513d38ef448f7c87653147c32f4d0f1446724c25ed91->leave($__internal_88461a6b703c1e2bdce2513d38ef448f7c87653147c32f4d0f1446724c25ed91_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/password_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'password')) ?>
", "@Framework/Form/password_widget.html.php", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\controllers\\symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\password_widget.html.php");
    }
}
