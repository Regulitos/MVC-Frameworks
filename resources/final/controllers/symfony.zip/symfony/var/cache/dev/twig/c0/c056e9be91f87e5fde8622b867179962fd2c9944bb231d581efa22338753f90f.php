<?php

/* TwigBundle:Exception:error.rdf.twig */
class __TwigTemplate_26edb4916903690e4fa175d2997e52784c4ac4cddc89b07f3700cfc3850459e3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f40fe1b2ed9e5bab06821707d0de168a476f46a0293cd2c66c80c797274a4148 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f40fe1b2ed9e5bab06821707d0de168a476f46a0293cd2c66c80c797274a4148->enter($__internal_f40fe1b2ed9e5bab06821707d0de168a476f46a0293cd2c66c80c797274a4148_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.rdf.twig"));

        $__internal_5be2f771804e81744c423868a835642c960e9d26148f39b1d7c82b39406f75e2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5be2f771804e81744c423868a835642c960e9d26148f39b1d7c82b39406f75e2->enter($__internal_5be2f771804e81744c423868a835642c960e9d26148f39b1d7c82b39406f75e2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.rdf.twig"));

        // line 1
        echo twig_include($this->env, $context, "@Twig/Exception/error.xml.twig");
        echo "
";
        
        $__internal_f40fe1b2ed9e5bab06821707d0de168a476f46a0293cd2c66c80c797274a4148->leave($__internal_f40fe1b2ed9e5bab06821707d0de168a476f46a0293cd2c66c80c797274a4148_prof);

        
        $__internal_5be2f771804e81744c423868a835642c960e9d26148f39b1d7c82b39406f75e2->leave($__internal_5be2f771804e81744c423868a835642c960e9d26148f39b1d7c82b39406f75e2_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.rdf.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ include('@Twig/Exception/error.xml.twig') }}
", "TwigBundle:Exception:error.rdf.twig", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\controllers\\symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle/Resources/views/Exception/error.rdf.twig");
    }
}
