<?php

/* @WebProfiler/Icon/forward.svg */
class __TwigTemplate_cc9469bc95cbed27efba26f71032a6a2d5282caff6caa970618ce3b34a6a67d9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7d91ed4e76e0b4c3df01166c2947c67c8d25f0ad5b6e9359de532e57c9ee192f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_7d91ed4e76e0b4c3df01166c2947c67c8d25f0ad5b6e9359de532e57c9ee192f->enter($__internal_7d91ed4e76e0b4c3df01166c2947c67c8d25f0ad5b6e9359de532e57c9ee192f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Icon/forward.svg"));

        $__internal_e364908068bd32768befd7444ccff0e31b5d6f61e84890107411e81b584fe00b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e364908068bd32768befd7444ccff0e31b5d6f61e84890107411e81b584fe00b->enter($__internal_e364908068bd32768befd7444ccff0e31b5d6f61e84890107411e81b584fe00b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Icon/forward.svg"));

        // line 1
        echo "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\">
    <path style=\"fill:#aaa\" d=\"M23.61,11.07L17.07,4.35A1.2,1.2,0,0,0,15,5.28V9H1.4A1.82,1.82,0,0,0,0,10.82v2.61A1.55,
        1.55,0,0,0,1.4,15H15v3.72a1.2,1.2,0,0,0,2.07.93l6.63-6.72A1.32,1.32,0,0,0,23.61,11.07Z\"/>
</svg>
";
        
        $__internal_7d91ed4e76e0b4c3df01166c2947c67c8d25f0ad5b6e9359de532e57c9ee192f->leave($__internal_7d91ed4e76e0b4c3df01166c2947c67c8d25f0ad5b6e9359de532e57c9ee192f_prof);

        
        $__internal_e364908068bd32768befd7444ccff0e31b5d6f61e84890107411e81b584fe00b->leave($__internal_e364908068bd32768befd7444ccff0e31b5d6f61e84890107411e81b584fe00b_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Icon/forward.svg";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\">
    <path style=\"fill:#aaa\" d=\"M23.61,11.07L17.07,4.35A1.2,1.2,0,0,0,15,5.28V9H1.4A1.82,1.82,0,0,0,0,10.82v2.61A1.55,
        1.55,0,0,0,1.4,15H15v3.72a1.2,1.2,0,0,0,2.07.93l6.63-6.72A1.32,1.32,0,0,0,23.61,11.07Z\"/>
</svg>
", "@WebProfiler/Icon/forward.svg", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\controllers\\symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Icon\\forward.svg");
    }
}
