<?php

/* @Framework/Form/widget_attributes.html.php */
class __TwigTemplate_ec11ec67a0f14336c7d965b38e7029e8aedc276223e341b6a3651b82c566562e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_16729649c7f5f303730b03858edcd0646638a4b6076d90cc15e5d1945af62054 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_16729649c7f5f303730b03858edcd0646638a4b6076d90cc15e5d1945af62054->enter($__internal_16729649c7f5f303730b03858edcd0646638a4b6076d90cc15e5d1945af62054_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/widget_attributes.html.php"));

        $__internal_2a212755a49b7817087ab3df20497b0f2a921b4230739fbd17c5759875ba2fef = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2a212755a49b7817087ab3df20497b0f2a921b4230739fbd17c5759875ba2fef->enter($__internal_2a212755a49b7817087ab3df20497b0f2a921b4230739fbd17c5759875ba2fef_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/widget_attributes.html.php"));

        // line 1
        echo "id=\"<?php echo \$view->escape(\$id) ?>\" name=\"<?php echo \$view->escape(\$full_name) ?>\"<?php if (\$disabled): ?> disabled=\"disabled\"<?php endif ?>
<?php if (\$required): ?> required=\"required\"<?php endif ?>
<?php echo \$attr ? ' '.\$view['form']->block(\$form, 'attributes') : '' ?>
";
        
        $__internal_16729649c7f5f303730b03858edcd0646638a4b6076d90cc15e5d1945af62054->leave($__internal_16729649c7f5f303730b03858edcd0646638a4b6076d90cc15e5d1945af62054_prof);

        
        $__internal_2a212755a49b7817087ab3df20497b0f2a921b4230739fbd17c5759875ba2fef->leave($__internal_2a212755a49b7817087ab3df20497b0f2a921b4230739fbd17c5759875ba2fef_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/widget_attributes.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("id=\"<?php echo \$view->escape(\$id) ?>\" name=\"<?php echo \$view->escape(\$full_name) ?>\"<?php if (\$disabled): ?> disabled=\"disabled\"<?php endif ?>
<?php if (\$required): ?> required=\"required\"<?php endif ?>
<?php echo \$attr ? ' '.\$view['form']->block(\$form, 'attributes') : '' ?>
", "@Framework/Form/widget_attributes.html.php", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\controllers\\symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\widget_attributes.html.php");
    }
}
