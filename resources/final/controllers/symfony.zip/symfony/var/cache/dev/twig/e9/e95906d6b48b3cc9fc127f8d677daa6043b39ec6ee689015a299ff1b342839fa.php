<?php

/* @Framework/Form/percent_widget.html.php */
class __TwigTemplate_09c9defca89b2fc2b2d87d9354240e301bf227357198eca9ac867e5082d3d5bf extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1954199f9ad842f8c0ce260601e5de70b3c04e19a80434576338e56ecb81fbb9 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1954199f9ad842f8c0ce260601e5de70b3c04e19a80434576338e56ecb81fbb9->enter($__internal_1954199f9ad842f8c0ce260601e5de70b3c04e19a80434576338e56ecb81fbb9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/percent_widget.html.php"));

        $__internal_d80f4b096209ab36f615eac9ffa086b2eed4356ded9f2759f23281d65aba6e0c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d80f4b096209ab36f615eac9ffa086b2eed4356ded9f2759f23281d65aba6e0c->enter($__internal_d80f4b096209ab36f615eac9ffa086b2eed4356ded9f2759f23281d65aba6e0c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/percent_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'text')) ?> %
";
        
        $__internal_1954199f9ad842f8c0ce260601e5de70b3c04e19a80434576338e56ecb81fbb9->leave($__internal_1954199f9ad842f8c0ce260601e5de70b3c04e19a80434576338e56ecb81fbb9_prof);

        
        $__internal_d80f4b096209ab36f615eac9ffa086b2eed4356ded9f2759f23281d65aba6e0c->leave($__internal_d80f4b096209ab36f615eac9ffa086b2eed4356ded9f2759f23281d65aba6e0c_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/percent_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'text')) ?> %
", "@Framework/Form/percent_widget.html.php", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\controllers\\symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\percent_widget.html.php");
    }
}
