<?php

/* @Framework/Form/range_widget.html.php */
class __TwigTemplate_befb86bdbe916d661cb0339f496b43d4c56b3adbfa5093111911c32ca8aeffbe extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_edef6ba17bacb5555a60731487586576c28689e2911bdb7f9d9b65d62d81f6d4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_edef6ba17bacb5555a60731487586576c28689e2911bdb7f9d9b65d62d81f6d4->enter($__internal_edef6ba17bacb5555a60731487586576c28689e2911bdb7f9d9b65d62d81f6d4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/range_widget.html.php"));

        $__internal_90e647949cf6e82c8b732f4cb79ef0300f43f6683cddc231eaa20bfd4041e086 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_90e647949cf6e82c8b732f4cb79ef0300f43f6683cddc231eaa20bfd4041e086->enter($__internal_90e647949cf6e82c8b732f4cb79ef0300f43f6683cddc231eaa20bfd4041e086_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/range_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'range'));
";
        
        $__internal_edef6ba17bacb5555a60731487586576c28689e2911bdb7f9d9b65d62d81f6d4->leave($__internal_edef6ba17bacb5555a60731487586576c28689e2911bdb7f9d9b65d62d81f6d4_prof);

        
        $__internal_90e647949cf6e82c8b732f4cb79ef0300f43f6683cddc231eaa20bfd4041e086->leave($__internal_90e647949cf6e82c8b732f4cb79ef0300f43f6683cddc231eaa20bfd4041e086_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/range_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'range'));
", "@Framework/Form/range_widget.html.php", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\controllers\\symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\range_widget.html.php");
    }
}
