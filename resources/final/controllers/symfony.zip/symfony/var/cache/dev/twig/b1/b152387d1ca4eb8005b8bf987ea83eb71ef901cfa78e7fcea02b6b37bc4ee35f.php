<?php

/* @WebProfiler/Profiler/toolbar_redirect.html.twig */
class __TwigTemplate_b3bc6c61daa78099703cd636bf909b5a35b1e5a72efb9a36c4125b567accfaa0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@Twig/layout.html.twig", "@WebProfiler/Profiler/toolbar_redirect.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@Twig/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b80a0fe02661172d6673a133a5f86e4aa190c6e621c06505b0548681d392b0aa = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b80a0fe02661172d6673a133a5f86e4aa190c6e621c06505b0548681d392b0aa->enter($__internal_b80a0fe02661172d6673a133a5f86e4aa190c6e621c06505b0548681d392b0aa_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/toolbar_redirect.html.twig"));

        $__internal_2db327bc3e5d6b774d541e06fcdc2814e8eba1bf142653eeea0e6006aed9068f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2db327bc3e5d6b774d541e06fcdc2814e8eba1bf142653eeea0e6006aed9068f->enter($__internal_2db327bc3e5d6b774d541e06fcdc2814e8eba1bf142653eeea0e6006aed9068f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/toolbar_redirect.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_b80a0fe02661172d6673a133a5f86e4aa190c6e621c06505b0548681d392b0aa->leave($__internal_b80a0fe02661172d6673a133a5f86e4aa190c6e621c06505b0548681d392b0aa_prof);

        
        $__internal_2db327bc3e5d6b774d541e06fcdc2814e8eba1bf142653eeea0e6006aed9068f->leave($__internal_2db327bc3e5d6b774d541e06fcdc2814e8eba1bf142653eeea0e6006aed9068f_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_c423177733abc0f6e93597ed0d5e0d0ee9da04a39d01bed9e237de4423344ed3 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c423177733abc0f6e93597ed0d5e0d0ee9da04a39d01bed9e237de4423344ed3->enter($__internal_c423177733abc0f6e93597ed0d5e0d0ee9da04a39d01bed9e237de4423344ed3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_036286a9821940e6083cac7edb1f6f0236e2b8d801c9d9da72ab1a87916df7a4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_036286a9821940e6083cac7edb1f6f0236e2b8d801c9d9da72ab1a87916df7a4->enter($__internal_036286a9821940e6083cac7edb1f6f0236e2b8d801c9d9da72ab1a87916df7a4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Redirection Intercepted";
        
        $__internal_036286a9821940e6083cac7edb1f6f0236e2b8d801c9d9da72ab1a87916df7a4->leave($__internal_036286a9821940e6083cac7edb1f6f0236e2b8d801c9d9da72ab1a87916df7a4_prof);

        
        $__internal_c423177733abc0f6e93597ed0d5e0d0ee9da04a39d01bed9e237de4423344ed3->leave($__internal_c423177733abc0f6e93597ed0d5e0d0ee9da04a39d01bed9e237de4423344ed3_prof);

    }

    // line 5
    public function block_body($context, array $blocks = array())
    {
        $__internal_c1b64e262984528965d2b56035ba95430d021c6696355e7e0bec5f672376d492 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c1b64e262984528965d2b56035ba95430d021c6696355e7e0bec5f672376d492->enter($__internal_c1b64e262984528965d2b56035ba95430d021c6696355e7e0bec5f672376d492_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_defd3e1e7218f1f5ffc9c4d844e2fc03ffe7b63079f9d56e33aec94908baefd5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_defd3e1e7218f1f5ffc9c4d844e2fc03ffe7b63079f9d56e33aec94908baefd5->enter($__internal_defd3e1e7218f1f5ffc9c4d844e2fc03ffe7b63079f9d56e33aec94908baefd5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "    <div class=\"sf-reset\">
        <div class=\"block-exception\">
            <h1>This request redirects to <a href=\"";
        // line 8
        echo twig_escape_filter($this->env, ($context["location"] ?? $this->getContext($context, "location")), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, ($context["location"] ?? $this->getContext($context, "location")), "html", null, true);
        echo "</a>.</h1>

            <p>
                <small>
                    The redirect was intercepted by the web debug toolbar to help debugging.
                    For more information, see the \"intercept-redirects\" option of the Profiler.
                </small>
            </p>
        </div>
    </div>
";
        
        $__internal_defd3e1e7218f1f5ffc9c4d844e2fc03ffe7b63079f9d56e33aec94908baefd5->leave($__internal_defd3e1e7218f1f5ffc9c4d844e2fc03ffe7b63079f9d56e33aec94908baefd5_prof);

        
        $__internal_c1b64e262984528965d2b56035ba95430d021c6696355e7e0bec5f672376d492->leave($__internal_c1b64e262984528965d2b56035ba95430d021c6696355e7e0bec5f672376d492_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Profiler/toolbar_redirect.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  72 => 8,  68 => 6,  59 => 5,  41 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@Twig/layout.html.twig' %}

{% block title 'Redirection Intercepted' %}

{% block body %}
    <div class=\"sf-reset\">
        <div class=\"block-exception\">
            <h1>This request redirects to <a href=\"{{ location }}\">{{ location }}</a>.</h1>

            <p>
                <small>
                    The redirect was intercepted by the web debug toolbar to help debugging.
                    For more information, see the \"intercept-redirects\" option of the Profiler.
                </small>
            </p>
        </div>
    </div>
{% endblock %}
", "@WebProfiler/Profiler/toolbar_redirect.html.twig", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\controllers\\symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Profiler\\toolbar_redirect.html.twig");
    }
}
