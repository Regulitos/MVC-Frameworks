<?php

/* TwigBundle:Exception:error.txt.twig */
class __TwigTemplate_68b5d63f7afffb2b243217ce96d745bf0a563bb8d2e5b6925445dc16766b395a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b3d039de343aec9f737bda87006ece8afd7f8c004a435bc1330acc922b9a4013 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b3d039de343aec9f737bda87006ece8afd7f8c004a435bc1330acc922b9a4013->enter($__internal_b3d039de343aec9f737bda87006ece8afd7f8c004a435bc1330acc922b9a4013_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.txt.twig"));

        $__internal_bc48beac405a177234be1bbaca852886d9eb8ec02137edd8a697a72564d0e39d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_bc48beac405a177234be1bbaca852886d9eb8ec02137edd8a697a72564d0e39d->enter($__internal_bc48beac405a177234be1bbaca852886d9eb8ec02137edd8a697a72564d0e39d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.txt.twig"));

        // line 1
        echo "Oops! An Error Occurred
=======================

The server returned a \"";
        // line 4
        echo ($context["status_code"] ?? $this->getContext($context, "status_code"));
        echo " ";
        echo ($context["status_text"] ?? $this->getContext($context, "status_text"));
        echo "\".

Something is broken. Please let us know what you were doing when this error occurred.
We will fix it as soon as possible. Sorry for any inconvenience caused.
";
        
        $__internal_b3d039de343aec9f737bda87006ece8afd7f8c004a435bc1330acc922b9a4013->leave($__internal_b3d039de343aec9f737bda87006ece8afd7f8c004a435bc1330acc922b9a4013_prof);

        
        $__internal_bc48beac405a177234be1bbaca852886d9eb8ec02137edd8a697a72564d0e39d->leave($__internal_bc48beac405a177234be1bbaca852886d9eb8ec02137edd8a697a72564d0e39d_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.txt.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  30 => 4,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("Oops! An Error Occurred
=======================

The server returned a \"{{ status_code }} {{ status_text }}\".

Something is broken. Please let us know what you were doing when this error occurred.
We will fix it as soon as possible. Sorry for any inconvenience caused.
", "TwigBundle:Exception:error.txt.twig", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\controllers\\symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle/Resources/views/Exception/error.txt.twig");
    }
}
