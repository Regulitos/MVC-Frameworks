<?php

/* @Twig/Exception/exception.rdf.twig */
class __TwigTemplate_8ab05884ce77ab2e1c1ed14109329ea8e655221064619f629c2594bb424171b5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_47fc8654e03e9a8a6fd7ec01dfe7ebedec186e9f930b421d2ba9b38dcbc70420 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_47fc8654e03e9a8a6fd7ec01dfe7ebedec186e9f930b421d2ba9b38dcbc70420->enter($__internal_47fc8654e03e9a8a6fd7ec01dfe7ebedec186e9f930b421d2ba9b38dcbc70420_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.rdf.twig"));

        $__internal_c5d3fdebcf48f1fa6510529b987cfafbdb8317a320c3426076c825ff9e1a4f49 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c5d3fdebcf48f1fa6510529b987cfafbdb8317a320c3426076c825ff9e1a4f49->enter($__internal_c5d3fdebcf48f1fa6510529b987cfafbdb8317a320c3426076c825ff9e1a4f49_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.rdf.twig"));

        // line 1
        echo twig_include($this->env, $context, "@Twig/Exception/exception.xml.twig", array("exception" => ($context["exception"] ?? $this->getContext($context, "exception"))));
        echo "
";
        
        $__internal_47fc8654e03e9a8a6fd7ec01dfe7ebedec186e9f930b421d2ba9b38dcbc70420->leave($__internal_47fc8654e03e9a8a6fd7ec01dfe7ebedec186e9f930b421d2ba9b38dcbc70420_prof);

        
        $__internal_c5d3fdebcf48f1fa6510529b987cfafbdb8317a320c3426076c825ff9e1a4f49->leave($__internal_c5d3fdebcf48f1fa6510529b987cfafbdb8317a320c3426076c825ff9e1a4f49_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/exception.rdf.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ include('@Twig/Exception/exception.xml.twig', { exception: exception }) }}
", "@Twig/Exception/exception.rdf.twig", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\controllers\\symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\exception.rdf.twig");
    }
}
