<?php

/* @Twig/Exception/exception.js.twig */
class __TwigTemplate_503a724b00859d73420ea91e59716c8bb8214c1a5e6126e48cf929e0c700f40e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_71ea20c73832aadec5b566c2978b96ce42ed38d9ffd294ce7d185edabe51343a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_71ea20c73832aadec5b566c2978b96ce42ed38d9ffd294ce7d185edabe51343a->enter($__internal_71ea20c73832aadec5b566c2978b96ce42ed38d9ffd294ce7d185edabe51343a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.js.twig"));

        $__internal_a32868a1c4a0a78033fe0f53b3ebe5159a1effdc6ac2d809a2adbdd35986e7cd = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a32868a1c4a0a78033fe0f53b3ebe5159a1effdc6ac2d809a2adbdd35986e7cd->enter($__internal_a32868a1c4a0a78033fe0f53b3ebe5159a1effdc6ac2d809a2adbdd35986e7cd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.js.twig"));

        // line 1
        echo "/*
";
        // line 2
        echo twig_include($this->env, $context, "@Twig/Exception/exception.txt.twig", array("exception" => ($context["exception"] ?? $this->getContext($context, "exception"))));
        echo "
*/
";
        
        $__internal_71ea20c73832aadec5b566c2978b96ce42ed38d9ffd294ce7d185edabe51343a->leave($__internal_71ea20c73832aadec5b566c2978b96ce42ed38d9ffd294ce7d185edabe51343a_prof);

        
        $__internal_a32868a1c4a0a78033fe0f53b3ebe5159a1effdc6ac2d809a2adbdd35986e7cd->leave($__internal_a32868a1c4a0a78033fe0f53b3ebe5159a1effdc6ac2d809a2adbdd35986e7cd_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/exception.js.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  28 => 2,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("/*
{{ include('@Twig/Exception/exception.txt.twig', { exception: exception }) }}
*/
", "@Twig/Exception/exception.js.twig", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\controllers\\symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\exception.js.twig");
    }
}
