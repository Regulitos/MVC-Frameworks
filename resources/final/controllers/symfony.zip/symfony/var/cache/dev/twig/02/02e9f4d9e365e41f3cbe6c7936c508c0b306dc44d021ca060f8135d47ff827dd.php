<?php

/* @Twig/Exception/error.atom.twig */
class __TwigTemplate_6ae93012740d9831bf45d8eec53ec090b960cb14574cd72bfce0d741960b659b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_29646d9e7300a4d3031a6d608bab81efe125ecd7310221ed8c0b3978e5a88336 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_29646d9e7300a4d3031a6d608bab81efe125ecd7310221ed8c0b3978e5a88336->enter($__internal_29646d9e7300a4d3031a6d608bab81efe125ecd7310221ed8c0b3978e5a88336_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.atom.twig"));

        $__internal_f679c0e8e7a8c20faa3954ae9774ebacc47566f1ee68202acfa769a6da75de25 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f679c0e8e7a8c20faa3954ae9774ebacc47566f1ee68202acfa769a6da75de25->enter($__internal_f679c0e8e7a8c20faa3954ae9774ebacc47566f1ee68202acfa769a6da75de25_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.atom.twig"));

        // line 1
        echo twig_include($this->env, $context, "@Twig/Exception/error.xml.twig");
        echo "
";
        
        $__internal_29646d9e7300a4d3031a6d608bab81efe125ecd7310221ed8c0b3978e5a88336->leave($__internal_29646d9e7300a4d3031a6d608bab81efe125ecd7310221ed8c0b3978e5a88336_prof);

        
        $__internal_f679c0e8e7a8c20faa3954ae9774ebacc47566f1ee68202acfa769a6da75de25->leave($__internal_f679c0e8e7a8c20faa3954ae9774ebacc47566f1ee68202acfa769a6da75de25_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/error.atom.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ include('@Twig/Exception/error.xml.twig') }}
", "@Twig/Exception/error.atom.twig", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\controllers\\symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\error.atom.twig");
    }
}
