<?php

/* @Framework/Form/form.html.php */
class __TwigTemplate_f47514a0765002d13c4a270a024c4310c16fe421bb11d882e8c598000256d859 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_cdb4be6cf146656bf9ad8e0c98b88280e6bc613d38ae31c0e2bab8adf7ca1fb4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_cdb4be6cf146656bf9ad8e0c98b88280e6bc613d38ae31c0e2bab8adf7ca1fb4->enter($__internal_cdb4be6cf146656bf9ad8e0c98b88280e6bc613d38ae31c0e2bab8adf7ca1fb4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form.html.php"));

        $__internal_6cbf76c83978eb409d80db2636cc915a208fa57368267fab1d4855e28809088a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6cbf76c83978eb409d80db2636cc915a208fa57368267fab1d4855e28809088a->enter($__internal_6cbf76c83978eb409d80db2636cc915a208fa57368267fab1d4855e28809088a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form.html.php"));

        // line 1
        echo "<?php echo \$view['form']->start(\$form) ?>
    <?php echo \$view['form']->widget(\$form) ?>
<?php echo \$view['form']->end(\$form) ?>
";
        
        $__internal_cdb4be6cf146656bf9ad8e0c98b88280e6bc613d38ae31c0e2bab8adf7ca1fb4->leave($__internal_cdb4be6cf146656bf9ad8e0c98b88280e6bc613d38ae31c0e2bab8adf7ca1fb4_prof);

        
        $__internal_6cbf76c83978eb409d80db2636cc915a208fa57368267fab1d4855e28809088a->leave($__internal_6cbf76c83978eb409d80db2636cc915a208fa57368267fab1d4855e28809088a_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->start(\$form) ?>
    <?php echo \$view['form']->widget(\$form) ?>
<?php echo \$view['form']->end(\$form) ?>
", "@Framework/Form/form.html.php", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\controllers\\symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\form.html.php");
    }
}
