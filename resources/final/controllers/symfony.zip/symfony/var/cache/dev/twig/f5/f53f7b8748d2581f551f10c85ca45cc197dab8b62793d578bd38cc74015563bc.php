<?php

/* TwigBundle:Exception:error.json.twig */
class __TwigTemplate_3a010ab51691f963c8a75573053e9d8771d909b3dd7c9b14dbdd21839e35835b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_54560eec15b2edce97aa25a1a0e8dc74d61da22177947d042e4eab7dd5369302 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_54560eec15b2edce97aa25a1a0e8dc74d61da22177947d042e4eab7dd5369302->enter($__internal_54560eec15b2edce97aa25a1a0e8dc74d61da22177947d042e4eab7dd5369302_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.json.twig"));

        $__internal_095c2c1a5ed641f4ebb0391623a57b3a8edbb991c87afde86308cc14c6cb4e10 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_095c2c1a5ed641f4ebb0391623a57b3a8edbb991c87afde86308cc14c6cb4e10->enter($__internal_095c2c1a5ed641f4ebb0391623a57b3a8edbb991c87afde86308cc14c6cb4e10_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.json.twig"));

        // line 1
        echo twig_jsonencode_filter(array("error" => array("code" => ($context["status_code"] ?? $this->getContext($context, "status_code")), "message" => ($context["status_text"] ?? $this->getContext($context, "status_text")))));
        echo "
";
        
        $__internal_54560eec15b2edce97aa25a1a0e8dc74d61da22177947d042e4eab7dd5369302->leave($__internal_54560eec15b2edce97aa25a1a0e8dc74d61da22177947d042e4eab7dd5369302_prof);

        
        $__internal_095c2c1a5ed641f4ebb0391623a57b3a8edbb991c87afde86308cc14c6cb4e10->leave($__internal_095c2c1a5ed641f4ebb0391623a57b3a8edbb991c87afde86308cc14c6cb4e10_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.json.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ { 'error': { 'code': status_code, 'message': status_text } }|json_encode|raw }}
", "TwigBundle:Exception:error.json.twig", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\controllers\\symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle/Resources/views/Exception/error.json.twig");
    }
}
