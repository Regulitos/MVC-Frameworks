<?php

/* @Twig/Exception/error.txt.twig */
class __TwigTemplate_1db20d4c57e35a0561eecf7e300c59ca84d7c212b9170c00e09fae1c4a97b420 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_82a4a628309fdf3d7f7a64ac15f33e440ec72b4410638b7e2148babb91c7a52f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_82a4a628309fdf3d7f7a64ac15f33e440ec72b4410638b7e2148babb91c7a52f->enter($__internal_82a4a628309fdf3d7f7a64ac15f33e440ec72b4410638b7e2148babb91c7a52f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.txt.twig"));

        $__internal_d9b0056a99b86c180c5cc40694be22f8fc8235625c189157fe3a1fac84e2b88c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d9b0056a99b86c180c5cc40694be22f8fc8235625c189157fe3a1fac84e2b88c->enter($__internal_d9b0056a99b86c180c5cc40694be22f8fc8235625c189157fe3a1fac84e2b88c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.txt.twig"));

        // line 1
        echo "Oops! An Error Occurred
=======================

The server returned a \"";
        // line 4
        echo ($context["status_code"] ?? $this->getContext($context, "status_code"));
        echo " ";
        echo ($context["status_text"] ?? $this->getContext($context, "status_text"));
        echo "\".

Something is broken. Please let us know what you were doing when this error occurred.
We will fix it as soon as possible. Sorry for any inconvenience caused.
";
        
        $__internal_82a4a628309fdf3d7f7a64ac15f33e440ec72b4410638b7e2148babb91c7a52f->leave($__internal_82a4a628309fdf3d7f7a64ac15f33e440ec72b4410638b7e2148babb91c7a52f_prof);

        
        $__internal_d9b0056a99b86c180c5cc40694be22f8fc8235625c189157fe3a1fac84e2b88c->leave($__internal_d9b0056a99b86c180c5cc40694be22f8fc8235625c189157fe3a1fac84e2b88c_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/error.txt.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  30 => 4,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("Oops! An Error Occurred
=======================

The server returned a \"{{ status_code }} {{ status_text }}\".

Something is broken. Please let us know what you were doing when this error occurred.
We will fix it as soon as possible. Sorry for any inconvenience caused.
", "@Twig/Exception/error.txt.twig", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\controllers\\symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\error.txt.twig");
    }
}
