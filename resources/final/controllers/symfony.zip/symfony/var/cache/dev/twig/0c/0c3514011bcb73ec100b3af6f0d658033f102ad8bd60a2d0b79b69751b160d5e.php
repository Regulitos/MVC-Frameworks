<?php

/* @Framework/Form/choice_widget_expanded.html.php */
class __TwigTemplate_7964a3d2d22666d5d0472910c730b90b96dd2e5fbd6437335d499470439738f3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c54f6186bfdeefde6f9906da1bb8ec1a29fe9803791bc681af928511730189b8 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c54f6186bfdeefde6f9906da1bb8ec1a29fe9803791bc681af928511730189b8->enter($__internal_c54f6186bfdeefde6f9906da1bb8ec1a29fe9803791bc681af928511730189b8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_widget_expanded.html.php"));

        $__internal_26595184721b336f0d67e563e9f21e2c1a9cf6fcac7b1456e223b987d18f680b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_26595184721b336f0d67e563e9f21e2c1a9cf6fcac7b1456e223b987d18f680b->enter($__internal_26595184721b336f0d67e563e9f21e2c1a9cf6fcac7b1456e223b987d18f680b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_widget_expanded.html.php"));

        // line 1
        echo "<div <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
<?php foreach (\$form as \$child): ?>
    <?php echo \$view['form']->widget(\$child) ?>
    <?php echo \$view['form']->label(\$child, null, array('translation_domain' => \$choice_translation_domain)) ?>
<?php endforeach ?>
</div>
";
        
        $__internal_c54f6186bfdeefde6f9906da1bb8ec1a29fe9803791bc681af928511730189b8->leave($__internal_c54f6186bfdeefde6f9906da1bb8ec1a29fe9803791bc681af928511730189b8_prof);

        
        $__internal_26595184721b336f0d67e563e9f21e2c1a9cf6fcac7b1456e223b987d18f680b->leave($__internal_26595184721b336f0d67e563e9f21e2c1a9cf6fcac7b1456e223b987d18f680b_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/choice_widget_expanded.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
<?php foreach (\$form as \$child): ?>
    <?php echo \$view['form']->widget(\$child) ?>
    <?php echo \$view['form']->label(\$child, null, array('translation_domain' => \$choice_translation_domain)) ?>
<?php endforeach ?>
</div>
", "@Framework/Form/choice_widget_expanded.html.php", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\controllers\\symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\choice_widget_expanded.html.php");
    }
}
