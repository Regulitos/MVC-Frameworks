<?php

/* @WebProfiler/Collector/exception.css.twig */
class __TwigTemplate_771a6d471daf0f81f81b2ce0315d4f6fdf3405df4b4ec6bb5de37d52456374ee extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_804d6b8faed8331b58b6c14d52bea66b5273b148cd7d5ebff92c7f5ba6d1145f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_804d6b8faed8331b58b6c14d52bea66b5273b148cd7d5ebff92c7f5ba6d1145f->enter($__internal_804d6b8faed8331b58b6c14d52bea66b5273b148cd7d5ebff92c7f5ba6d1145f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/exception.css.twig"));

        $__internal_e3907cc535ec8b5d0ec60c9772c69ea16e1d87195706f8d9e81392ae2b0ee68c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e3907cc535ec8b5d0ec60c9772c69ea16e1d87195706f8d9e81392ae2b0ee68c->enter($__internal_e3907cc535ec8b5d0ec60c9772c69ea16e1d87195706f8d9e81392ae2b0ee68c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/exception.css.twig"));

        // line 1
        echo twig_include($this->env, $context, "@Twig/exception.css.twig");
        echo "

.container {
    max-width: auto;
    margin: 0;
    padding: 0;
}
.container .container {
    padding: 0;
}

.exception-summary {
    background: #FFF;
    border: 1px solid #E0E0E0;
    box-shadow: 0 0 1px rgba(128, 128, 128, .2);
    margin: 1em 0;
    padding: 10px;
}

.exception-message {
    color: #B0413E;
}

.exception-metadata,
.exception-illustration {
    display: none;
}

.exception-message-wrapper {
    min-height: auto;
}
";
        
        $__internal_804d6b8faed8331b58b6c14d52bea66b5273b148cd7d5ebff92c7f5ba6d1145f->leave($__internal_804d6b8faed8331b58b6c14d52bea66b5273b148cd7d5ebff92c7f5ba6d1145f_prof);

        
        $__internal_e3907cc535ec8b5d0ec60c9772c69ea16e1d87195706f8d9e81392ae2b0ee68c->leave($__internal_e3907cc535ec8b5d0ec60c9772c69ea16e1d87195706f8d9e81392ae2b0ee68c_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/exception.css.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ include('@Twig/exception.css.twig') }}

.container {
    max-width: auto;
    margin: 0;
    padding: 0;
}
.container .container {
    padding: 0;
}

.exception-summary {
    background: #FFF;
    border: 1px solid #E0E0E0;
    box-shadow: 0 0 1px rgba(128, 128, 128, .2);
    margin: 1em 0;
    padding: 10px;
}

.exception-message {
    color: #B0413E;
}

.exception-metadata,
.exception-illustration {
    display: none;
}

.exception-message-wrapper {
    min-height: auto;
}
", "@WebProfiler/Collector/exception.css.twig", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\controllers\\symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Collector\\exception.css.twig");
    }
}
