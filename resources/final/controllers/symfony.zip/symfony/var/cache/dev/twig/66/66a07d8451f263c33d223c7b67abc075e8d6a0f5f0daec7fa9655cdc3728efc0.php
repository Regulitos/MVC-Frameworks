<?php

/* @Framework/Form/datetime_widget.html.php */
class __TwigTemplate_2dd339b61765aaa24eed85303d7eb4d95b07bfa5965a11eee2b8509d986856a9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_40a3b28da0ff3ecfb7701aa35e65a39affda13fbb0dfdb3e4e3701a5dc303e41 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_40a3b28da0ff3ecfb7701aa35e65a39affda13fbb0dfdb3e4e3701a5dc303e41->enter($__internal_40a3b28da0ff3ecfb7701aa35e65a39affda13fbb0dfdb3e4e3701a5dc303e41_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/datetime_widget.html.php"));

        $__internal_be7864a422a0a995b9f98d392d337cdddd0ac120e8d0e2cf32cd2c221362d6dc = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_be7864a422a0a995b9f98d392d337cdddd0ac120e8d0e2cf32cd2c221362d6dc->enter($__internal_be7864a422a0a995b9f98d392d337cdddd0ac120e8d0e2cf32cd2c221362d6dc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/datetime_widget.html.php"));

        // line 1
        echo "<?php if (\$widget == 'single_text'): ?>
    <?php echo \$view['form']->block(\$form, 'form_widget_simple'); ?>
<?php else: ?>
    <div <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
        <?php echo \$view['form']->widget(\$form['date']).' '.\$view['form']->widget(\$form['time']) ?>
    </div>
<?php endif ?>
";
        
        $__internal_40a3b28da0ff3ecfb7701aa35e65a39affda13fbb0dfdb3e4e3701a5dc303e41->leave($__internal_40a3b28da0ff3ecfb7701aa35e65a39affda13fbb0dfdb3e4e3701a5dc303e41_prof);

        
        $__internal_be7864a422a0a995b9f98d392d337cdddd0ac120e8d0e2cf32cd2c221362d6dc->leave($__internal_be7864a422a0a995b9f98d392d337cdddd0ac120e8d0e2cf32cd2c221362d6dc_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/datetime_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (\$widget == 'single_text'): ?>
    <?php echo \$view['form']->block(\$form, 'form_widget_simple'); ?>
<?php else: ?>
    <div <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
        <?php echo \$view['form']->widget(\$form['date']).' '.\$view['form']->widget(\$form['time']) ?>
    </div>
<?php endif ?>
", "@Framework/Form/datetime_widget.html.php", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\controllers\\symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\datetime_widget.html.php");
    }
}
