<?php

/* @Twig/Exception/exception.atom.twig */
class __TwigTemplate_bbdc25bb899392bdd7f87882f32bdb6fa6cd338bfacd58e905cc31fb5e83f5d8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0c43af1874b6eebbe215924dab200c0baa0b604a0a132ed137c417966ecd42f6 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0c43af1874b6eebbe215924dab200c0baa0b604a0a132ed137c417966ecd42f6->enter($__internal_0c43af1874b6eebbe215924dab200c0baa0b604a0a132ed137c417966ecd42f6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.atom.twig"));

        $__internal_39e3c0732966a9d4e839787467efdaa9694d2a70d0b99920870ba2c7161a9979 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_39e3c0732966a9d4e839787467efdaa9694d2a70d0b99920870ba2c7161a9979->enter($__internal_39e3c0732966a9d4e839787467efdaa9694d2a70d0b99920870ba2c7161a9979_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.atom.twig"));

        // line 1
        echo twig_include($this->env, $context, "@Twig/Exception/exception.xml.twig", array("exception" => ($context["exception"] ?? $this->getContext($context, "exception"))));
        echo "
";
        
        $__internal_0c43af1874b6eebbe215924dab200c0baa0b604a0a132ed137c417966ecd42f6->leave($__internal_0c43af1874b6eebbe215924dab200c0baa0b604a0a132ed137c417966ecd42f6_prof);

        
        $__internal_39e3c0732966a9d4e839787467efdaa9694d2a70d0b99920870ba2c7161a9979->leave($__internal_39e3c0732966a9d4e839787467efdaa9694d2a70d0b99920870ba2c7161a9979_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/exception.atom.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ include('@Twig/Exception/exception.xml.twig', { exception: exception }) }}
", "@Twig/Exception/exception.atom.twig", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\controllers\\symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\exception.atom.twig");
    }
}
