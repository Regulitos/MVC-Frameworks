<?php

/* TwigBundle:Exception:error.css.twig */
class __TwigTemplate_976ddc88dc6308d2caf5003750c021392fd3ae543a78794585911c3a52c5f7a2 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f897fbd729e82a5496b66fabe65734270850412539c9bce53f2d3de345a9da3b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f897fbd729e82a5496b66fabe65734270850412539c9bce53f2d3de345a9da3b->enter($__internal_f897fbd729e82a5496b66fabe65734270850412539c9bce53f2d3de345a9da3b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.css.twig"));

        $__internal_3dd6574ec0033af361ac77c62cfb6e437a3edcc4ab63ca5565abb1d9ac56c5dc = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3dd6574ec0033af361ac77c62cfb6e437a3edcc4ab63ca5565abb1d9ac56c5dc->enter($__internal_3dd6574ec0033af361ac77c62cfb6e437a3edcc4ab63ca5565abb1d9ac56c5dc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.css.twig"));

        // line 1
        echo "/*
";
        // line 2
        echo twig_escape_filter($this->env, ($context["status_code"] ?? $this->getContext($context, "status_code")), "css", null, true);
        echo " ";
        echo twig_escape_filter($this->env, ($context["status_text"] ?? $this->getContext($context, "status_text")), "css", null, true);
        echo "

*/
";
        
        $__internal_f897fbd729e82a5496b66fabe65734270850412539c9bce53f2d3de345a9da3b->leave($__internal_f897fbd729e82a5496b66fabe65734270850412539c9bce53f2d3de345a9da3b_prof);

        
        $__internal_3dd6574ec0033af361ac77c62cfb6e437a3edcc4ab63ca5565abb1d9ac56c5dc->leave($__internal_3dd6574ec0033af361ac77c62cfb6e437a3edcc4ab63ca5565abb1d9ac56c5dc_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.css.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  28 => 2,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("/*
{{ status_code }} {{ status_text }}

*/
", "TwigBundle:Exception:error.css.twig", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\controllers\\symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle/Resources/views/Exception/error.css.twig");
    }
}
