<?php

/* @Framework/Form/widget_container_attributes.html.php */
class __TwigTemplate_1b6e41835f4598fb72cb484202e6decba551bbdec1fc800033620f1eac72e899 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_116619c2366c41a9019a98713a6d10131b36a788d971e9c049c45ea0868a9728 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_116619c2366c41a9019a98713a6d10131b36a788d971e9c049c45ea0868a9728->enter($__internal_116619c2366c41a9019a98713a6d10131b36a788d971e9c049c45ea0868a9728_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/widget_container_attributes.html.php"));

        $__internal_e81571ce4107914291a3c70d9841e997685a36e116124d3671573ebba518c83b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e81571ce4107914291a3c70d9841e997685a36e116124d3671573ebba518c83b->enter($__internal_e81571ce4107914291a3c70d9841e997685a36e116124d3671573ebba518c83b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/widget_container_attributes.html.php"));

        // line 1
        echo "<?php if (!empty(\$id)): ?>id=\"<?php echo \$view->escape(\$id) ?>\"<?php endif ?>
<?php echo \$attr ? ' '.\$view['form']->block(\$form, 'attributes') : '' ?>
";
        
        $__internal_116619c2366c41a9019a98713a6d10131b36a788d971e9c049c45ea0868a9728->leave($__internal_116619c2366c41a9019a98713a6d10131b36a788d971e9c049c45ea0868a9728_prof);

        
        $__internal_e81571ce4107914291a3c70d9841e997685a36e116124d3671573ebba518c83b->leave($__internal_e81571ce4107914291a3c70d9841e997685a36e116124d3671573ebba518c83b_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/widget_container_attributes.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (!empty(\$id)): ?>id=\"<?php echo \$view->escape(\$id) ?>\"<?php endif ?>
<?php echo \$attr ? ' '.\$view['form']->block(\$form, 'attributes') : '' ?>
", "@Framework/Form/widget_container_attributes.html.php", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\controllers\\symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\widget_container_attributes.html.php");
    }
}
