<?php

/* TwigBundle:Exception:exception.atom.twig */
class __TwigTemplate_8bad279752edf5670e2ecf0b4208dbc1dd1c3e31e9889cff1243f386cedd9af0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_45af64b32f5d3043693b32ef7bf7da35baa120d2c7947ebdc33fabf325c6286f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_45af64b32f5d3043693b32ef7bf7da35baa120d2c7947ebdc33fabf325c6286f->enter($__internal_45af64b32f5d3043693b32ef7bf7da35baa120d2c7947ebdc33fabf325c6286f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.atom.twig"));

        $__internal_ac6f76d6ca2712eeade93d3eb3c441f6944ee710fd4e5f57f94e21a396014472 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ac6f76d6ca2712eeade93d3eb3c441f6944ee710fd4e5f57f94e21a396014472->enter($__internal_ac6f76d6ca2712eeade93d3eb3c441f6944ee710fd4e5f57f94e21a396014472_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.atom.twig"));

        // line 1
        echo twig_include($this->env, $context, "@Twig/Exception/exception.xml.twig", array("exception" => ($context["exception"] ?? $this->getContext($context, "exception"))));
        echo "
";
        
        $__internal_45af64b32f5d3043693b32ef7bf7da35baa120d2c7947ebdc33fabf325c6286f->leave($__internal_45af64b32f5d3043693b32ef7bf7da35baa120d2c7947ebdc33fabf325c6286f_prof);

        
        $__internal_ac6f76d6ca2712eeade93d3eb3c441f6944ee710fd4e5f57f94e21a396014472->leave($__internal_ac6f76d6ca2712eeade93d3eb3c441f6944ee710fd4e5f57f94e21a396014472_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.atom.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ include('@Twig/Exception/exception.xml.twig', { exception: exception }) }}
", "TwigBundle:Exception:exception.atom.twig", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\controllers\\symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle/Resources/views/Exception/exception.atom.twig");
    }
}
