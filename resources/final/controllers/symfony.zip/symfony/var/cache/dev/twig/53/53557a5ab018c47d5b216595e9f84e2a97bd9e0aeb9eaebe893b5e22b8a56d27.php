<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_596134ad84a45d3a703ef1c943d6679f4d623e85895794760a3bbcf0e91e4958 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_cf340729002e5a52cb54836e8c6b3f35c6672098a841417b86b9b4f79ee88562 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_cf340729002e5a52cb54836e8c6b3f35c6672098a841417b86b9b4f79ee88562->enter($__internal_cf340729002e5a52cb54836e8c6b3f35c6672098a841417b86b9b4f79ee88562_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $__internal_193aed3e843b8b103cd539ede4ed8263bf14735cb5749ee2bcce33ead53d0bd9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_193aed3e843b8b103cd539ede4ed8263bf14735cb5749ee2bcce33ead53d0bd9->enter($__internal_193aed3e843b8b103cd539ede4ed8263bf14735cb5749ee2bcce33ead53d0bd9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_cf340729002e5a52cb54836e8c6b3f35c6672098a841417b86b9b4f79ee88562->leave($__internal_cf340729002e5a52cb54836e8c6b3f35c6672098a841417b86b9b4f79ee88562_prof);

        
        $__internal_193aed3e843b8b103cd539ede4ed8263bf14735cb5749ee2bcce33ead53d0bd9->leave($__internal_193aed3e843b8b103cd539ede4ed8263bf14735cb5749ee2bcce33ead53d0bd9_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_e78ef0b0fd28b872579133c20fcdcd9edfc98069d3f8d0feb740f35e0ac93ea6 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e78ef0b0fd28b872579133c20fcdcd9edfc98069d3f8d0feb740f35e0ac93ea6->enter($__internal_e78ef0b0fd28b872579133c20fcdcd9edfc98069d3f8d0feb740f35e0ac93ea6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        $__internal_f6542b3cf9f404e2e6f269bfca63576be64e16b283893958aea4fc9a8332814b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f6542b3cf9f404e2e6f269bfca63576be64e16b283893958aea4fc9a8332814b->enter($__internal_f6542b3cf9f404e2e6f269bfca63576be64e16b283893958aea4fc9a8332814b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_f6542b3cf9f404e2e6f269bfca63576be64e16b283893958aea4fc9a8332814b->leave($__internal_f6542b3cf9f404e2e6f269bfca63576be64e16b283893958aea4fc9a8332814b_prof);

        
        $__internal_e78ef0b0fd28b872579133c20fcdcd9edfc98069d3f8d0feb740f35e0ac93ea6->leave($__internal_e78ef0b0fd28b872579133c20fcdcd9edfc98069d3f8d0feb740f35e0ac93ea6_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_2a64ceb91e4784e82b19540c82057c1a9ae3c39cb5df572eb21703a36d93e8cf = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2a64ceb91e4784e82b19540c82057c1a9ae3c39cb5df572eb21703a36d93e8cf->enter($__internal_2a64ceb91e4784e82b19540c82057c1a9ae3c39cb5df572eb21703a36d93e8cf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_2d1b17a65a84b365724993f1949d26fb7e8f1efa2746f8a2555d3110b904db0b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2d1b17a65a84b365724993f1949d26fb7e8f1efa2746f8a2555d3110b904db0b->enter($__internal_2d1b17a65a84b365724993f1949d26fb7e8f1efa2746f8a2555d3110b904db0b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_2d1b17a65a84b365724993f1949d26fb7e8f1efa2746f8a2555d3110b904db0b->leave($__internal_2d1b17a65a84b365724993f1949d26fb7e8f1efa2746f8a2555d3110b904db0b_prof);

        
        $__internal_2a64ceb91e4784e82b19540c82057c1a9ae3c39cb5df572eb21703a36d93e8cf->leave($__internal_2a64ceb91e4784e82b19540c82057c1a9ae3c39cb5df572eb21703a36d93e8cf_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_09f4ba09594c5787bc91eb2fc6a026e44f10461d819a91909a89aa729efea306 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_09f4ba09594c5787bc91eb2fc6a026e44f10461d819a91909a89aa729efea306->enter($__internal_09f4ba09594c5787bc91eb2fc6a026e44f10461d819a91909a89aa729efea306_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_e1553a787f16c425a6aca32e2c9241c11beb684554e79c97abf07cd0982a5e77 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e1553a787f16c425a6aca32e2c9241c11beb684554e79c97abf07cd0982a5e77->enter($__internal_e1553a787f16c425a6aca32e2c9241c11beb684554e79c97abf07cd0982a5e77_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_e1553a787f16c425a6aca32e2c9241c11beb684554e79c97abf07cd0982a5e77->leave($__internal_e1553a787f16c425a6aca32e2c9241c11beb684554e79c97abf07cd0982a5e77_prof);

        
        $__internal_09f4ba09594c5787bc91eb2fc6a026e44f10461d819a91909a89aa729efea306->leave($__internal_09f4ba09594c5787bc91eb2fc6a026e44f10461d819a91909a89aa729efea306_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  94 => 13,  85 => 12,  71 => 7,  68 => 6,  59 => 5,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
", "@WebProfiler/Collector/router.html.twig", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\controllers\\symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Collector\\router.html.twig");
    }
}
