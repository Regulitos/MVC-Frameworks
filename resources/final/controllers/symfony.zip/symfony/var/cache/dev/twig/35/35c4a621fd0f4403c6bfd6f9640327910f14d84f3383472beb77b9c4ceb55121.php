<?php

/* @Framework/Form/button_attributes.html.php */
class __TwigTemplate_4c5713aaef9d3dbfe156eaec1bb89552844c1db72ad95c7eb1f850e31316f8ce extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6f77a2060427add8a4c23123667bc1d5a65f8619e1b8e22e9f3a651c18949895 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6f77a2060427add8a4c23123667bc1d5a65f8619e1b8e22e9f3a651c18949895->enter($__internal_6f77a2060427add8a4c23123667bc1d5a65f8619e1b8e22e9f3a651c18949895_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_attributes.html.php"));

        $__internal_e0be2db03484bf36b2abd91e8c8e1233db53e1cd083251d9e12e81542df5ee7b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e0be2db03484bf36b2abd91e8c8e1233db53e1cd083251d9e12e81542df5ee7b->enter($__internal_e0be2db03484bf36b2abd91e8c8e1233db53e1cd083251d9e12e81542df5ee7b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_attributes.html.php"));

        // line 1
        echo "id=\"<?php echo \$view->escape(\$id) ?>\" name=\"<?php echo \$view->escape(\$full_name) ?>\"<?php if (\$disabled): ?> disabled=\"disabled\"<?php endif ?>
<?php echo \$attr ? ' '.\$view['form']->block(\$form, 'attributes') : '' ?>
";
        
        $__internal_6f77a2060427add8a4c23123667bc1d5a65f8619e1b8e22e9f3a651c18949895->leave($__internal_6f77a2060427add8a4c23123667bc1d5a65f8619e1b8e22e9f3a651c18949895_prof);

        
        $__internal_e0be2db03484bf36b2abd91e8c8e1233db53e1cd083251d9e12e81542df5ee7b->leave($__internal_e0be2db03484bf36b2abd91e8c8e1233db53e1cd083251d9e12e81542df5ee7b_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_attributes.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("id=\"<?php echo \$view->escape(\$id) ?>\" name=\"<?php echo \$view->escape(\$full_name) ?>\"<?php if (\$disabled): ?> disabled=\"disabled\"<?php endif ?>
<?php echo \$attr ? ' '.\$view['form']->block(\$form, 'attributes') : '' ?>
", "@Framework/Form/button_attributes.html.php", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\controllers\\symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\button_attributes.html.php");
    }
}
