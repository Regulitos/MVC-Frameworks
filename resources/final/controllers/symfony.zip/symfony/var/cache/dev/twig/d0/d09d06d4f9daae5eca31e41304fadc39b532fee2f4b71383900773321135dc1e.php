<?php

/* @Framework/Form/form_rows.html.php */
class __TwigTemplate_cc6c901cdef63566eb911ff579d162bdf1c429ff439dacd25386ab6f285f8d8f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ebdc3e5fe70c4e7650d08b82783cdefc8fafdfe647d7e673e094191683ef2e4e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ebdc3e5fe70c4e7650d08b82783cdefc8fafdfe647d7e673e094191683ef2e4e->enter($__internal_ebdc3e5fe70c4e7650d08b82783cdefc8fafdfe647d7e673e094191683ef2e4e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_rows.html.php"));

        $__internal_d8aa1f25c1fe9fddc6cd0a376ac8eaf1f8992a74e63b0f368ee72f6462bd8985 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d8aa1f25c1fe9fddc6cd0a376ac8eaf1f8992a74e63b0f368ee72f6462bd8985->enter($__internal_d8aa1f25c1fe9fddc6cd0a376ac8eaf1f8992a74e63b0f368ee72f6462bd8985_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_rows.html.php"));

        // line 1
        echo "<?php foreach (\$form as \$child) : ?>
    <?php echo \$view['form']->row(\$child) ?>
<?php endforeach; ?>
";
        
        $__internal_ebdc3e5fe70c4e7650d08b82783cdefc8fafdfe647d7e673e094191683ef2e4e->leave($__internal_ebdc3e5fe70c4e7650d08b82783cdefc8fafdfe647d7e673e094191683ef2e4e_prof);

        
        $__internal_d8aa1f25c1fe9fddc6cd0a376ac8eaf1f8992a74e63b0f368ee72f6462bd8985->leave($__internal_d8aa1f25c1fe9fddc6cd0a376ac8eaf1f8992a74e63b0f368ee72f6462bd8985_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_rows.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php foreach (\$form as \$child) : ?>
    <?php echo \$view['form']->row(\$child) ?>
<?php endforeach; ?>
", "@Framework/Form/form_rows.html.php", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\controllers\\symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\form_rows.html.php");
    }
}
