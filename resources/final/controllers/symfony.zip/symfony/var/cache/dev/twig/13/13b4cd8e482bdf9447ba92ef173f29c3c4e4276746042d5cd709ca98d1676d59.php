<?php

/* @Framework/Form/collection_widget.html.php */
class __TwigTemplate_255253f2c3060780688db7ce61005f093c0a2fc6e262175bc6b4c196785cb70d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c2cf6b53d73c7a5af121ad1d3693e205279d5451da1a0168bf64de6a241b0d64 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c2cf6b53d73c7a5af121ad1d3693e205279d5451da1a0168bf64de6a241b0d64->enter($__internal_c2cf6b53d73c7a5af121ad1d3693e205279d5451da1a0168bf64de6a241b0d64_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/collection_widget.html.php"));

        $__internal_91e5c86ec7b24c1c645c72161be3ec72cebb15de0aeadc47b19ccc71cb3128e0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_91e5c86ec7b24c1c645c72161be3ec72cebb15de0aeadc47b19ccc71cb3128e0->enter($__internal_91e5c86ec7b24c1c645c72161be3ec72cebb15de0aeadc47b19ccc71cb3128e0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/collection_widget.html.php"));

        // line 1
        echo "<?php if (isset(\$prototype)): ?>
    <?php \$attr['data-prototype'] = \$view->escape(\$view['form']->row(\$prototype)) ?>
<?php endif ?>
<?php echo \$view['form']->widget(\$form, array('attr' => \$attr)) ?>
";
        
        $__internal_c2cf6b53d73c7a5af121ad1d3693e205279d5451da1a0168bf64de6a241b0d64->leave($__internal_c2cf6b53d73c7a5af121ad1d3693e205279d5451da1a0168bf64de6a241b0d64_prof);

        
        $__internal_91e5c86ec7b24c1c645c72161be3ec72cebb15de0aeadc47b19ccc71cb3128e0->leave($__internal_91e5c86ec7b24c1c645c72161be3ec72cebb15de0aeadc47b19ccc71cb3128e0_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/collection_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (isset(\$prototype)): ?>
    <?php \$attr['data-prototype'] = \$view->escape(\$view['form']->row(\$prototype)) ?>
<?php endif ?>
<?php echo \$view['form']->widget(\$form, array('attr' => \$attr)) ?>
", "@Framework/Form/collection_widget.html.php", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\controllers\\symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\collection_widget.html.php");
    }
}
