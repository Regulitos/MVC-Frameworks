<?php

/* @Twig/Exception/exception.css.twig */
class __TwigTemplate_8c787de82f553afc7f06ec5bf16f923d919d2bb78f51f178c51dd2668ed08e18 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ad26cb6099deb707278d204df62c45635108218b73c69dfd5667c7fc958f2df9 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ad26cb6099deb707278d204df62c45635108218b73c69dfd5667c7fc958f2df9->enter($__internal_ad26cb6099deb707278d204df62c45635108218b73c69dfd5667c7fc958f2df9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.css.twig"));

        $__internal_d6ff04078f1054e594058b727675d5397950b0609f7756a6629e7dcd68ca6bf5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d6ff04078f1054e594058b727675d5397950b0609f7756a6629e7dcd68ca6bf5->enter($__internal_d6ff04078f1054e594058b727675d5397950b0609f7756a6629e7dcd68ca6bf5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.css.twig"));

        // line 1
        echo "/*
";
        // line 2
        echo twig_include($this->env, $context, "@Twig/Exception/exception.txt.twig", array("exception" => ($context["exception"] ?? $this->getContext($context, "exception"))));
        echo "
*/
";
        
        $__internal_ad26cb6099deb707278d204df62c45635108218b73c69dfd5667c7fc958f2df9->leave($__internal_ad26cb6099deb707278d204df62c45635108218b73c69dfd5667c7fc958f2df9_prof);

        
        $__internal_d6ff04078f1054e594058b727675d5397950b0609f7756a6629e7dcd68ca6bf5->leave($__internal_d6ff04078f1054e594058b727675d5397950b0609f7756a6629e7dcd68ca6bf5_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/exception.css.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  28 => 2,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("/*
{{ include('@Twig/Exception/exception.txt.twig', { exception: exception }) }}
*/
", "@Twig/Exception/exception.css.twig", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\controllers\\symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\exception.css.twig");
    }
}
