<?php

/* TwigBundle:Exception:error.atom.twig */
class __TwigTemplate_bce416d498d5b0de59abcc4f0609023822fede12bd24b93c4bdcac9d526138ad extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5d94d5482af4e6bca755ddb66f2462c60dc3dabd37fbba2bd35b62515c0cbb5c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5d94d5482af4e6bca755ddb66f2462c60dc3dabd37fbba2bd35b62515c0cbb5c->enter($__internal_5d94d5482af4e6bca755ddb66f2462c60dc3dabd37fbba2bd35b62515c0cbb5c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.atom.twig"));

        $__internal_6615b81fc687007259be4abea2499fd3833ad05611d533ddf10a5beed408b3af = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6615b81fc687007259be4abea2499fd3833ad05611d533ddf10a5beed408b3af->enter($__internal_6615b81fc687007259be4abea2499fd3833ad05611d533ddf10a5beed408b3af_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.atom.twig"));

        // line 1
        echo twig_include($this->env, $context, "@Twig/Exception/error.xml.twig");
        echo "
";
        
        $__internal_5d94d5482af4e6bca755ddb66f2462c60dc3dabd37fbba2bd35b62515c0cbb5c->leave($__internal_5d94d5482af4e6bca755ddb66f2462c60dc3dabd37fbba2bd35b62515c0cbb5c_prof);

        
        $__internal_6615b81fc687007259be4abea2499fd3833ad05611d533ddf10a5beed408b3af->leave($__internal_6615b81fc687007259be4abea2499fd3833ad05611d533ddf10a5beed408b3af_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.atom.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ include('@Twig/Exception/error.xml.twig') }}
", "TwigBundle:Exception:error.atom.twig", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\controllers\\symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle/Resources/views/Exception/error.atom.twig");
    }
}
