<?php

/* TwigBundle:Exception:error.xml.twig */
class __TwigTemplate_28a039a80e0ef40c60fda3b17e748f036240e77c7f4aa18a9845a028b51c9a29 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f81e5b0162655c332d69a0930ebd6944a1b296186d6913bfccafe9cf3dc640be = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f81e5b0162655c332d69a0930ebd6944a1b296186d6913bfccafe9cf3dc640be->enter($__internal_f81e5b0162655c332d69a0930ebd6944a1b296186d6913bfccafe9cf3dc640be_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.xml.twig"));

        $__internal_09f19ecd027c876a96b8b37158dc313504deb7f094a9135048ef6502b0998411 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_09f19ecd027c876a96b8b37158dc313504deb7f094a9135048ef6502b0998411->enter($__internal_09f19ecd027c876a96b8b37158dc313504deb7f094a9135048ef6502b0998411_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.xml.twig"));

        // line 1
        echo "<?xml version=\"1.0\" encoding=\"";
        echo twig_escape_filter($this->env, $this->env->getCharset(), "html", null, true);
        echo "\" ?>

<error code=\"";
        // line 3
        echo twig_escape_filter($this->env, ($context["status_code"] ?? $this->getContext($context, "status_code")), "html", null, true);
        echo "\" message=\"";
        echo twig_escape_filter($this->env, ($context["status_text"] ?? $this->getContext($context, "status_text")), "html", null, true);
        echo "\" />
";
        
        $__internal_f81e5b0162655c332d69a0930ebd6944a1b296186d6913bfccafe9cf3dc640be->leave($__internal_f81e5b0162655c332d69a0930ebd6944a1b296186d6913bfccafe9cf3dc640be_prof);

        
        $__internal_09f19ecd027c876a96b8b37158dc313504deb7f094a9135048ef6502b0998411->leave($__internal_09f19ecd027c876a96b8b37158dc313504deb7f094a9135048ef6502b0998411_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.xml.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  31 => 3,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?xml version=\"1.0\" encoding=\"{{ _charset }}\" ?>

<error code=\"{{ status_code }}\" message=\"{{ status_text }}\" />
", "TwigBundle:Exception:error.xml.twig", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\controllers\\symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle/Resources/views/Exception/error.xml.twig");
    }
}
