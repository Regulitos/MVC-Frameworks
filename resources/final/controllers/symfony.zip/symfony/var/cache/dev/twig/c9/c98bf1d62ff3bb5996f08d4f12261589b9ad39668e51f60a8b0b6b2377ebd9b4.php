<?php

/* @Twig/Exception/error.rdf.twig */
class __TwigTemplate_ebf8aedd5c44f694607413aed4441f8014f0fb155687e68b832612ce09917b3e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_481f6bf7ee28b2da8e8d22dd29c2a8e1593731973663a70f16e170a063104d06 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_481f6bf7ee28b2da8e8d22dd29c2a8e1593731973663a70f16e170a063104d06->enter($__internal_481f6bf7ee28b2da8e8d22dd29c2a8e1593731973663a70f16e170a063104d06_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.rdf.twig"));

        $__internal_65630716fa188a5a79381a749c18f92e7879585044e4868d95e4911152c1ad1c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_65630716fa188a5a79381a749c18f92e7879585044e4868d95e4911152c1ad1c->enter($__internal_65630716fa188a5a79381a749c18f92e7879585044e4868d95e4911152c1ad1c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.rdf.twig"));

        // line 1
        echo twig_include($this->env, $context, "@Twig/Exception/error.xml.twig");
        echo "
";
        
        $__internal_481f6bf7ee28b2da8e8d22dd29c2a8e1593731973663a70f16e170a063104d06->leave($__internal_481f6bf7ee28b2da8e8d22dd29c2a8e1593731973663a70f16e170a063104d06_prof);

        
        $__internal_65630716fa188a5a79381a749c18f92e7879585044e4868d95e4911152c1ad1c->leave($__internal_65630716fa188a5a79381a749c18f92e7879585044e4868d95e4911152c1ad1c_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/error.rdf.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ include('@Twig/Exception/error.xml.twig') }}
", "@Twig/Exception/error.rdf.twig", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\controllers\\symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\error.rdf.twig");
    }
}
