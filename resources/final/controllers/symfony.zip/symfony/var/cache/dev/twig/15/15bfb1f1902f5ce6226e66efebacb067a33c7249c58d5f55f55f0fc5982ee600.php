<?php

/* @WebProfiler/Profiler/ajax_layout.html.twig */
class __TwigTemplate_e654a57c1c1190cdb6754f7fe92c6fa0261a0159ec19cdd8b92747da0cd431a8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5d26f76588d7735918af5150a1d47adffeef82ad9c628918161234c4497b950c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5d26f76588d7735918af5150a1d47adffeef82ad9c628918161234c4497b950c->enter($__internal_5d26f76588d7735918af5150a1d47adffeef82ad9c628918161234c4497b950c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/ajax_layout.html.twig"));

        $__internal_9a894338d8b14daed748d23c8e40113612825fcb6e2d8b40bad548d4f92d17fe = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9a894338d8b14daed748d23c8e40113612825fcb6e2d8b40bad548d4f92d17fe->enter($__internal_9a894338d8b14daed748d23c8e40113612825fcb6e2d8b40bad548d4f92d17fe_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/ajax_layout.html.twig"));

        // line 1
        $this->displayBlock('panel', $context, $blocks);
        
        $__internal_5d26f76588d7735918af5150a1d47adffeef82ad9c628918161234c4497b950c->leave($__internal_5d26f76588d7735918af5150a1d47adffeef82ad9c628918161234c4497b950c_prof);

        
        $__internal_9a894338d8b14daed748d23c8e40113612825fcb6e2d8b40bad548d4f92d17fe->leave($__internal_9a894338d8b14daed748d23c8e40113612825fcb6e2d8b40bad548d4f92d17fe_prof);

    }

    public function block_panel($context, array $blocks = array())
    {
        $__internal_d040737b2f33724079a7493c56712ab8dc583273e30d0ffa37228d70c69a4aeb = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d040737b2f33724079a7493c56712ab8dc583273e30d0ffa37228d70c69a4aeb->enter($__internal_d040737b2f33724079a7493c56712ab8dc583273e30d0ffa37228d70c69a4aeb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_f49cbfc008d98e4a0f49ff164a9835dbfb80d91c34feab899d9925b580f484be = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f49cbfc008d98e4a0f49ff164a9835dbfb80d91c34feab899d9925b580f484be->enter($__internal_f49cbfc008d98e4a0f49ff164a9835dbfb80d91c34feab899d9925b580f484be_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        echo "";
        
        $__internal_f49cbfc008d98e4a0f49ff164a9835dbfb80d91c34feab899d9925b580f484be->leave($__internal_f49cbfc008d98e4a0f49ff164a9835dbfb80d91c34feab899d9925b580f484be_prof);

        
        $__internal_d040737b2f33724079a7493c56712ab8dc583273e30d0ffa37228d70c69a4aeb->leave($__internal_d040737b2f33724079a7493c56712ab8dc583273e30d0ffa37228d70c69a4aeb_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Profiler/ajax_layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  26 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% block panel '' %}
", "@WebProfiler/Profiler/ajax_layout.html.twig", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\controllers\\symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Profiler\\ajax_layout.html.twig");
    }
}
