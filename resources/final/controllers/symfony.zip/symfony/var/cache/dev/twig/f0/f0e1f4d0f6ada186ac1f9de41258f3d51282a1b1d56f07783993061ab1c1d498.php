<?php

/* WebProfilerBundle:Collector:router.html.twig */
class __TwigTemplate_afa9d77af99b48c2619f3c3857d2b04f85db861a56de9ca9c3f17809fac7a49b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "WebProfilerBundle:Collector:router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_bcad0989fb11e2e727f35c8ec3fa1dd4d4f8244d8e0324b48890ce227d863d86 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_bcad0989fb11e2e727f35c8ec3fa1dd4d4f8244d8e0324b48890ce227d863d86->enter($__internal_bcad0989fb11e2e727f35c8ec3fa1dd4d4f8244d8e0324b48890ce227d863d86_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Collector:router.html.twig"));

        $__internal_f80776d36fdb8b5c3c9e2959e93001f998523b0aa1caf73a927c7a913128fba2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f80776d36fdb8b5c3c9e2959e93001f998523b0aa1caf73a927c7a913128fba2->enter($__internal_f80776d36fdb8b5c3c9e2959e93001f998523b0aa1caf73a927c7a913128fba2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Collector:router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_bcad0989fb11e2e727f35c8ec3fa1dd4d4f8244d8e0324b48890ce227d863d86->leave($__internal_bcad0989fb11e2e727f35c8ec3fa1dd4d4f8244d8e0324b48890ce227d863d86_prof);

        
        $__internal_f80776d36fdb8b5c3c9e2959e93001f998523b0aa1caf73a927c7a913128fba2->leave($__internal_f80776d36fdb8b5c3c9e2959e93001f998523b0aa1caf73a927c7a913128fba2_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_93183907fcff67c3416de240123a486a251aecfac415a672d42a1d7e862c4f4d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_93183907fcff67c3416de240123a486a251aecfac415a672d42a1d7e862c4f4d->enter($__internal_93183907fcff67c3416de240123a486a251aecfac415a672d42a1d7e862c4f4d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        $__internal_f9c56c08fa2d150153624967d5851c38fc62492a9886c0cdfcf043256cbbf636 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f9c56c08fa2d150153624967d5851c38fc62492a9886c0cdfcf043256cbbf636->enter($__internal_f9c56c08fa2d150153624967d5851c38fc62492a9886c0cdfcf043256cbbf636_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_f9c56c08fa2d150153624967d5851c38fc62492a9886c0cdfcf043256cbbf636->leave($__internal_f9c56c08fa2d150153624967d5851c38fc62492a9886c0cdfcf043256cbbf636_prof);

        
        $__internal_93183907fcff67c3416de240123a486a251aecfac415a672d42a1d7e862c4f4d->leave($__internal_93183907fcff67c3416de240123a486a251aecfac415a672d42a1d7e862c4f4d_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_70c27f4f583e82a95889da7ab7dc04f4ab5131ecbb3177488635f814e78a87bc = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_70c27f4f583e82a95889da7ab7dc04f4ab5131ecbb3177488635f814e78a87bc->enter($__internal_70c27f4f583e82a95889da7ab7dc04f4ab5131ecbb3177488635f814e78a87bc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_5e9cbd2a9e5bd94fbd2c7be4af14aa74018bf2cab17fc7007dd68c4148c37615 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5e9cbd2a9e5bd94fbd2c7be4af14aa74018bf2cab17fc7007dd68c4148c37615->enter($__internal_5e9cbd2a9e5bd94fbd2c7be4af14aa74018bf2cab17fc7007dd68c4148c37615_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_5e9cbd2a9e5bd94fbd2c7be4af14aa74018bf2cab17fc7007dd68c4148c37615->leave($__internal_5e9cbd2a9e5bd94fbd2c7be4af14aa74018bf2cab17fc7007dd68c4148c37615_prof);

        
        $__internal_70c27f4f583e82a95889da7ab7dc04f4ab5131ecbb3177488635f814e78a87bc->leave($__internal_70c27f4f583e82a95889da7ab7dc04f4ab5131ecbb3177488635f814e78a87bc_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_65551c544fdbf010686fd0f0af55b73cf8454c63720b5d05f17bced4c2beb1b7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_65551c544fdbf010686fd0f0af55b73cf8454c63720b5d05f17bced4c2beb1b7->enter($__internal_65551c544fdbf010686fd0f0af55b73cf8454c63720b5d05f17bced4c2beb1b7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_4a3b1ef3a2d3a033cbab34a7241d0f1f0a9ce94a11fc81691785dd58b57c9e2a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4a3b1ef3a2d3a033cbab34a7241d0f1f0a9ce94a11fc81691785dd58b57c9e2a->enter($__internal_4a3b1ef3a2d3a033cbab34a7241d0f1f0a9ce94a11fc81691785dd58b57c9e2a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_4a3b1ef3a2d3a033cbab34a7241d0f1f0a9ce94a11fc81691785dd58b57c9e2a->leave($__internal_4a3b1ef3a2d3a033cbab34a7241d0f1f0a9ce94a11fc81691785dd58b57c9e2a_prof);

        
        $__internal_65551c544fdbf010686fd0f0af55b73cf8454c63720b5d05f17bced4c2beb1b7->leave($__internal_65551c544fdbf010686fd0f0af55b73cf8454c63720b5d05f17bced4c2beb1b7_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Collector:router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  94 => 13,  85 => 12,  71 => 7,  68 => 6,  59 => 5,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
", "WebProfilerBundle:Collector:router.html.twig", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\controllers\\symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle/Resources/views/Collector/router.html.twig");
    }
}
