<?php

/* @Framework/Form/email_widget.html.php */
class __TwigTemplate_2f3d959d9d3903a747a22cbd389c8b17ad767e5dc1fd577fc679de2d401a013c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9e8ae2ff500c96b862fca44300e4354d35cf77d217a07010f9d074cba9ee280f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9e8ae2ff500c96b862fca44300e4354d35cf77d217a07010f9d074cba9ee280f->enter($__internal_9e8ae2ff500c96b862fca44300e4354d35cf77d217a07010f9d074cba9ee280f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/email_widget.html.php"));

        $__internal_6195239cd8feea4e0df573e589ee49b79500871130f0e86cd4815c89621120b8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6195239cd8feea4e0df573e589ee49b79500871130f0e86cd4815c89621120b8->enter($__internal_6195239cd8feea4e0df573e589ee49b79500871130f0e86cd4815c89621120b8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/email_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'email')) ?>
";
        
        $__internal_9e8ae2ff500c96b862fca44300e4354d35cf77d217a07010f9d074cba9ee280f->leave($__internal_9e8ae2ff500c96b862fca44300e4354d35cf77d217a07010f9d074cba9ee280f_prof);

        
        $__internal_6195239cd8feea4e0df573e589ee49b79500871130f0e86cd4815c89621120b8->leave($__internal_6195239cd8feea4e0df573e589ee49b79500871130f0e86cd4815c89621120b8_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/email_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'email')) ?>
", "@Framework/Form/email_widget.html.php", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\controllers\\symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\email_widget.html.php");
    }
}
