<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Clients extends CI_Controller {

	public function index()
	{
		echo 'New controller index method';
	}

	public function details($id)
	{

		echo 'Id: ' . $id;

	}
}
