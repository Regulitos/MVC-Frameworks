<?php

namespace app\controllers;

use Yii;
use yii\filters\AccessControl;
use yii\web\Controller;
use yii\filters\VerbFilter;

class ClientsController extends Controller
{
    public function actionIndex()
    {
        return "New controller method index";
    }

    public function actionDetails( $id )
    {
        return "Id: " . $id;
    }
}
