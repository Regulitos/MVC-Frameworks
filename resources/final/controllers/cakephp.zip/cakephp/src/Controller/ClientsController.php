<?php
namespace App\Controller;

use App\Controller\AppController;

class ClientsController extends AppController
{
    public function index()
    {
        $this->response->body('New controller method index');
        return $this->response;
    }

    public function details( $id )
    {
        $this->response->body('Id: ' . $id);
        return $this->response;
    }
}