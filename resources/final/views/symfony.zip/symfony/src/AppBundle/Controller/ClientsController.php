<?php

namespace AppBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Component\HttpFoundation\Response;


class ClientsController extends Controller
{
    var $clients = [ 
                    [ 'id' => 0 , 'name' => 'Emmett', 'last_name' => 'Brown', 'email' => 'emmett@domain.com' ] ,
                    [ 'id' => 1 , 'name' => 'Jennifer', 'last_name' => 'Parker', 'email' => 'jennifer@domain.com' ] ,
                ];
    /**
     * @Route("/clients", name="client_index")
     */
    public function clientIndex()
    {
        //return new Response('New Controller method index');
        return $this->render('clients/index.html.twig', [ 'clients' => $this->clients ]);
    }

    /**
     * @Route("/clients/{id}", name="client_details")
     */
    public function clientDetails($id)
    {
        //return new Response('Id: ' . $id);
        return $this->render('clients/details.html.twig');
    }
}
