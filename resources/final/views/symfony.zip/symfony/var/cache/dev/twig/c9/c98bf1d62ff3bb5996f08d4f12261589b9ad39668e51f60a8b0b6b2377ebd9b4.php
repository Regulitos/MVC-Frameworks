<?php

/* @Twig/Exception/error.rdf.twig */
class __TwigTemplate_ebf8aedd5c44f694607413aed4441f8014f0fb155687e68b832612ce09917b3e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2ff19264363f9d91119f42b9ef37891f3de8033e5d440f7fb66440c7a116b26a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2ff19264363f9d91119f42b9ef37891f3de8033e5d440f7fb66440c7a116b26a->enter($__internal_2ff19264363f9d91119f42b9ef37891f3de8033e5d440f7fb66440c7a116b26a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.rdf.twig"));

        $__internal_0dd399eea18b2ecc70561f1293e7daa225f6db65f3a30b87f4b6fb58a32c3ad1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0dd399eea18b2ecc70561f1293e7daa225f6db65f3a30b87f4b6fb58a32c3ad1->enter($__internal_0dd399eea18b2ecc70561f1293e7daa225f6db65f3a30b87f4b6fb58a32c3ad1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.rdf.twig"));

        // line 1
        echo twig_include($this->env, $context, "@Twig/Exception/error.xml.twig");
        echo "
";
        
        $__internal_2ff19264363f9d91119f42b9ef37891f3de8033e5d440f7fb66440c7a116b26a->leave($__internal_2ff19264363f9d91119f42b9ef37891f3de8033e5d440f7fb66440c7a116b26a_prof);

        
        $__internal_0dd399eea18b2ecc70561f1293e7daa225f6db65f3a30b87f4b6fb58a32c3ad1->leave($__internal_0dd399eea18b2ecc70561f1293e7daa225f6db65f3a30b87f4b6fb58a32c3ad1_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/error.rdf.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ include('@Twig/Exception/error.xml.twig') }}
", "@Twig/Exception/error.rdf.twig", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\views\\symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\error.rdf.twig");
    }
}
