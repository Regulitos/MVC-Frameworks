<?php

/* @Framework/Form/repeated_row.html.php */
class __TwigTemplate_3d206093c01bde614dd5f7f2051942fddf01f2a533f1e9edcb39b5be2ec6f34e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_562f8e57741c147d40b104efe61702c63886c936d3c3afbbdd1ff68a0c42084a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_562f8e57741c147d40b104efe61702c63886c936d3c3afbbdd1ff68a0c42084a->enter($__internal_562f8e57741c147d40b104efe61702c63886c936d3c3afbbdd1ff68a0c42084a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/repeated_row.html.php"));

        $__internal_558c7caced756870ca1aa359866b625e9dcd0cd33f7ff839ba3ad3d27e8e0254 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_558c7caced756870ca1aa359866b625e9dcd0cd33f7ff839ba3ad3d27e8e0254->enter($__internal_558c7caced756870ca1aa359866b625e9dcd0cd33f7ff839ba3ad3d27e8e0254_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/repeated_row.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_rows') ?>
";
        
        $__internal_562f8e57741c147d40b104efe61702c63886c936d3c3afbbdd1ff68a0c42084a->leave($__internal_562f8e57741c147d40b104efe61702c63886c936d3c3afbbdd1ff68a0c42084a_prof);

        
        $__internal_558c7caced756870ca1aa359866b625e9dcd0cd33f7ff839ba3ad3d27e8e0254->leave($__internal_558c7caced756870ca1aa359866b625e9dcd0cd33f7ff839ba3ad3d27e8e0254_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/repeated_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_rows') ?>
", "@Framework/Form/repeated_row.html.php", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\views\\symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\repeated_row.html.php");
    }
}
