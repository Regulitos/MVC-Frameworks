<?php

/* ::base.html.twig */
class __TwigTemplate_aaa161c310dcecf2b0607299d5353c510065f9384a93e27c9013c98e455d9322 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2cce2e1cf4c839dcbfd555775102debe2418b13f00236108874bbc234abade5f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2cce2e1cf4c839dcbfd555775102debe2418b13f00236108874bbc234abade5f->enter($__internal_2cce2e1cf4c839dcbfd555775102debe2418b13f00236108874bbc234abade5f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::base.html.twig"));

        $__internal_1b9e2e97451157e57b568a5d194dd29a196aaa1eef352a4da20829521caf1c6b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1b9e2e97451157e57b568a5d194dd29a196aaa1eef352a4da20829521caf1c6b->enter($__internal_1b9e2e97451157e57b568a5d194dd29a196aaa1eef352a4da20829521caf1c6b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>";
        // line 5
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        ";
        // line 6
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 7
        echo "        <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />
    </head>
    <body>
        ";
        // line 10
        $this->displayBlock('body', $context, $blocks);
        // line 11
        echo "        ";
        $this->displayBlock('javascripts', $context, $blocks);
        // line 12
        echo "    </body>
</html>
";
        
        $__internal_2cce2e1cf4c839dcbfd555775102debe2418b13f00236108874bbc234abade5f->leave($__internal_2cce2e1cf4c839dcbfd555775102debe2418b13f00236108874bbc234abade5f_prof);

        
        $__internal_1b9e2e97451157e57b568a5d194dd29a196aaa1eef352a4da20829521caf1c6b->leave($__internal_1b9e2e97451157e57b568a5d194dd29a196aaa1eef352a4da20829521caf1c6b_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_b10f7e9b71643deada03bf2f18c05c959a7c7a2358db7c444bac50f45c5690f1 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b10f7e9b71643deada03bf2f18c05c959a7c7a2358db7c444bac50f45c5690f1->enter($__internal_b10f7e9b71643deada03bf2f18c05c959a7c7a2358db7c444bac50f45c5690f1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_452105eccb07e960b8d92c8b2482cdd022e89f5b27ef0039cc158274855cb6e8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_452105eccb07e960b8d92c8b2482cdd022e89f5b27ef0039cc158274855cb6e8->enter($__internal_452105eccb07e960b8d92c8b2482cdd022e89f5b27ef0039cc158274855cb6e8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Welcome!";
        
        $__internal_452105eccb07e960b8d92c8b2482cdd022e89f5b27ef0039cc158274855cb6e8->leave($__internal_452105eccb07e960b8d92c8b2482cdd022e89f5b27ef0039cc158274855cb6e8_prof);

        
        $__internal_b10f7e9b71643deada03bf2f18c05c959a7c7a2358db7c444bac50f45c5690f1->leave($__internal_b10f7e9b71643deada03bf2f18c05c959a7c7a2358db7c444bac50f45c5690f1_prof);

    }

    // line 6
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_9c0fc619d07d298f56c017dc0823d701b4df280ad29461cef5ac6575cf5e4b43 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9c0fc619d07d298f56c017dc0823d701b4df280ad29461cef5ac6575cf5e4b43->enter($__internal_9c0fc619d07d298f56c017dc0823d701b4df280ad29461cef5ac6575cf5e4b43_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_3beda268df91c7077fed1a394a5830cb69b55d8daa9b76822105c8802ac37967 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3beda268df91c7077fed1a394a5830cb69b55d8daa9b76822105c8802ac37967->enter($__internal_3beda268df91c7077fed1a394a5830cb69b55d8daa9b76822105c8802ac37967_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_3beda268df91c7077fed1a394a5830cb69b55d8daa9b76822105c8802ac37967->leave($__internal_3beda268df91c7077fed1a394a5830cb69b55d8daa9b76822105c8802ac37967_prof);

        
        $__internal_9c0fc619d07d298f56c017dc0823d701b4df280ad29461cef5ac6575cf5e4b43->leave($__internal_9c0fc619d07d298f56c017dc0823d701b4df280ad29461cef5ac6575cf5e4b43_prof);

    }

    // line 10
    public function block_body($context, array $blocks = array())
    {
        $__internal_55b76a28a60f6b3148e9eceb7d2bbc46ed7fac8d1273b5ecd2edfeb04c5b4401 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_55b76a28a60f6b3148e9eceb7d2bbc46ed7fac8d1273b5ecd2edfeb04c5b4401->enter($__internal_55b76a28a60f6b3148e9eceb7d2bbc46ed7fac8d1273b5ecd2edfeb04c5b4401_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_be6276fb5dbb0ee04c29c239c449d569bf29743d99438a0983c49f3de018c241 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_be6276fb5dbb0ee04c29c239c449d569bf29743d99438a0983c49f3de018c241->enter($__internal_be6276fb5dbb0ee04c29c239c449d569bf29743d99438a0983c49f3de018c241_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_be6276fb5dbb0ee04c29c239c449d569bf29743d99438a0983c49f3de018c241->leave($__internal_be6276fb5dbb0ee04c29c239c449d569bf29743d99438a0983c49f3de018c241_prof);

        
        $__internal_55b76a28a60f6b3148e9eceb7d2bbc46ed7fac8d1273b5ecd2edfeb04c5b4401->leave($__internal_55b76a28a60f6b3148e9eceb7d2bbc46ed7fac8d1273b5ecd2edfeb04c5b4401_prof);

    }

    // line 11
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_c798a82384637655492ff8112d618232e38cf6c91e4394b2c8b2f3b6a22413b3 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c798a82384637655492ff8112d618232e38cf6c91e4394b2c8b2f3b6a22413b3->enter($__internal_c798a82384637655492ff8112d618232e38cf6c91e4394b2c8b2f3b6a22413b3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_773f1f9eb7b08556ba9518b22d897d3b5885646baa698190ae5b83d418ed7da8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_773f1f9eb7b08556ba9518b22d897d3b5885646baa698190ae5b83d418ed7da8->enter($__internal_773f1f9eb7b08556ba9518b22d897d3b5885646baa698190ae5b83d418ed7da8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_773f1f9eb7b08556ba9518b22d897d3b5885646baa698190ae5b83d418ed7da8->leave($__internal_773f1f9eb7b08556ba9518b22d897d3b5885646baa698190ae5b83d418ed7da8_prof);

        
        $__internal_c798a82384637655492ff8112d618232e38cf6c91e4394b2c8b2f3b6a22413b3->leave($__internal_c798a82384637655492ff8112d618232e38cf6c91e4394b2c8b2f3b6a22413b3_prof);

    }

    public function getTemplateName()
    {
        return "::base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  117 => 11,  100 => 10,  83 => 6,  65 => 5,  53 => 12,  50 => 11,  48 => 10,  41 => 7,  39 => 6,  35 => 5,  29 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>{% block title %}Welcome!{% endblock %}</title>
        {% block stylesheets %}{% endblock %}
        <link rel=\"icon\" type=\"image/x-icon\" href=\"{{ asset('favicon.ico') }}\" />
    </head>
    <body>
        {% block body %}{% endblock %}
        {% block javascripts %}{% endblock %}
    </body>
</html>
", "::base.html.twig", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\views\\symfony\\app/Resources\\views/base.html.twig");
    }
}
