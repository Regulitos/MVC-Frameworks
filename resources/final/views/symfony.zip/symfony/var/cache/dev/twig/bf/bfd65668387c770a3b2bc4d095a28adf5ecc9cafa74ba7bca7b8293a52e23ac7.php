<?php

/* @Framework/Form/form_enctype.html.php */
class __TwigTemplate_c54de38a96336fc8c264fa5246cffcb1f77d7fbae541c8075c040282d209c2fd extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_93b17bb88d30f814ef91575ee7952ef7fa24c8fe36fa7b7cd5e8d895c4ab87d0 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_93b17bb88d30f814ef91575ee7952ef7fa24c8fe36fa7b7cd5e8d895c4ab87d0->enter($__internal_93b17bb88d30f814ef91575ee7952ef7fa24c8fe36fa7b7cd5e8d895c4ab87d0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_enctype.html.php"));

        $__internal_4639dcd77c7697a36a7a560639d73fb75d2d996a1e65d310ffb40d8eda6980fe = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4639dcd77c7697a36a7a560639d73fb75d2d996a1e65d310ffb40d8eda6980fe->enter($__internal_4639dcd77c7697a36a7a560639d73fb75d2d996a1e65d310ffb40d8eda6980fe_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_enctype.html.php"));

        // line 1
        echo "<?php if (\$form->vars['multipart']): ?>enctype=\"multipart/form-data\"<?php endif ?>
";
        
        $__internal_93b17bb88d30f814ef91575ee7952ef7fa24c8fe36fa7b7cd5e8d895c4ab87d0->leave($__internal_93b17bb88d30f814ef91575ee7952ef7fa24c8fe36fa7b7cd5e8d895c4ab87d0_prof);

        
        $__internal_4639dcd77c7697a36a7a560639d73fb75d2d996a1e65d310ffb40d8eda6980fe->leave($__internal_4639dcd77c7697a36a7a560639d73fb75d2d996a1e65d310ffb40d8eda6980fe_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_enctype.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (\$form->vars['multipart']): ?>enctype=\"multipart/form-data\"<?php endif ?>
", "@Framework/Form/form_enctype.html.php", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\views\\symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\form_enctype.html.php");
    }
}
