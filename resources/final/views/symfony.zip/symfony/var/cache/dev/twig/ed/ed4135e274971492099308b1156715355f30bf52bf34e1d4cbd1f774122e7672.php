<?php

/* WebProfilerBundle:Collector:exception.css.twig */
class __TwigTemplate_9e23bb3b7c7e353fd440ff94377d6eb97525f79328bf3189119862f753fc223e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d64b6ff38b676dd032c464ea001ec200dcb71630ea3a6404573a8798e55f37de = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d64b6ff38b676dd032c464ea001ec200dcb71630ea3a6404573a8798e55f37de->enter($__internal_d64b6ff38b676dd032c464ea001ec200dcb71630ea3a6404573a8798e55f37de_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Collector:exception.css.twig"));

        $__internal_c339b905a22dd20eeb530ad4bbfcc13184e2c40f80c2da7ff0920eb9e156c8d4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c339b905a22dd20eeb530ad4bbfcc13184e2c40f80c2da7ff0920eb9e156c8d4->enter($__internal_c339b905a22dd20eeb530ad4bbfcc13184e2c40f80c2da7ff0920eb9e156c8d4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Collector:exception.css.twig"));

        // line 1
        echo twig_include($this->env, $context, "@Twig/exception.css.twig");
        echo "

.container {
    max-width: auto;
    margin: 0;
    padding: 0;
}
.container .container {
    padding: 0;
}

.exception-summary {
    background: #FFF;
    border: 1px solid #E0E0E0;
    box-shadow: 0 0 1px rgba(128, 128, 128, .2);
    margin: 1em 0;
    padding: 10px;
}

.exception-message {
    color: #B0413E;
}

.exception-metadata,
.exception-illustration {
    display: none;
}

.exception-message-wrapper {
    min-height: auto;
}
";
        
        $__internal_d64b6ff38b676dd032c464ea001ec200dcb71630ea3a6404573a8798e55f37de->leave($__internal_d64b6ff38b676dd032c464ea001ec200dcb71630ea3a6404573a8798e55f37de_prof);

        
        $__internal_c339b905a22dd20eeb530ad4bbfcc13184e2c40f80c2da7ff0920eb9e156c8d4->leave($__internal_c339b905a22dd20eeb530ad4bbfcc13184e2c40f80c2da7ff0920eb9e156c8d4_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Collector:exception.css.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ include('@Twig/exception.css.twig') }}

.container {
    max-width: auto;
    margin: 0;
    padding: 0;
}
.container .container {
    padding: 0;
}

.exception-summary {
    background: #FFF;
    border: 1px solid #E0E0E0;
    box-shadow: 0 0 1px rgba(128, 128, 128, .2);
    margin: 1em 0;
    padding: 10px;
}

.exception-message {
    color: #B0413E;
}

.exception-metadata,
.exception-illustration {
    display: none;
}

.exception-message-wrapper {
    min-height: auto;
}
", "WebProfilerBundle:Collector:exception.css.twig", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\views\\symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle/Resources/views/Collector/exception.css.twig");
    }
}
