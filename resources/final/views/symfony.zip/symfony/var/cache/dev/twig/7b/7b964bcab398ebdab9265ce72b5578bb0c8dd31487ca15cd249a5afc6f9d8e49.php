<?php

/* @Framework/Form/form_widget_compound.html.php */
class __TwigTemplate_48da2b5a70dd8ebee4b5b00a21f4d66683f9829510a8297a84b97358b3a1d54d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_755bf7d1c653d6d28362680ff58b4ded470a9a38948f3e1a641d5f61a39f67f4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_755bf7d1c653d6d28362680ff58b4ded470a9a38948f3e1a641d5f61a39f67f4->enter($__internal_755bf7d1c653d6d28362680ff58b4ded470a9a38948f3e1a641d5f61a39f67f4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget_compound.html.php"));

        $__internal_b1507a12200dff5cc2de9be909fc97734a0787480572570da016229fefbad3d6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b1507a12200dff5cc2de9be909fc97734a0787480572570da016229fefbad3d6->enter($__internal_b1507a12200dff5cc2de9be909fc97734a0787480572570da016229fefbad3d6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget_compound.html.php"));

        // line 1
        echo "<div <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
    <?php if (!\$form->parent && \$errors): ?>
    <?php echo \$view['form']->errors(\$form) ?>
    <?php endif ?>
    <?php echo \$view['form']->block(\$form, 'form_rows') ?>
    <?php echo \$view['form']->rest(\$form) ?>
</div>
";
        
        $__internal_755bf7d1c653d6d28362680ff58b4ded470a9a38948f3e1a641d5f61a39f67f4->leave($__internal_755bf7d1c653d6d28362680ff58b4ded470a9a38948f3e1a641d5f61a39f67f4_prof);

        
        $__internal_b1507a12200dff5cc2de9be909fc97734a0787480572570da016229fefbad3d6->leave($__internal_b1507a12200dff5cc2de9be909fc97734a0787480572570da016229fefbad3d6_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_widget_compound.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
    <?php if (!\$form->parent && \$errors): ?>
    <?php echo \$view['form']->errors(\$form) ?>
    <?php endif ?>
    <?php echo \$view['form']->block(\$form, 'form_rows') ?>
    <?php echo \$view['form']->rest(\$form) ?>
</div>
", "@Framework/Form/form_widget_compound.html.php", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\views\\symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\form_widget_compound.html.php");
    }
}
