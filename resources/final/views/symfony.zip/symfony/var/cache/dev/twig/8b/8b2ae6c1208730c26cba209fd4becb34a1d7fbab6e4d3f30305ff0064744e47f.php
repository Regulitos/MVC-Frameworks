<?php

/* @Framework/Form/reset_widget.html.php */
class __TwigTemplate_58940593f855337d9d75604ee90768a3352995d21a47aa79598ce8f367b6c809 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_13bbd3141495ad895457448902a9442ac745a605ef2005a755d0b76e515ba424 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_13bbd3141495ad895457448902a9442ac745a605ef2005a755d0b76e515ba424->enter($__internal_13bbd3141495ad895457448902a9442ac745a605ef2005a755d0b76e515ba424_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/reset_widget.html.php"));

        $__internal_5078fcf04961847a34c995dd6d57cdf350279173d37a7c71f107ed7cd951ea91 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5078fcf04961847a34c995dd6d57cdf350279173d37a7c71f107ed7cd951ea91->enter($__internal_5078fcf04961847a34c995dd6d57cdf350279173d37a7c71f107ed7cd951ea91_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/reset_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'button_widget', array('type' => isset(\$type) ? \$type : 'reset')) ?>
";
        
        $__internal_13bbd3141495ad895457448902a9442ac745a605ef2005a755d0b76e515ba424->leave($__internal_13bbd3141495ad895457448902a9442ac745a605ef2005a755d0b76e515ba424_prof);

        
        $__internal_5078fcf04961847a34c995dd6d57cdf350279173d37a7c71f107ed7cd951ea91->leave($__internal_5078fcf04961847a34c995dd6d57cdf350279173d37a7c71f107ed7cd951ea91_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/reset_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'button_widget', array('type' => isset(\$type) ? \$type : 'reset')) ?>
", "@Framework/Form/reset_widget.html.php", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\views\\symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\reset_widget.html.php");
    }
}
