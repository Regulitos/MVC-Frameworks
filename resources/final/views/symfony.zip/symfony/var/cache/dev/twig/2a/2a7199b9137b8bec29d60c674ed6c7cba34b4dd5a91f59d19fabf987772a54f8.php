<?php

/* @Framework/Form/choice_widget.html.php */
class __TwigTemplate_19b24c3ca01ff1c80cb89eb5c1e553139f31644b676124b8966ecfc0b2ac90f6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ce93886dbe4c36ff65f9c1f4878c2559d9394ef097787220bb986296b37ebc37 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ce93886dbe4c36ff65f9c1f4878c2559d9394ef097787220bb986296b37ebc37->enter($__internal_ce93886dbe4c36ff65f9c1f4878c2559d9394ef097787220bb986296b37ebc37_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_widget.html.php"));

        $__internal_ee277d3b38f838b7ed831be9fafe490d93b9a23979cf75303dd343f2b2a5071d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ee277d3b38f838b7ed831be9fafe490d93b9a23979cf75303dd343f2b2a5071d->enter($__internal_ee277d3b38f838b7ed831be9fafe490d93b9a23979cf75303dd343f2b2a5071d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_widget.html.php"));

        // line 1
        echo "<?php if (\$expanded): ?>
<?php echo \$view['form']->block(\$form, 'choice_widget_expanded') ?>
<?php else: ?>
<?php echo \$view['form']->block(\$form, 'choice_widget_collapsed') ?>
<?php endif ?>
";
        
        $__internal_ce93886dbe4c36ff65f9c1f4878c2559d9394ef097787220bb986296b37ebc37->leave($__internal_ce93886dbe4c36ff65f9c1f4878c2559d9394ef097787220bb986296b37ebc37_prof);

        
        $__internal_ee277d3b38f838b7ed831be9fafe490d93b9a23979cf75303dd343f2b2a5071d->leave($__internal_ee277d3b38f838b7ed831be9fafe490d93b9a23979cf75303dd343f2b2a5071d_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/choice_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (\$expanded): ?>
<?php echo \$view['form']->block(\$form, 'choice_widget_expanded') ?>
<?php else: ?>
<?php echo \$view['form']->block(\$form, 'choice_widget_collapsed') ?>
<?php endif ?>
", "@Framework/Form/choice_widget.html.php", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\views\\symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\choice_widget.html.php");
    }
}
