<?php

/* @Framework/Form/textarea_widget.html.php */
class __TwigTemplate_eabb3ac8dc3ba789bfac05fc25b3fdba33e6539f0b9406c56b0abbb3501a00b8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_eb5693480b8263ad09e7f0c88867881b57633becf6051e391e50c142526be906 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_eb5693480b8263ad09e7f0c88867881b57633becf6051e391e50c142526be906->enter($__internal_eb5693480b8263ad09e7f0c88867881b57633becf6051e391e50c142526be906_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/textarea_widget.html.php"));

        $__internal_a82b3774d4b81343d3a2a944a4e2ebfd9356e952d81d5518f7bda3f2f0f3e8ce = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a82b3774d4b81343d3a2a944a4e2ebfd9356e952d81d5518f7bda3f2f0f3e8ce->enter($__internal_a82b3774d4b81343d3a2a944a4e2ebfd9356e952d81d5518f7bda3f2f0f3e8ce_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/textarea_widget.html.php"));

        // line 1
        echo "<textarea <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>><?php echo \$view->escape(\$value) ?></textarea>
";
        
        $__internal_eb5693480b8263ad09e7f0c88867881b57633becf6051e391e50c142526be906->leave($__internal_eb5693480b8263ad09e7f0c88867881b57633becf6051e391e50c142526be906_prof);

        
        $__internal_a82b3774d4b81343d3a2a944a4e2ebfd9356e952d81d5518f7bda3f2f0f3e8ce->leave($__internal_a82b3774d4b81343d3a2a944a4e2ebfd9356e952d81d5518f7bda3f2f0f3e8ce_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/textarea_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<textarea <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>><?php echo \$view->escape(\$value) ?></textarea>
", "@Framework/Form/textarea_widget.html.php", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\views\\symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\textarea_widget.html.php");
    }
}
