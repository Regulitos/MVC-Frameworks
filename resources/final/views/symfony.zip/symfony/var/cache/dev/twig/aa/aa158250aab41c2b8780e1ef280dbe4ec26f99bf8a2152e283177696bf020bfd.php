<?php

/* base.html.twig */
class __TwigTemplate_cf276ec5c8aeca8007e33ee25c4885ab60c5782e044b68c641db76c6879257f8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_08fcbd9339441184f5a43070a607ca31e306e660cc6424ce8a7402bab48f76d4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_08fcbd9339441184f5a43070a607ca31e306e660cc6424ce8a7402bab48f76d4->enter($__internal_08fcbd9339441184f5a43070a607ca31e306e660cc6424ce8a7402bab48f76d4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        $__internal_4c689bc2e89b45164c30d320e1b2e50a87bcf864857be34163cb49bb3c5fc4e2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4c689bc2e89b45164c30d320e1b2e50a87bcf864857be34163cb49bb3c5fc4e2->enter($__internal_4c689bc2e89b45164c30d320e1b2e50a87bcf864857be34163cb49bb3c5fc4e2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>";
        // line 5
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        ";
        // line 6
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 7
        echo "        <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />
    </head>
    <body>
        ";
        // line 10
        $this->displayBlock('body', $context, $blocks);
        // line 11
        echo "        ";
        $this->displayBlock('javascripts', $context, $blocks);
        // line 12
        echo "    </body>
</html>
";
        
        $__internal_08fcbd9339441184f5a43070a607ca31e306e660cc6424ce8a7402bab48f76d4->leave($__internal_08fcbd9339441184f5a43070a607ca31e306e660cc6424ce8a7402bab48f76d4_prof);

        
        $__internal_4c689bc2e89b45164c30d320e1b2e50a87bcf864857be34163cb49bb3c5fc4e2->leave($__internal_4c689bc2e89b45164c30d320e1b2e50a87bcf864857be34163cb49bb3c5fc4e2_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_711d7c163fc807b6c92131db01e2e066dd67daeb6879419d85ee523b25922229 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_711d7c163fc807b6c92131db01e2e066dd67daeb6879419d85ee523b25922229->enter($__internal_711d7c163fc807b6c92131db01e2e066dd67daeb6879419d85ee523b25922229_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_17d750ef7a9881776058f62e9e832b01908ed707a3bcda5477dc7fbf0634e56d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_17d750ef7a9881776058f62e9e832b01908ed707a3bcda5477dc7fbf0634e56d->enter($__internal_17d750ef7a9881776058f62e9e832b01908ed707a3bcda5477dc7fbf0634e56d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Welcome!";
        
        $__internal_17d750ef7a9881776058f62e9e832b01908ed707a3bcda5477dc7fbf0634e56d->leave($__internal_17d750ef7a9881776058f62e9e832b01908ed707a3bcda5477dc7fbf0634e56d_prof);

        
        $__internal_711d7c163fc807b6c92131db01e2e066dd67daeb6879419d85ee523b25922229->leave($__internal_711d7c163fc807b6c92131db01e2e066dd67daeb6879419d85ee523b25922229_prof);

    }

    // line 6
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_c5c62018452cb265980a6a56acc345bb3886afaa1e984f30420930286f326094 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c5c62018452cb265980a6a56acc345bb3886afaa1e984f30420930286f326094->enter($__internal_c5c62018452cb265980a6a56acc345bb3886afaa1e984f30420930286f326094_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_cf0c33ace5fb93457547faaafbd9e02ad7e19d4de1717220d3ae08374945f1a1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_cf0c33ace5fb93457547faaafbd9e02ad7e19d4de1717220d3ae08374945f1a1->enter($__internal_cf0c33ace5fb93457547faaafbd9e02ad7e19d4de1717220d3ae08374945f1a1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_cf0c33ace5fb93457547faaafbd9e02ad7e19d4de1717220d3ae08374945f1a1->leave($__internal_cf0c33ace5fb93457547faaafbd9e02ad7e19d4de1717220d3ae08374945f1a1_prof);

        
        $__internal_c5c62018452cb265980a6a56acc345bb3886afaa1e984f30420930286f326094->leave($__internal_c5c62018452cb265980a6a56acc345bb3886afaa1e984f30420930286f326094_prof);

    }

    // line 10
    public function block_body($context, array $blocks = array())
    {
        $__internal_047a8e7cdb0b3c44c18a9c898f84b1bdd942436cf39ea175436d7e5a714c16b9 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_047a8e7cdb0b3c44c18a9c898f84b1bdd942436cf39ea175436d7e5a714c16b9->enter($__internal_047a8e7cdb0b3c44c18a9c898f84b1bdd942436cf39ea175436d7e5a714c16b9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_1939a2c10e02dcc6f6726ef481da267031aff499f8fb21a5877c9f59c7f4f9ed = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1939a2c10e02dcc6f6726ef481da267031aff499f8fb21a5877c9f59c7f4f9ed->enter($__internal_1939a2c10e02dcc6f6726ef481da267031aff499f8fb21a5877c9f59c7f4f9ed_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_1939a2c10e02dcc6f6726ef481da267031aff499f8fb21a5877c9f59c7f4f9ed->leave($__internal_1939a2c10e02dcc6f6726ef481da267031aff499f8fb21a5877c9f59c7f4f9ed_prof);

        
        $__internal_047a8e7cdb0b3c44c18a9c898f84b1bdd942436cf39ea175436d7e5a714c16b9->leave($__internal_047a8e7cdb0b3c44c18a9c898f84b1bdd942436cf39ea175436d7e5a714c16b9_prof);

    }

    // line 11
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_15959b85d5806a9aaf38c078b2bd787aff48a124ccd1032ebe2c309a5ae0f3ea = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_15959b85d5806a9aaf38c078b2bd787aff48a124ccd1032ebe2c309a5ae0f3ea->enter($__internal_15959b85d5806a9aaf38c078b2bd787aff48a124ccd1032ebe2c309a5ae0f3ea_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_27c739b97e077e201c848a396d50c2d97b11b0d75acc4612f47c0654bb16d2ba = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_27c739b97e077e201c848a396d50c2d97b11b0d75acc4612f47c0654bb16d2ba->enter($__internal_27c739b97e077e201c848a396d50c2d97b11b0d75acc4612f47c0654bb16d2ba_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_27c739b97e077e201c848a396d50c2d97b11b0d75acc4612f47c0654bb16d2ba->leave($__internal_27c739b97e077e201c848a396d50c2d97b11b0d75acc4612f47c0654bb16d2ba_prof);

        
        $__internal_15959b85d5806a9aaf38c078b2bd787aff48a124ccd1032ebe2c309a5ae0f3ea->leave($__internal_15959b85d5806a9aaf38c078b2bd787aff48a124ccd1032ebe2c309a5ae0f3ea_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  117 => 11,  100 => 10,  83 => 6,  65 => 5,  53 => 12,  50 => 11,  48 => 10,  41 => 7,  39 => 6,  35 => 5,  29 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>{% block title %}Welcome!{% endblock %}</title>
        {% block stylesheets %}{% endblock %}
        <link rel=\"icon\" type=\"image/x-icon\" href=\"{{ asset('favicon.ico') }}\" />
    </head>
    <body>
        {% block body %}{% endblock %}
        {% block javascripts %}{% endblock %}
    </body>
</html>
", "base.html.twig", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\views\\symfony\\app\\Resources\\views\\base.html.twig");
    }
}
