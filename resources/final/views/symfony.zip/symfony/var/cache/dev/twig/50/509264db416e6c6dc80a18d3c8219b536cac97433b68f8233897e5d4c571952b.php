<?php

/* @Framework/FormTable/button_row.html.php */
class __TwigTemplate_94df3297117cf8b239d580640729497e45d1ff1ae07f22bc42337a949b66feb9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d1a00119adc51b45b808391f942f7af0c6b3e2127265b3ee71fe31888717de24 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d1a00119adc51b45b808391f942f7af0c6b3e2127265b3ee71fe31888717de24->enter($__internal_d1a00119adc51b45b808391f942f7af0c6b3e2127265b3ee71fe31888717de24_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/button_row.html.php"));

        $__internal_ae3e193a3691911e5e3b5e720e104123deefda883a3191099de1143337c4b0d5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ae3e193a3691911e5e3b5e720e104123deefda883a3191099de1143337c4b0d5->enter($__internal_ae3e193a3691911e5e3b5e720e104123deefda883a3191099de1143337c4b0d5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/button_row.html.php"));

        // line 1
        echo "<tr>
    <td></td>
    <td>
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
";
        
        $__internal_d1a00119adc51b45b808391f942f7af0c6b3e2127265b3ee71fe31888717de24->leave($__internal_d1a00119adc51b45b808391f942f7af0c6b3e2127265b3ee71fe31888717de24_prof);

        
        $__internal_ae3e193a3691911e5e3b5e720e104123deefda883a3191099de1143337c4b0d5->leave($__internal_ae3e193a3691911e5e3b5e720e104123deefda883a3191099de1143337c4b0d5_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/button_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<tr>
    <td></td>
    <td>
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
", "@Framework/FormTable/button_row.html.php", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\views\\symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\FormTable\\button_row.html.php");
    }
}
