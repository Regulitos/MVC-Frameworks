<?php

/* TwigBundle:Exception:error.js.twig */
class __TwigTemplate_c03c92ad869670f18bf9afe943f604332e795d48247f03ab695a303201fc70e3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6bab4f7e8536589a8c123ab0064fdf9e428e1b28bc3f4c51954ee07426838994 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6bab4f7e8536589a8c123ab0064fdf9e428e1b28bc3f4c51954ee07426838994->enter($__internal_6bab4f7e8536589a8c123ab0064fdf9e428e1b28bc3f4c51954ee07426838994_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.js.twig"));

        $__internal_b145c5d845fafe11040cb9941efaf08761ca70b3fd64f5c223f6b78a59cc7b40 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b145c5d845fafe11040cb9941efaf08761ca70b3fd64f5c223f6b78a59cc7b40->enter($__internal_b145c5d845fafe11040cb9941efaf08761ca70b3fd64f5c223f6b78a59cc7b40_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.js.twig"));

        // line 1
        echo "/*
";
        // line 2
        echo twig_escape_filter($this->env, ($context["status_code"] ?? $this->getContext($context, "status_code")), "js", null, true);
        echo " ";
        echo twig_escape_filter($this->env, ($context["status_text"] ?? $this->getContext($context, "status_text")), "js", null, true);
        echo "

*/
";
        
        $__internal_6bab4f7e8536589a8c123ab0064fdf9e428e1b28bc3f4c51954ee07426838994->leave($__internal_6bab4f7e8536589a8c123ab0064fdf9e428e1b28bc3f4c51954ee07426838994_prof);

        
        $__internal_b145c5d845fafe11040cb9941efaf08761ca70b3fd64f5c223f6b78a59cc7b40->leave($__internal_b145c5d845fafe11040cb9941efaf08761ca70b3fd64f5c223f6b78a59cc7b40_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.js.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  28 => 2,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("/*
{{ status_code }} {{ status_text }}

*/
", "TwigBundle:Exception:error.js.twig", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\views\\symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle/Resources/views/Exception/error.js.twig");
    }
}
