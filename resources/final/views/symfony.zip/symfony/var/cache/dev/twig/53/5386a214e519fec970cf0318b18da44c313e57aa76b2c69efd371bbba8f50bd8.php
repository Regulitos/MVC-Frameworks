<?php

/* @Twig/Exception/error.json.twig */
class __TwigTemplate_a8051311ad4758eb4d5b462fca1efa2add9ae20489400a05f18ce663c249a3c8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_eec82409f7d9cdf4bd8da42e5b60e0c8a3b5d04a61c1f1e84abd561abfac6234 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_eec82409f7d9cdf4bd8da42e5b60e0c8a3b5d04a61c1f1e84abd561abfac6234->enter($__internal_eec82409f7d9cdf4bd8da42e5b60e0c8a3b5d04a61c1f1e84abd561abfac6234_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.json.twig"));

        $__internal_fa2d440ae49746a2592a4be468140246e8d6660856d23317e43c5d230cdda2a9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fa2d440ae49746a2592a4be468140246e8d6660856d23317e43c5d230cdda2a9->enter($__internal_fa2d440ae49746a2592a4be468140246e8d6660856d23317e43c5d230cdda2a9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.json.twig"));

        // line 1
        echo twig_jsonencode_filter(array("error" => array("code" => ($context["status_code"] ?? $this->getContext($context, "status_code")), "message" => ($context["status_text"] ?? $this->getContext($context, "status_text")))));
        echo "
";
        
        $__internal_eec82409f7d9cdf4bd8da42e5b60e0c8a3b5d04a61c1f1e84abd561abfac6234->leave($__internal_eec82409f7d9cdf4bd8da42e5b60e0c8a3b5d04a61c1f1e84abd561abfac6234_prof);

        
        $__internal_fa2d440ae49746a2592a4be468140246e8d6660856d23317e43c5d230cdda2a9->leave($__internal_fa2d440ae49746a2592a4be468140246e8d6660856d23317e43c5d230cdda2a9_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/error.json.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ { 'error': { 'code': status_code, 'message': status_text } }|json_encode|raw }}
", "@Twig/Exception/error.json.twig", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\views\\symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\error.json.twig");
    }
}
