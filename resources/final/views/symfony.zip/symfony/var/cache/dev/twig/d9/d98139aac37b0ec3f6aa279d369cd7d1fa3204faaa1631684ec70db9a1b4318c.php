<?php

/* WebProfilerBundle:Profiler:toolbar_redirect.html.twig */
class __TwigTemplate_89852ac4f07d073d0f759aa1e3412d3ebf9e7c813906aa031a054819504545c0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@Twig/layout.html.twig", "WebProfilerBundle:Profiler:toolbar_redirect.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@Twig/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_573070aa00c079577051cf6a6fc811067afef4c63718f19f2a4020a1869bf86e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_573070aa00c079577051cf6a6fc811067afef4c63718f19f2a4020a1869bf86e->enter($__internal_573070aa00c079577051cf6a6fc811067afef4c63718f19f2a4020a1869bf86e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:toolbar_redirect.html.twig"));

        $__internal_453d89e3b89bf06addc6d7e6803abf770b703e29f79207f9295da5f6c0fa08fb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_453d89e3b89bf06addc6d7e6803abf770b703e29f79207f9295da5f6c0fa08fb->enter($__internal_453d89e3b89bf06addc6d7e6803abf770b703e29f79207f9295da5f6c0fa08fb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:toolbar_redirect.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_573070aa00c079577051cf6a6fc811067afef4c63718f19f2a4020a1869bf86e->leave($__internal_573070aa00c079577051cf6a6fc811067afef4c63718f19f2a4020a1869bf86e_prof);

        
        $__internal_453d89e3b89bf06addc6d7e6803abf770b703e29f79207f9295da5f6c0fa08fb->leave($__internal_453d89e3b89bf06addc6d7e6803abf770b703e29f79207f9295da5f6c0fa08fb_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_dd3f20f0546d87806044413db66ba611e48acc4e18a527fb98e12359b9e8608d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_dd3f20f0546d87806044413db66ba611e48acc4e18a527fb98e12359b9e8608d->enter($__internal_dd3f20f0546d87806044413db66ba611e48acc4e18a527fb98e12359b9e8608d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_ac32f251b87cd1a05dec788814709c5571e31fb3d925bdc3a5008c9d777d2988 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ac32f251b87cd1a05dec788814709c5571e31fb3d925bdc3a5008c9d777d2988->enter($__internal_ac32f251b87cd1a05dec788814709c5571e31fb3d925bdc3a5008c9d777d2988_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Redirection Intercepted";
        
        $__internal_ac32f251b87cd1a05dec788814709c5571e31fb3d925bdc3a5008c9d777d2988->leave($__internal_ac32f251b87cd1a05dec788814709c5571e31fb3d925bdc3a5008c9d777d2988_prof);

        
        $__internal_dd3f20f0546d87806044413db66ba611e48acc4e18a527fb98e12359b9e8608d->leave($__internal_dd3f20f0546d87806044413db66ba611e48acc4e18a527fb98e12359b9e8608d_prof);

    }

    // line 5
    public function block_body($context, array $blocks = array())
    {
        $__internal_5d161ec15c7aac276500fad6d3f026b7534c60d60fb7665a2f390905c28dd5c0 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5d161ec15c7aac276500fad6d3f026b7534c60d60fb7665a2f390905c28dd5c0->enter($__internal_5d161ec15c7aac276500fad6d3f026b7534c60d60fb7665a2f390905c28dd5c0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_f020137dd045ab091c91edabe737764633d0e0f4e5312d9dd2faa7d561922101 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f020137dd045ab091c91edabe737764633d0e0f4e5312d9dd2faa7d561922101->enter($__internal_f020137dd045ab091c91edabe737764633d0e0f4e5312d9dd2faa7d561922101_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "    <div class=\"sf-reset\">
        <div class=\"block-exception\">
            <h1>This request redirects to <a href=\"";
        // line 8
        echo twig_escape_filter($this->env, ($context["location"] ?? $this->getContext($context, "location")), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, ($context["location"] ?? $this->getContext($context, "location")), "html", null, true);
        echo "</a>.</h1>

            <p>
                <small>
                    The redirect was intercepted by the web debug toolbar to help debugging.
                    For more information, see the \"intercept-redirects\" option of the Profiler.
                </small>
            </p>
        </div>
    </div>
";
        
        $__internal_f020137dd045ab091c91edabe737764633d0e0f4e5312d9dd2faa7d561922101->leave($__internal_f020137dd045ab091c91edabe737764633d0e0f4e5312d9dd2faa7d561922101_prof);

        
        $__internal_5d161ec15c7aac276500fad6d3f026b7534c60d60fb7665a2f390905c28dd5c0->leave($__internal_5d161ec15c7aac276500fad6d3f026b7534c60d60fb7665a2f390905c28dd5c0_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:toolbar_redirect.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  72 => 8,  68 => 6,  59 => 5,  41 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@Twig/layout.html.twig' %}

{% block title 'Redirection Intercepted' %}

{% block body %}
    <div class=\"sf-reset\">
        <div class=\"block-exception\">
            <h1>This request redirects to <a href=\"{{ location }}\">{{ location }}</a>.</h1>

            <p>
                <small>
                    The redirect was intercepted by the web debug toolbar to help debugging.
                    For more information, see the \"intercept-redirects\" option of the Profiler.
                </small>
            </p>
        </div>
    </div>
{% endblock %}
", "WebProfilerBundle:Profiler:toolbar_redirect.html.twig", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\views\\symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle/Resources/views/Profiler/toolbar_redirect.html.twig");
    }
}
