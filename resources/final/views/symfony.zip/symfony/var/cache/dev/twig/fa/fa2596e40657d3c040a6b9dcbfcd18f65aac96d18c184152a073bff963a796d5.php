<?php

/* TwigBundle:Exception:exception.css.twig */
class __TwigTemplate_1643c1e7fd034384da1fcb810a8034aa244e9f33e8a0875f1fe8a6944c12a617 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_856acdf51454f6a9cd9eb787d8e87a35d4c934fc876553c4fff139a021cbb717 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_856acdf51454f6a9cd9eb787d8e87a35d4c934fc876553c4fff139a021cbb717->enter($__internal_856acdf51454f6a9cd9eb787d8e87a35d4c934fc876553c4fff139a021cbb717_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.css.twig"));

        $__internal_fefd94b13a592de957fd2c4f2adbd522e0d604db22f8c038231fb11b31ec46da = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fefd94b13a592de957fd2c4f2adbd522e0d604db22f8c038231fb11b31ec46da->enter($__internal_fefd94b13a592de957fd2c4f2adbd522e0d604db22f8c038231fb11b31ec46da_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.css.twig"));

        // line 1
        echo "/*
";
        // line 2
        echo twig_include($this->env, $context, "@Twig/Exception/exception.txt.twig", array("exception" => ($context["exception"] ?? $this->getContext($context, "exception"))));
        echo "
*/
";
        
        $__internal_856acdf51454f6a9cd9eb787d8e87a35d4c934fc876553c4fff139a021cbb717->leave($__internal_856acdf51454f6a9cd9eb787d8e87a35d4c934fc876553c4fff139a021cbb717_prof);

        
        $__internal_fefd94b13a592de957fd2c4f2adbd522e0d604db22f8c038231fb11b31ec46da->leave($__internal_fefd94b13a592de957fd2c4f2adbd522e0d604db22f8c038231fb11b31ec46da_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.css.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  28 => 2,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("/*
{{ include('@Twig/Exception/exception.txt.twig', { exception: exception }) }}
*/
", "TwigBundle:Exception:exception.css.twig", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\views\\symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle/Resources/views/Exception/exception.css.twig");
    }
}
