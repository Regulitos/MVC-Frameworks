<?php

/* TwigBundle:Exception:exception.js.twig */
class __TwigTemplate_b8abb0eb73b136d8efa53cdaca99e6dcdacfbf93297656837016661dd03ef842 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_85ed876813dd7a41ad672d3f5130a2a29f770618b8e69a00ccdce35738cdc721 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_85ed876813dd7a41ad672d3f5130a2a29f770618b8e69a00ccdce35738cdc721->enter($__internal_85ed876813dd7a41ad672d3f5130a2a29f770618b8e69a00ccdce35738cdc721_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.js.twig"));

        $__internal_6ed4c1f53d3d014e653481d5b804e7721cd3611869081808999daf67f3a15a9c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6ed4c1f53d3d014e653481d5b804e7721cd3611869081808999daf67f3a15a9c->enter($__internal_6ed4c1f53d3d014e653481d5b804e7721cd3611869081808999daf67f3a15a9c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.js.twig"));

        // line 1
        echo "/*
";
        // line 2
        echo twig_include($this->env, $context, "@Twig/Exception/exception.txt.twig", array("exception" => ($context["exception"] ?? $this->getContext($context, "exception"))));
        echo "
*/
";
        
        $__internal_85ed876813dd7a41ad672d3f5130a2a29f770618b8e69a00ccdce35738cdc721->leave($__internal_85ed876813dd7a41ad672d3f5130a2a29f770618b8e69a00ccdce35738cdc721_prof);

        
        $__internal_6ed4c1f53d3d014e653481d5b804e7721cd3611869081808999daf67f3a15a9c->leave($__internal_6ed4c1f53d3d014e653481d5b804e7721cd3611869081808999daf67f3a15a9c_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.js.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  28 => 2,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("/*
{{ include('@Twig/Exception/exception.txt.twig', { exception: exception }) }}
*/
", "TwigBundle:Exception:exception.js.twig", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\views\\symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle/Resources/views/Exception/exception.js.twig");
    }
}
