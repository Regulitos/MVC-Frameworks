<?php

/* WebProfilerBundle:Collector:router.html.twig */
class __TwigTemplate_afa9d77af99b48c2619f3c3857d2b04f85db861a56de9ca9c3f17809fac7a49b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "WebProfilerBundle:Collector:router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4bf64631e78cbafbf9149d3a08ca9ffd6efa8ad91f3ab9008074ee9380225f26 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4bf64631e78cbafbf9149d3a08ca9ffd6efa8ad91f3ab9008074ee9380225f26->enter($__internal_4bf64631e78cbafbf9149d3a08ca9ffd6efa8ad91f3ab9008074ee9380225f26_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Collector:router.html.twig"));

        $__internal_73e7f0530d044e6e7bf7c601b028f0957cf0c2bb43330e48e9183db4e54d9d7b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_73e7f0530d044e6e7bf7c601b028f0957cf0c2bb43330e48e9183db4e54d9d7b->enter($__internal_73e7f0530d044e6e7bf7c601b028f0957cf0c2bb43330e48e9183db4e54d9d7b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Collector:router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_4bf64631e78cbafbf9149d3a08ca9ffd6efa8ad91f3ab9008074ee9380225f26->leave($__internal_4bf64631e78cbafbf9149d3a08ca9ffd6efa8ad91f3ab9008074ee9380225f26_prof);

        
        $__internal_73e7f0530d044e6e7bf7c601b028f0957cf0c2bb43330e48e9183db4e54d9d7b->leave($__internal_73e7f0530d044e6e7bf7c601b028f0957cf0c2bb43330e48e9183db4e54d9d7b_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_a6457a734986ad119085216f3ad2b95429f84f46f767878a6133caf3b0d085d6 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a6457a734986ad119085216f3ad2b95429f84f46f767878a6133caf3b0d085d6->enter($__internal_a6457a734986ad119085216f3ad2b95429f84f46f767878a6133caf3b0d085d6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        $__internal_9549ec5528634d6d3d8f93f4e1ec9325af8ae4bcf45f244e5cbcc76dead3917b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9549ec5528634d6d3d8f93f4e1ec9325af8ae4bcf45f244e5cbcc76dead3917b->enter($__internal_9549ec5528634d6d3d8f93f4e1ec9325af8ae4bcf45f244e5cbcc76dead3917b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_9549ec5528634d6d3d8f93f4e1ec9325af8ae4bcf45f244e5cbcc76dead3917b->leave($__internal_9549ec5528634d6d3d8f93f4e1ec9325af8ae4bcf45f244e5cbcc76dead3917b_prof);

        
        $__internal_a6457a734986ad119085216f3ad2b95429f84f46f767878a6133caf3b0d085d6->leave($__internal_a6457a734986ad119085216f3ad2b95429f84f46f767878a6133caf3b0d085d6_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_3ced30d6e6a53c4b737713aa7e6201193d84690a1db454b399b9c4310401055b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3ced30d6e6a53c4b737713aa7e6201193d84690a1db454b399b9c4310401055b->enter($__internal_3ced30d6e6a53c4b737713aa7e6201193d84690a1db454b399b9c4310401055b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_841e5464ee5ff524f1b5fb3a9ae5124e91891f05e0f564cf408e6ca54a15eda1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_841e5464ee5ff524f1b5fb3a9ae5124e91891f05e0f564cf408e6ca54a15eda1->enter($__internal_841e5464ee5ff524f1b5fb3a9ae5124e91891f05e0f564cf408e6ca54a15eda1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_841e5464ee5ff524f1b5fb3a9ae5124e91891f05e0f564cf408e6ca54a15eda1->leave($__internal_841e5464ee5ff524f1b5fb3a9ae5124e91891f05e0f564cf408e6ca54a15eda1_prof);

        
        $__internal_3ced30d6e6a53c4b737713aa7e6201193d84690a1db454b399b9c4310401055b->leave($__internal_3ced30d6e6a53c4b737713aa7e6201193d84690a1db454b399b9c4310401055b_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_d9b8bb1f5805bb0b86ef2d9955e316662d9b1367e12302c1628617749bc736b6 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d9b8bb1f5805bb0b86ef2d9955e316662d9b1367e12302c1628617749bc736b6->enter($__internal_d9b8bb1f5805bb0b86ef2d9955e316662d9b1367e12302c1628617749bc736b6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_fe8e7541b01a495100f5e34896942eac507052c986ebe7edac32f51b65be7143 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fe8e7541b01a495100f5e34896942eac507052c986ebe7edac32f51b65be7143->enter($__internal_fe8e7541b01a495100f5e34896942eac507052c986ebe7edac32f51b65be7143_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_fe8e7541b01a495100f5e34896942eac507052c986ebe7edac32f51b65be7143->leave($__internal_fe8e7541b01a495100f5e34896942eac507052c986ebe7edac32f51b65be7143_prof);

        
        $__internal_d9b8bb1f5805bb0b86ef2d9955e316662d9b1367e12302c1628617749bc736b6->leave($__internal_d9b8bb1f5805bb0b86ef2d9955e316662d9b1367e12302c1628617749bc736b6_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Collector:router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  94 => 13,  85 => 12,  71 => 7,  68 => 6,  59 => 5,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
", "WebProfilerBundle:Collector:router.html.twig", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\views\\symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle/Resources/views/Collector/router.html.twig");
    }
}
