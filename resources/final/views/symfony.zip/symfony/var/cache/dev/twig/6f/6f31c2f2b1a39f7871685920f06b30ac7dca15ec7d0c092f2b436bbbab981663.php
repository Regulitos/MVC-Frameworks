<?php

/* @Framework/Form/form_widget.html.php */
class __TwigTemplate_d572ad79cf07edcbf04f8519722e71bda34fbd095c29299224d58fd7eb57d90d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_482fb29fa37321215232b1beacc953b64ac33dd69a3f6e044d71232cf05b34d1 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_482fb29fa37321215232b1beacc953b64ac33dd69a3f6e044d71232cf05b34d1->enter($__internal_482fb29fa37321215232b1beacc953b64ac33dd69a3f6e044d71232cf05b34d1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget.html.php"));

        $__internal_373ad089680bae544b48b79550c35f7dd99456dd2ab36c4e061f33d61375b0e6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_373ad089680bae544b48b79550c35f7dd99456dd2ab36c4e061f33d61375b0e6->enter($__internal_373ad089680bae544b48b79550c35f7dd99456dd2ab36c4e061f33d61375b0e6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget.html.php"));

        // line 1
        echo "<?php if (\$compound): ?>
<?php echo \$view['form']->block(\$form, 'form_widget_compound')?>
<?php else: ?>
<?php echo \$view['form']->block(\$form, 'form_widget_simple')?>
<?php endif ?>
";
        
        $__internal_482fb29fa37321215232b1beacc953b64ac33dd69a3f6e044d71232cf05b34d1->leave($__internal_482fb29fa37321215232b1beacc953b64ac33dd69a3f6e044d71232cf05b34d1_prof);

        
        $__internal_373ad089680bae544b48b79550c35f7dd99456dd2ab36c4e061f33d61375b0e6->leave($__internal_373ad089680bae544b48b79550c35f7dd99456dd2ab36c4e061f33d61375b0e6_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (\$compound): ?>
<?php echo \$view['form']->block(\$form, 'form_widget_compound')?>
<?php else: ?>
<?php echo \$view['form']->block(\$form, 'form_widget_simple')?>
<?php endif ?>
", "@Framework/Form/form_widget.html.php", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\views\\symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\form_widget.html.php");
    }
}
