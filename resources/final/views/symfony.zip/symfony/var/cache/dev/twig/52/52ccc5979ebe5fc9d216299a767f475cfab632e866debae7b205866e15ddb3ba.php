<?php

/* @Framework/Form/radio_widget.html.php */
class __TwigTemplate_de4109765a9af087da3d5e729e2c8a0137a15deeb1f70611aa50efcd0b8649fa extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_81af599c29d1457691ddfc5c19c7b52839ca5b5ff474dca6978018afa4d46e64 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_81af599c29d1457691ddfc5c19c7b52839ca5b5ff474dca6978018afa4d46e64->enter($__internal_81af599c29d1457691ddfc5c19c7b52839ca5b5ff474dca6978018afa4d46e64_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/radio_widget.html.php"));

        $__internal_ab6ebb4c8cf73640e17cf6ca1f21c239e70a7866a079c5a0b0e5d9868dd9344b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ab6ebb4c8cf73640e17cf6ca1f21c239e70a7866a079c5a0b0e5d9868dd9344b->enter($__internal_ab6ebb4c8cf73640e17cf6ca1f21c239e70a7866a079c5a0b0e5d9868dd9344b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/radio_widget.html.php"));

        // line 1
        echo "<input type=\"radio\"
    <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
    value=\"<?php echo \$view->escape(\$value) ?>\"
    <?php if (\$checked): ?> checked=\"checked\"<?php endif ?>
/>
";
        
        $__internal_81af599c29d1457691ddfc5c19c7b52839ca5b5ff474dca6978018afa4d46e64->leave($__internal_81af599c29d1457691ddfc5c19c7b52839ca5b5ff474dca6978018afa4d46e64_prof);

        
        $__internal_ab6ebb4c8cf73640e17cf6ca1f21c239e70a7866a079c5a0b0e5d9868dd9344b->leave($__internal_ab6ebb4c8cf73640e17cf6ca1f21c239e70a7866a079c5a0b0e5d9868dd9344b_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/radio_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<input type=\"radio\"
    <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
    value=\"<?php echo \$view->escape(\$value) ?>\"
    <?php if (\$checked): ?> checked=\"checked\"<?php endif ?>
/>
", "@Framework/Form/radio_widget.html.php", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\views\\symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\radio_widget.html.php");
    }
}
