<?php

/* @WebProfiler/Collector/exception.css.twig */
class __TwigTemplate_771a6d471daf0f81f81b2ce0315d4f6fdf3405df4b4ec6bb5de37d52456374ee extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_42dadadc48372abb69f41bbe3ddf660b9662376352ebf60580aaab7d8b9d600b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_42dadadc48372abb69f41bbe3ddf660b9662376352ebf60580aaab7d8b9d600b->enter($__internal_42dadadc48372abb69f41bbe3ddf660b9662376352ebf60580aaab7d8b9d600b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/exception.css.twig"));

        $__internal_cd84ea0752eae30312cef47b2a4d40b9939836ef4e87671b35c143a4e556687b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_cd84ea0752eae30312cef47b2a4d40b9939836ef4e87671b35c143a4e556687b->enter($__internal_cd84ea0752eae30312cef47b2a4d40b9939836ef4e87671b35c143a4e556687b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/exception.css.twig"));

        // line 1
        echo twig_include($this->env, $context, "@Twig/exception.css.twig");
        echo "

.container {
    max-width: auto;
    margin: 0;
    padding: 0;
}
.container .container {
    padding: 0;
}

.exception-summary {
    background: #FFF;
    border: 1px solid #E0E0E0;
    box-shadow: 0 0 1px rgba(128, 128, 128, .2);
    margin: 1em 0;
    padding: 10px;
}

.exception-message {
    color: #B0413E;
}

.exception-metadata,
.exception-illustration {
    display: none;
}

.exception-message-wrapper {
    min-height: auto;
}
";
        
        $__internal_42dadadc48372abb69f41bbe3ddf660b9662376352ebf60580aaab7d8b9d600b->leave($__internal_42dadadc48372abb69f41bbe3ddf660b9662376352ebf60580aaab7d8b9d600b_prof);

        
        $__internal_cd84ea0752eae30312cef47b2a4d40b9939836ef4e87671b35c143a4e556687b->leave($__internal_cd84ea0752eae30312cef47b2a4d40b9939836ef4e87671b35c143a4e556687b_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/exception.css.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ include('@Twig/exception.css.twig') }}

.container {
    max-width: auto;
    margin: 0;
    padding: 0;
}
.container .container {
    padding: 0;
}

.exception-summary {
    background: #FFF;
    border: 1px solid #E0E0E0;
    box-shadow: 0 0 1px rgba(128, 128, 128, .2);
    margin: 1em 0;
    padding: 10px;
}

.exception-message {
    color: #B0413E;
}

.exception-metadata,
.exception-illustration {
    display: none;
}

.exception-message-wrapper {
    min-height: auto;
}
", "@WebProfiler/Collector/exception.css.twig", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\views\\symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Collector\\exception.css.twig");
    }
}
