<?php

/* @Framework/Form/button_label.html.php */
class __TwigTemplate_0710a0509677fc0eb5b818cff1fe5c815f5c29a8028b78066672fae900340f03 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e1fd8383875e7dd1d887c45e7b3de315c93aa2ba06fa7caf9311df7f703f606b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e1fd8383875e7dd1d887c45e7b3de315c93aa2ba06fa7caf9311df7f703f606b->enter($__internal_e1fd8383875e7dd1d887c45e7b3de315c93aa2ba06fa7caf9311df7f703f606b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_label.html.php"));

        $__internal_85fcaf773b71b298c678dad7978100590c1194ed603e8435551a9cd958720b59 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_85fcaf773b71b298c678dad7978100590c1194ed603e8435551a9cd958720b59->enter($__internal_85fcaf773b71b298c678dad7978100590c1194ed603e8435551a9cd958720b59_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_label.html.php"));

        
        $__internal_e1fd8383875e7dd1d887c45e7b3de315c93aa2ba06fa7caf9311df7f703f606b->leave($__internal_e1fd8383875e7dd1d887c45e7b3de315c93aa2ba06fa7caf9311df7f703f606b_prof);

        
        $__internal_85fcaf773b71b298c678dad7978100590c1194ed603e8435551a9cd958720b59->leave($__internal_85fcaf773b71b298c678dad7978100590c1194ed603e8435551a9cd958720b59_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_label.html.php";
    }

    public function getDebugInfo()
    {
        return array ();
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "@Framework/Form/button_label.html.php", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\views\\symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\button_label.html.php");
    }
}
