<?php

/* WebProfilerBundle:Profiler:open.html.twig */
class __TwigTemplate_43a02ceeb6778dc7ff7e163a71b1e8225e8c8cc9de4b59e80973d9804aa2b22a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/base.html.twig", "WebProfilerBundle:Profiler:open.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a9a0e92a424ac938522bb258f04c6d8298ea6fdc665c6e07d7c9cefa50ddcf7c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a9a0e92a424ac938522bb258f04c6d8298ea6fdc665c6e07d7c9cefa50ddcf7c->enter($__internal_a9a0e92a424ac938522bb258f04c6d8298ea6fdc665c6e07d7c9cefa50ddcf7c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:open.html.twig"));

        $__internal_aff0549adfae14608dd0f1b68b52c1245aa263123a386b76dfe2f89d47f88901 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_aff0549adfae14608dd0f1b68b52c1245aa263123a386b76dfe2f89d47f88901->enter($__internal_aff0549adfae14608dd0f1b68b52c1245aa263123a386b76dfe2f89d47f88901_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:open.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_a9a0e92a424ac938522bb258f04c6d8298ea6fdc665c6e07d7c9cefa50ddcf7c->leave($__internal_a9a0e92a424ac938522bb258f04c6d8298ea6fdc665c6e07d7c9cefa50ddcf7c_prof);

        
        $__internal_aff0549adfae14608dd0f1b68b52c1245aa263123a386b76dfe2f89d47f88901->leave($__internal_aff0549adfae14608dd0f1b68b52c1245aa263123a386b76dfe2f89d47f88901_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_251287be52fc4b21f3a3435f64c9ce1783b9894fb1e5c91c72bf4720e2f38c01 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_251287be52fc4b21f3a3435f64c9ce1783b9894fb1e5c91c72bf4720e2f38c01->enter($__internal_251287be52fc4b21f3a3435f64c9ce1783b9894fb1e5c91c72bf4720e2f38c01_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        $__internal_bb5c587eaf5906eb641cd1a455f9876eb069e186576708d93877d44de8a27e1e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_bb5c587eaf5906eb641cd1a455f9876eb069e186576708d93877d44de8a27e1e->enter($__internal_bb5c587eaf5906eb641cd1a455f9876eb069e186576708d93877d44de8a27e1e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    <style>
        ";
        // line 5
        echo twig_include($this->env, $context, "@WebProfiler/Profiler/open.css.twig");
        echo "
    </style>
";
        
        $__internal_bb5c587eaf5906eb641cd1a455f9876eb069e186576708d93877d44de8a27e1e->leave($__internal_bb5c587eaf5906eb641cd1a455f9876eb069e186576708d93877d44de8a27e1e_prof);

        
        $__internal_251287be52fc4b21f3a3435f64c9ce1783b9894fb1e5c91c72bf4720e2f38c01->leave($__internal_251287be52fc4b21f3a3435f64c9ce1783b9894fb1e5c91c72bf4720e2f38c01_prof);

    }

    // line 9
    public function block_body($context, array $blocks = array())
    {
        $__internal_adb0d8bffba9a894868085cf9773a198d99ae9d4804b8e9feea6c0ee9f71a6a9 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_adb0d8bffba9a894868085cf9773a198d99ae9d4804b8e9feea6c0ee9f71a6a9->enter($__internal_adb0d8bffba9a894868085cf9773a198d99ae9d4804b8e9feea6c0ee9f71a6a9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_36365f30c2ee5d47314d1ca702874b4e7324a275050cd68750e7a8cf4cd456c5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_36365f30c2ee5d47314d1ca702874b4e7324a275050cd68750e7a8cf4cd456c5->enter($__internal_36365f30c2ee5d47314d1ca702874b4e7324a275050cd68750e7a8cf4cd456c5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 10
        echo "<div class=\"header\">
    <h1>";
        // line 11
        echo twig_escape_filter($this->env, ($context["file"] ?? $this->getContext($context, "file")), "html", null, true);
        echo " <small>line ";
        echo twig_escape_filter($this->env, ($context["line"] ?? $this->getContext($context, "line")), "html", null, true);
        echo "</small></h1>
    <a class=\"doc\" href=\"https://symfony.com/doc/";
        // line 12
        echo twig_escape_filter($this->env, twig_constant("Symfony\\Component\\HttpKernel\\Kernel::VERSION"), "html", null, true);
        echo "/reference/configuration/framework.html#ide\" rel=\"help\">Open in your IDE?</a>
</div>
<div class=\"source\">
    ";
        // line 15
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\CodeExtension')->fileExcerpt(($context["filename"] ?? $this->getContext($context, "filename")), ($context["line"] ?? $this->getContext($context, "line")),  -1);
        echo "
</div>
";
        
        $__internal_36365f30c2ee5d47314d1ca702874b4e7324a275050cd68750e7a8cf4cd456c5->leave($__internal_36365f30c2ee5d47314d1ca702874b4e7324a275050cd68750e7a8cf4cd456c5_prof);

        
        $__internal_adb0d8bffba9a894868085cf9773a198d99ae9d4804b8e9feea6c0ee9f71a6a9->leave($__internal_adb0d8bffba9a894868085cf9773a198d99ae9d4804b8e9feea6c0ee9f71a6a9_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:open.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  90 => 15,  84 => 12,  78 => 11,  75 => 10,  66 => 9,  53 => 5,  50 => 4,  41 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/base.html.twig' %}

{% block head %}
    <style>
        {{ include('@WebProfiler/Profiler/open.css.twig') }}
    </style>
{% endblock %}

{% block body %}
<div class=\"header\">
    <h1>{{ file }} <small>line {{ line }}</small></h1>
    <a class=\"doc\" href=\"https://symfony.com/doc/{{ constant('Symfony\\\\Component\\\\HttpKernel\\\\Kernel::VERSION') }}/reference/configuration/framework.html#ide\" rel=\"help\">Open in your IDE?</a>
</div>
<div class=\"source\">
    {{ filename|file_excerpt(line, -1) }}
</div>
{% endblock %}
", "WebProfilerBundle:Profiler:open.html.twig", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\views\\symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle/Resources/views/Profiler/open.html.twig");
    }
}
