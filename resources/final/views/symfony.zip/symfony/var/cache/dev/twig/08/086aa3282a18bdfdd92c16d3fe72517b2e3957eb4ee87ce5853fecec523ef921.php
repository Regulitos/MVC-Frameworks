<?php

/* @WebProfiler/Collector/exception.html.twig */
class __TwigTemplate_91f23d26d1e9c4d15bd74abc1f548fe71498140eaf4fd2e477e058e8a9bd1df4 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/exception.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_cc633b26d63276ef71fc264dffbfd5d60d6d4fa090a0335819b97f055774d6f1 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_cc633b26d63276ef71fc264dffbfd5d60d6d4fa090a0335819b97f055774d6f1->enter($__internal_cc633b26d63276ef71fc264dffbfd5d60d6d4fa090a0335819b97f055774d6f1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/exception.html.twig"));

        $__internal_432e262a65acdd22875fdedad9caead025df2ec91817ae1fb971ad6109b926e1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_432e262a65acdd22875fdedad9caead025df2ec91817ae1fb971ad6109b926e1->enter($__internal_432e262a65acdd22875fdedad9caead025df2ec91817ae1fb971ad6109b926e1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/exception.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_cc633b26d63276ef71fc264dffbfd5d60d6d4fa090a0335819b97f055774d6f1->leave($__internal_cc633b26d63276ef71fc264dffbfd5d60d6d4fa090a0335819b97f055774d6f1_prof);

        
        $__internal_432e262a65acdd22875fdedad9caead025df2ec91817ae1fb971ad6109b926e1->leave($__internal_432e262a65acdd22875fdedad9caead025df2ec91817ae1fb971ad6109b926e1_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_44278a8b72b7e7941191f2b79107aeb60d615437bef1674985ca675dc75ba98f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_44278a8b72b7e7941191f2b79107aeb60d615437bef1674985ca675dc75ba98f->enter($__internal_44278a8b72b7e7941191f2b79107aeb60d615437bef1674985ca675dc75ba98f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        $__internal_aa1ee8088bcf39164a1d77e8b132228bbe9e227e1d2daeb8d86af8353e6f918f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_aa1ee8088bcf39164a1d77e8b132228bbe9e227e1d2daeb8d86af8353e6f918f->enter($__internal_aa1ee8088bcf39164a1d77e8b132228bbe9e227e1d2daeb8d86af8353e6f918f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    ";
        if ($this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) {
            // line 5
            echo "        <style>
            ";
            // line 6
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_exception_css", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
            echo "
        </style>
    ";
        }
        // line 9
        echo "    ";
        $this->displayParentBlock("head", $context, $blocks);
        echo "
";
        
        $__internal_aa1ee8088bcf39164a1d77e8b132228bbe9e227e1d2daeb8d86af8353e6f918f->leave($__internal_aa1ee8088bcf39164a1d77e8b132228bbe9e227e1d2daeb8d86af8353e6f918f_prof);

        
        $__internal_44278a8b72b7e7941191f2b79107aeb60d615437bef1674985ca675dc75ba98f->leave($__internal_44278a8b72b7e7941191f2b79107aeb60d615437bef1674985ca675dc75ba98f_prof);

    }

    // line 12
    public function block_menu($context, array $blocks = array())
    {
        $__internal_a68fb3f7d827cf9e61b9941795ebe09aebfc50f2282390f15e8cdf304d2e32dd = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a68fb3f7d827cf9e61b9941795ebe09aebfc50f2282390f15e8cdf304d2e32dd->enter($__internal_a68fb3f7d827cf9e61b9941795ebe09aebfc50f2282390f15e8cdf304d2e32dd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_baf5c65a4b76a93e95e778f77ea54f9c58da05009ee2cb0293be766391dc49ce = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_baf5c65a4b76a93e95e778f77ea54f9c58da05009ee2cb0293be766391dc49ce->enter($__internal_baf5c65a4b76a93e95e778f77ea54f9c58da05009ee2cb0293be766391dc49ce_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 13
        echo "    <span class=\"label ";
        echo (($this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) ? ("label-status-error") : ("disabled"));
        echo "\">
        <span class=\"icon\">";
        // line 14
        echo twig_include($this->env, $context, "@WebProfiler/Icon/exception.svg");
        echo "</span>
        <strong>Exception</strong>
        ";
        // line 16
        if ($this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) {
            // line 17
            echo "            <span class=\"count\">
                <span>1</span>
            </span>
        ";
        }
        // line 21
        echo "    </span>
";
        
        $__internal_baf5c65a4b76a93e95e778f77ea54f9c58da05009ee2cb0293be766391dc49ce->leave($__internal_baf5c65a4b76a93e95e778f77ea54f9c58da05009ee2cb0293be766391dc49ce_prof);

        
        $__internal_a68fb3f7d827cf9e61b9941795ebe09aebfc50f2282390f15e8cdf304d2e32dd->leave($__internal_a68fb3f7d827cf9e61b9941795ebe09aebfc50f2282390f15e8cdf304d2e32dd_prof);

    }

    // line 24
    public function block_panel($context, array $blocks = array())
    {
        $__internal_adb5f58d7cdb3bc0b2d57539de5b7dfb1f63a2859608ee6f5fb26f51d7ddb0a2 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_adb5f58d7cdb3bc0b2d57539de5b7dfb1f63a2859608ee6f5fb26f51d7ddb0a2->enter($__internal_adb5f58d7cdb3bc0b2d57539de5b7dfb1f63a2859608ee6f5fb26f51d7ddb0a2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_823dfd34bdf305ef7ef6a46df4f6105ffa1f45505e4c4563fa11c39bbf3241df = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_823dfd34bdf305ef7ef6a46df4f6105ffa1f45505e4c4563fa11c39bbf3241df->enter($__internal_823dfd34bdf305ef7ef6a46df4f6105ffa1f45505e4c4563fa11c39bbf3241df_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 25
        echo "    <h2>Exceptions</h2>

    ";
        // line 27
        if ( !$this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) {
            // line 28
            echo "        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    ";
        } else {
            // line 32
            echo "        <div class=\"sf-reset\">
            ";
            // line 33
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_exception", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
            echo "
        </div>
    ";
        }
        
        $__internal_823dfd34bdf305ef7ef6a46df4f6105ffa1f45505e4c4563fa11c39bbf3241df->leave($__internal_823dfd34bdf305ef7ef6a46df4f6105ffa1f45505e4c4563fa11c39bbf3241df_prof);

        
        $__internal_adb5f58d7cdb3bc0b2d57539de5b7dfb1f63a2859608ee6f5fb26f51d7ddb0a2->leave($__internal_adb5f58d7cdb3bc0b2d57539de5b7dfb1f63a2859608ee6f5fb26f51d7ddb0a2_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/exception.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  138 => 33,  135 => 32,  129 => 28,  127 => 27,  123 => 25,  114 => 24,  103 => 21,  97 => 17,  95 => 16,  90 => 14,  85 => 13,  76 => 12,  63 => 9,  57 => 6,  54 => 5,  51 => 4,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block head %}
    {% if collector.hasexception %}
        <style>
            {{ render(path('_profiler_exception_css', { token: token })) }}
        </style>
    {% endif %}
    {{ parent() }}
{% endblock %}

{% block menu %}
    <span class=\"label {{ collector.hasexception ? 'label-status-error' : 'disabled' }}\">
        <span class=\"icon\">{{ include('@WebProfiler/Icon/exception.svg') }}</span>
        <strong>Exception</strong>
        {% if collector.hasexception %}
            <span class=\"count\">
                <span>1</span>
            </span>
        {% endif %}
    </span>
{% endblock %}

{% block panel %}
    <h2>Exceptions</h2>

    {% if not collector.hasexception %}
        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    {% else %}
        <div class=\"sf-reset\">
            {{ render(path('_profiler_exception', { token: token })) }}
        </div>
    {% endif %}
{% endblock %}
", "@WebProfiler/Collector/exception.html.twig", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\views\\symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Collector\\exception.html.twig");
    }
}
