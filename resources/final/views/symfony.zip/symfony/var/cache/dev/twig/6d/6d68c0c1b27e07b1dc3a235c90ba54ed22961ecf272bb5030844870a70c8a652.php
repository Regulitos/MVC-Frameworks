<?php

/* @Framework/Form/integer_widget.html.php */
class __TwigTemplate_c8f4bb651aa9a53a250947c965509d5f20972e5542037524e593ab87d08da757 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_62b035a933aa7aea8530a714da293eb4cb908b7395079f72873d902ce2f23efb = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_62b035a933aa7aea8530a714da293eb4cb908b7395079f72873d902ce2f23efb->enter($__internal_62b035a933aa7aea8530a714da293eb4cb908b7395079f72873d902ce2f23efb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/integer_widget.html.php"));

        $__internal_2813a3ccc6f369e014612ba516c25dbbdaf7d5283c067d732ccae13b015b3854 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2813a3ccc6f369e014612ba516c25dbbdaf7d5283c067d732ccae13b015b3854->enter($__internal_2813a3ccc6f369e014612ba516c25dbbdaf7d5283c067d732ccae13b015b3854_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/integer_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'number')) ?>
";
        
        $__internal_62b035a933aa7aea8530a714da293eb4cb908b7395079f72873d902ce2f23efb->leave($__internal_62b035a933aa7aea8530a714da293eb4cb908b7395079f72873d902ce2f23efb_prof);

        
        $__internal_2813a3ccc6f369e014612ba516c25dbbdaf7d5283c067d732ccae13b015b3854->leave($__internal_2813a3ccc6f369e014612ba516c25dbbdaf7d5283c067d732ccae13b015b3854_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/integer_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'number')) ?>
", "@Framework/Form/integer_widget.html.php", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\views\\symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\integer_widget.html.php");
    }
}
