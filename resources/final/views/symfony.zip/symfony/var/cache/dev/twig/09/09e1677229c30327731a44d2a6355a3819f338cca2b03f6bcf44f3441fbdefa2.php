<?php

/* TwigBundle:Exception:exception.rdf.twig */
class __TwigTemplate_179cbaea0a8bb4615471c354ca9447064c125c526a4b8e1012b95aeec811cf13 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d8dad33b273b6a0cdb8ce240f16125d03b91efb85552426d156fe8675602a657 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d8dad33b273b6a0cdb8ce240f16125d03b91efb85552426d156fe8675602a657->enter($__internal_d8dad33b273b6a0cdb8ce240f16125d03b91efb85552426d156fe8675602a657_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.rdf.twig"));

        $__internal_da25989df19f1b6185f0aea31ad18ebf2b155c7feecc3e0f97652ad03145706a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_da25989df19f1b6185f0aea31ad18ebf2b155c7feecc3e0f97652ad03145706a->enter($__internal_da25989df19f1b6185f0aea31ad18ebf2b155c7feecc3e0f97652ad03145706a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.rdf.twig"));

        // line 1
        echo twig_include($this->env, $context, "@Twig/Exception/exception.xml.twig", array("exception" => ($context["exception"] ?? $this->getContext($context, "exception"))));
        echo "
";
        
        $__internal_d8dad33b273b6a0cdb8ce240f16125d03b91efb85552426d156fe8675602a657->leave($__internal_d8dad33b273b6a0cdb8ce240f16125d03b91efb85552426d156fe8675602a657_prof);

        
        $__internal_da25989df19f1b6185f0aea31ad18ebf2b155c7feecc3e0f97652ad03145706a->leave($__internal_da25989df19f1b6185f0aea31ad18ebf2b155c7feecc3e0f97652ad03145706a_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.rdf.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ include('@Twig/Exception/exception.xml.twig', { exception: exception }) }}
", "TwigBundle:Exception:exception.rdf.twig", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\views\\symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle/Resources/views/Exception/exception.rdf.twig");
    }
}
