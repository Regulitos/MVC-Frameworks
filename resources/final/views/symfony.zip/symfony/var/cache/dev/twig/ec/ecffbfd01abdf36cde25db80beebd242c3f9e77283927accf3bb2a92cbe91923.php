<?php

/* @Framework/Form/button_row.html.php */
class __TwigTemplate_4b4bd3d6de7e2c90f067551787e44c1ef8d1bb38215839af9898f50ab5c0c5c1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8e01240b6e524d4c8db5ed532ceb6bec53716b527e6860e7de2e47b50edbb81b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8e01240b6e524d4c8db5ed532ceb6bec53716b527e6860e7de2e47b50edbb81b->enter($__internal_8e01240b6e524d4c8db5ed532ceb6bec53716b527e6860e7de2e47b50edbb81b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_row.html.php"));

        $__internal_6a7e2ff80eff51f550da151d8c349378076d6adab567cb8aac40be208c963939 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6a7e2ff80eff51f550da151d8c349378076d6adab567cb8aac40be208c963939->enter($__internal_6a7e2ff80eff51f550da151d8c349378076d6adab567cb8aac40be208c963939_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_row.html.php"));

        // line 1
        echo "<div>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
";
        
        $__internal_8e01240b6e524d4c8db5ed532ceb6bec53716b527e6860e7de2e47b50edbb81b->leave($__internal_8e01240b6e524d4c8db5ed532ceb6bec53716b527e6860e7de2e47b50edbb81b_prof);

        
        $__internal_6a7e2ff80eff51f550da151d8c349378076d6adab567cb8aac40be208c963939->leave($__internal_6a7e2ff80eff51f550da151d8c349378076d6adab567cb8aac40be208c963939_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
", "@Framework/Form/button_row.html.php", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\views\\symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\button_row.html.php");
    }
}
