<?php

/* @Framework/FormTable/hidden_row.html.php */
class __TwigTemplate_cf2596bacc63137065402920d774b5256063187a65f51591cf623dd87798c29d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1a738c321a6a864da6e20a9c42aac0c10395cfba589a30f1b1719ade24d8478c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1a738c321a6a864da6e20a9c42aac0c10395cfba589a30f1b1719ade24d8478c->enter($__internal_1a738c321a6a864da6e20a9c42aac0c10395cfba589a30f1b1719ade24d8478c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/hidden_row.html.php"));

        $__internal_06321fa0e1b635a0aabf2bb09f74dad1b1b256ec07a89f42a06621b0f63d89e6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_06321fa0e1b635a0aabf2bb09f74dad1b1b256ec07a89f42a06621b0f63d89e6->enter($__internal_06321fa0e1b635a0aabf2bb09f74dad1b1b256ec07a89f42a06621b0f63d89e6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/hidden_row.html.php"));

        // line 1
        echo "<tr style=\"display: none\">
    <td colspan=\"2\">
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
";
        
        $__internal_1a738c321a6a864da6e20a9c42aac0c10395cfba589a30f1b1719ade24d8478c->leave($__internal_1a738c321a6a864da6e20a9c42aac0c10395cfba589a30f1b1719ade24d8478c_prof);

        
        $__internal_06321fa0e1b635a0aabf2bb09f74dad1b1b256ec07a89f42a06621b0f63d89e6->leave($__internal_06321fa0e1b635a0aabf2bb09f74dad1b1b256ec07a89f42a06621b0f63d89e6_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/hidden_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<tr style=\"display: none\">
    <td colspan=\"2\">
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
", "@Framework/FormTable/hidden_row.html.php", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\views\\symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\FormTable\\hidden_row.html.php");
    }
}
