<?php

/* @Framework/Form/choice_options.html.php */
class __TwigTemplate_32699e087196b13f160cc7596ce48296a3737bb211057b369df885a37d7145a1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d30e85fc0a32e9eacaf5d0d62cce94c65eb28eaf867bd053b60d29b81184054b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d30e85fc0a32e9eacaf5d0d62cce94c65eb28eaf867bd053b60d29b81184054b->enter($__internal_d30e85fc0a32e9eacaf5d0d62cce94c65eb28eaf867bd053b60d29b81184054b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_options.html.php"));

        $__internal_81379fd3ff04c022841f74f28e1f06a67879c90fdaf3ef1b0ca69048bebd6b45 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_81379fd3ff04c022841f74f28e1f06a67879c90fdaf3ef1b0ca69048bebd6b45->enter($__internal_81379fd3ff04c022841f74f28e1f06a67879c90fdaf3ef1b0ca69048bebd6b45_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_options.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'choice_widget_options') ?>
";
        
        $__internal_d30e85fc0a32e9eacaf5d0d62cce94c65eb28eaf867bd053b60d29b81184054b->leave($__internal_d30e85fc0a32e9eacaf5d0d62cce94c65eb28eaf867bd053b60d29b81184054b_prof);

        
        $__internal_81379fd3ff04c022841f74f28e1f06a67879c90fdaf3ef1b0ca69048bebd6b45->leave($__internal_81379fd3ff04c022841f74f28e1f06a67879c90fdaf3ef1b0ca69048bebd6b45_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/choice_options.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'choice_widget_options') ?>
", "@Framework/Form/choice_options.html.php", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\views\\symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\choice_options.html.php");
    }
}
