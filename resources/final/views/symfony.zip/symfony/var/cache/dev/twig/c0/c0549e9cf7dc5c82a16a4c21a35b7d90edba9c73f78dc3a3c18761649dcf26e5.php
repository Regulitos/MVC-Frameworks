<?php

/* @Framework/Form/form_rest.html.php */
class __TwigTemplate_d93b5124d1343930b9de507e1d72d484371ea043cf13b9586b3e65790345dd86 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_47813b9a929a673a713c91633ebc908808e5477519db8e2515db3aebf60d8eff = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_47813b9a929a673a713c91633ebc908808e5477519db8e2515db3aebf60d8eff->enter($__internal_47813b9a929a673a713c91633ebc908808e5477519db8e2515db3aebf60d8eff_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_rest.html.php"));

        $__internal_2714db892375b699d2c67179dbdcc384480dd394f9f869571e8984a047224985 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2714db892375b699d2c67179dbdcc384480dd394f9f869571e8984a047224985->enter($__internal_2714db892375b699d2c67179dbdcc384480dd394f9f869571e8984a047224985_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_rest.html.php"));

        // line 1
        echo "<?php foreach (\$form as \$child): ?>
    <?php if (!\$child->isRendered()): ?>
        <?php echo \$view['form']->row(\$child) ?>
    <?php endif; ?>
<?php endforeach; ?>
";
        
        $__internal_47813b9a929a673a713c91633ebc908808e5477519db8e2515db3aebf60d8eff->leave($__internal_47813b9a929a673a713c91633ebc908808e5477519db8e2515db3aebf60d8eff_prof);

        
        $__internal_2714db892375b699d2c67179dbdcc384480dd394f9f869571e8984a047224985->leave($__internal_2714db892375b699d2c67179dbdcc384480dd394f9f869571e8984a047224985_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_rest.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php foreach (\$form as \$child): ?>
    <?php if (!\$child->isRendered()): ?>
        <?php echo \$view['form']->row(\$child) ?>
    <?php endif; ?>
<?php endforeach; ?>
", "@Framework/Form/form_rest.html.php", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\views\\symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\form_rest.html.php");
    }
}
