<?php

/* WebProfilerBundle:Profiler:ajax_layout.html.twig */
class __TwigTemplate_ea5546ba30baf4b586e3d8de7ea5609933e843ee1c480e8a1618a0e56cbaf936 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7a618b0b7ffe83563e71b03fb716d15e6c76e1b76985acc0301f8e650a618999 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_7a618b0b7ffe83563e71b03fb716d15e6c76e1b76985acc0301f8e650a618999->enter($__internal_7a618b0b7ffe83563e71b03fb716d15e6c76e1b76985acc0301f8e650a618999_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:ajax_layout.html.twig"));

        $__internal_ca56012ed2c5a6b585cb26071eec93d453a475c4a2e3df73c88cbf8017ca6841 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ca56012ed2c5a6b585cb26071eec93d453a475c4a2e3df73c88cbf8017ca6841->enter($__internal_ca56012ed2c5a6b585cb26071eec93d453a475c4a2e3df73c88cbf8017ca6841_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:ajax_layout.html.twig"));

        // line 1
        $this->displayBlock('panel', $context, $blocks);
        
        $__internal_7a618b0b7ffe83563e71b03fb716d15e6c76e1b76985acc0301f8e650a618999->leave($__internal_7a618b0b7ffe83563e71b03fb716d15e6c76e1b76985acc0301f8e650a618999_prof);

        
        $__internal_ca56012ed2c5a6b585cb26071eec93d453a475c4a2e3df73c88cbf8017ca6841->leave($__internal_ca56012ed2c5a6b585cb26071eec93d453a475c4a2e3df73c88cbf8017ca6841_prof);

    }

    public function block_panel($context, array $blocks = array())
    {
        $__internal_0ca3f1c0d78c8c79fadbabef74bf9e54ca01359a6f50e6259de9878bdb74693e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0ca3f1c0d78c8c79fadbabef74bf9e54ca01359a6f50e6259de9878bdb74693e->enter($__internal_0ca3f1c0d78c8c79fadbabef74bf9e54ca01359a6f50e6259de9878bdb74693e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_bf3a876dea4715ec8581b70d6d8423228f13d395108f5e94401659e284fb57bd = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_bf3a876dea4715ec8581b70d6d8423228f13d395108f5e94401659e284fb57bd->enter($__internal_bf3a876dea4715ec8581b70d6d8423228f13d395108f5e94401659e284fb57bd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        echo "";
        
        $__internal_bf3a876dea4715ec8581b70d6d8423228f13d395108f5e94401659e284fb57bd->leave($__internal_bf3a876dea4715ec8581b70d6d8423228f13d395108f5e94401659e284fb57bd_prof);

        
        $__internal_0ca3f1c0d78c8c79fadbabef74bf9e54ca01359a6f50e6259de9878bdb74693e->leave($__internal_0ca3f1c0d78c8c79fadbabef74bf9e54ca01359a6f50e6259de9878bdb74693e_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:ajax_layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  26 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% block panel '' %}
", "WebProfilerBundle:Profiler:ajax_layout.html.twig", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\views\\symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle/Resources/views/Profiler/ajax_layout.html.twig");
    }
}
