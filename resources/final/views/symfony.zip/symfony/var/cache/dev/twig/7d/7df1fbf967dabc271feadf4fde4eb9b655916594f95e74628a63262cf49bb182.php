<?php

/* @Framework/Form/url_widget.html.php */
class __TwigTemplate_9b3b60e87d166ef1e5169f63264e464b079dacde68f0423f1b0171aa91e45527 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f985262508d3ed1f6922d76cba7112d477f0e883bf577fa44c6cb70207f75a31 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f985262508d3ed1f6922d76cba7112d477f0e883bf577fa44c6cb70207f75a31->enter($__internal_f985262508d3ed1f6922d76cba7112d477f0e883bf577fa44c6cb70207f75a31_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/url_widget.html.php"));

        $__internal_345b4c18ccef23d498f9fa94a874135e13b93af58fde8942c05b879d60b57761 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_345b4c18ccef23d498f9fa94a874135e13b93af58fde8942c05b879d60b57761->enter($__internal_345b4c18ccef23d498f9fa94a874135e13b93af58fde8942c05b879d60b57761_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/url_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'url')) ?>
";
        
        $__internal_f985262508d3ed1f6922d76cba7112d477f0e883bf577fa44c6cb70207f75a31->leave($__internal_f985262508d3ed1f6922d76cba7112d477f0e883bf577fa44c6cb70207f75a31_prof);

        
        $__internal_345b4c18ccef23d498f9fa94a874135e13b93af58fde8942c05b879d60b57761->leave($__internal_345b4c18ccef23d498f9fa94a874135e13b93af58fde8942c05b879d60b57761_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/url_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'url')) ?>
", "@Framework/Form/url_widget.html.php", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\views\\symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\url_widget.html.php");
    }
}
