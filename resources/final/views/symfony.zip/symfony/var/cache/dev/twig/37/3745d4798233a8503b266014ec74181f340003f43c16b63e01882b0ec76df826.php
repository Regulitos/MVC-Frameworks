<?php

/* @Framework/Form/search_widget.html.php */
class __TwigTemplate_86b09fd648f156ff6c80423206809b69b634e339354b63d942f6e31710f8e890 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4646205133d9cf01bd939d9b824392313272e9caf629e9e83b16e089e5c62813 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4646205133d9cf01bd939d9b824392313272e9caf629e9e83b16e089e5c62813->enter($__internal_4646205133d9cf01bd939d9b824392313272e9caf629e9e83b16e089e5c62813_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/search_widget.html.php"));

        $__internal_324557505971fd249d0a797409ff77642b0849dfc6edfb585c105b8fa093f20a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_324557505971fd249d0a797409ff77642b0849dfc6edfb585c105b8fa093f20a->enter($__internal_324557505971fd249d0a797409ff77642b0849dfc6edfb585c105b8fa093f20a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/search_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'search')) ?>
";
        
        $__internal_4646205133d9cf01bd939d9b824392313272e9caf629e9e83b16e089e5c62813->leave($__internal_4646205133d9cf01bd939d9b824392313272e9caf629e9e83b16e089e5c62813_prof);

        
        $__internal_324557505971fd249d0a797409ff77642b0849dfc6edfb585c105b8fa093f20a->leave($__internal_324557505971fd249d0a797409ff77642b0849dfc6edfb585c105b8fa093f20a_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/search_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'search')) ?>
", "@Framework/Form/search_widget.html.php", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\views\\symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\search_widget.html.php");
    }
}
