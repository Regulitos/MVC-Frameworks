<?php

/* @Twig/Exception/error.atom.twig */
class __TwigTemplate_6ae93012740d9831bf45d8eec53ec090b960cb14574cd72bfce0d741960b659b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_95b86e92119ff159d86f0c02eb56385e79214fbcbd9a0e6bdb54d40d3f7f4d7c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_95b86e92119ff159d86f0c02eb56385e79214fbcbd9a0e6bdb54d40d3f7f4d7c->enter($__internal_95b86e92119ff159d86f0c02eb56385e79214fbcbd9a0e6bdb54d40d3f7f4d7c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.atom.twig"));

        $__internal_2f61de379f46ff00f0990f2c4d9ac05c0586d374fee42874fa71695a77aba3cc = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2f61de379f46ff00f0990f2c4d9ac05c0586d374fee42874fa71695a77aba3cc->enter($__internal_2f61de379f46ff00f0990f2c4d9ac05c0586d374fee42874fa71695a77aba3cc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.atom.twig"));

        // line 1
        echo twig_include($this->env, $context, "@Twig/Exception/error.xml.twig");
        echo "
";
        
        $__internal_95b86e92119ff159d86f0c02eb56385e79214fbcbd9a0e6bdb54d40d3f7f4d7c->leave($__internal_95b86e92119ff159d86f0c02eb56385e79214fbcbd9a0e6bdb54d40d3f7f4d7c_prof);

        
        $__internal_2f61de379f46ff00f0990f2c4d9ac05c0586d374fee42874fa71695a77aba3cc->leave($__internal_2f61de379f46ff00f0990f2c4d9ac05c0586d374fee42874fa71695a77aba3cc_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/error.atom.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ include('@Twig/Exception/error.xml.twig') }}
", "@Twig/Exception/error.atom.twig", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\views\\symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\error.atom.twig");
    }
}
