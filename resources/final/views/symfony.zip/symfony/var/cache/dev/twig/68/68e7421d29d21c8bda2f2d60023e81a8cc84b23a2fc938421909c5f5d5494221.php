<?php

/* TwigBundle:Exception:exception.atom.twig */
class __TwigTemplate_8bad279752edf5670e2ecf0b4208dbc1dd1c3e31e9889cff1243f386cedd9af0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_349778b23e190ebfaac795c1244afdb56acc88e93ec0517a63b8f13a2193bada = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_349778b23e190ebfaac795c1244afdb56acc88e93ec0517a63b8f13a2193bada->enter($__internal_349778b23e190ebfaac795c1244afdb56acc88e93ec0517a63b8f13a2193bada_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.atom.twig"));

        $__internal_3934ed3dc4890f06805122b1a3847949aec9b273d3c1fc696d97307a0b53d384 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3934ed3dc4890f06805122b1a3847949aec9b273d3c1fc696d97307a0b53d384->enter($__internal_3934ed3dc4890f06805122b1a3847949aec9b273d3c1fc696d97307a0b53d384_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.atom.twig"));

        // line 1
        echo twig_include($this->env, $context, "@Twig/Exception/exception.xml.twig", array("exception" => ($context["exception"] ?? $this->getContext($context, "exception"))));
        echo "
";
        
        $__internal_349778b23e190ebfaac795c1244afdb56acc88e93ec0517a63b8f13a2193bada->leave($__internal_349778b23e190ebfaac795c1244afdb56acc88e93ec0517a63b8f13a2193bada_prof);

        
        $__internal_3934ed3dc4890f06805122b1a3847949aec9b273d3c1fc696d97307a0b53d384->leave($__internal_3934ed3dc4890f06805122b1a3847949aec9b273d3c1fc696d97307a0b53d384_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.atom.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ include('@Twig/Exception/exception.xml.twig', { exception: exception }) }}
", "TwigBundle:Exception:exception.atom.twig", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\views\\symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle/Resources/views/Exception/exception.atom.twig");
    }
}
