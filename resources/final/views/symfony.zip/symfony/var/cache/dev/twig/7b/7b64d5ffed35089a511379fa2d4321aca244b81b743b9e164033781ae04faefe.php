<?php

/* @WebProfiler/Profiler/open.html.twig */
class __TwigTemplate_02a887d4589b168b4292e6617e38c6962d99bad21ae0097b64a11bc6d3bf9a91 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/base.html.twig", "@WebProfiler/Profiler/open.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ba6028cd5a0447fce986c2c1b49764a3e7920e6b294cb7ab0bd65c25e81d0b2d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ba6028cd5a0447fce986c2c1b49764a3e7920e6b294cb7ab0bd65c25e81d0b2d->enter($__internal_ba6028cd5a0447fce986c2c1b49764a3e7920e6b294cb7ab0bd65c25e81d0b2d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/open.html.twig"));

        $__internal_99ca017053b9ee89006830ed0a4f41cf3da94f7709fe74e4e09cb65e63be45a6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_99ca017053b9ee89006830ed0a4f41cf3da94f7709fe74e4e09cb65e63be45a6->enter($__internal_99ca017053b9ee89006830ed0a4f41cf3da94f7709fe74e4e09cb65e63be45a6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/open.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_ba6028cd5a0447fce986c2c1b49764a3e7920e6b294cb7ab0bd65c25e81d0b2d->leave($__internal_ba6028cd5a0447fce986c2c1b49764a3e7920e6b294cb7ab0bd65c25e81d0b2d_prof);

        
        $__internal_99ca017053b9ee89006830ed0a4f41cf3da94f7709fe74e4e09cb65e63be45a6->leave($__internal_99ca017053b9ee89006830ed0a4f41cf3da94f7709fe74e4e09cb65e63be45a6_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_af1468fd336dd14a10df996f38c83401007196d887ab6917b1cc333149349948 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_af1468fd336dd14a10df996f38c83401007196d887ab6917b1cc333149349948->enter($__internal_af1468fd336dd14a10df996f38c83401007196d887ab6917b1cc333149349948_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        $__internal_bbdd105a92728b7b2310f302dbd5dfd8f39ba5382e53aa2f1fa5b49d4555a587 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_bbdd105a92728b7b2310f302dbd5dfd8f39ba5382e53aa2f1fa5b49d4555a587->enter($__internal_bbdd105a92728b7b2310f302dbd5dfd8f39ba5382e53aa2f1fa5b49d4555a587_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    <style>
        ";
        // line 5
        echo twig_include($this->env, $context, "@WebProfiler/Profiler/open.css.twig");
        echo "
    </style>
";
        
        $__internal_bbdd105a92728b7b2310f302dbd5dfd8f39ba5382e53aa2f1fa5b49d4555a587->leave($__internal_bbdd105a92728b7b2310f302dbd5dfd8f39ba5382e53aa2f1fa5b49d4555a587_prof);

        
        $__internal_af1468fd336dd14a10df996f38c83401007196d887ab6917b1cc333149349948->leave($__internal_af1468fd336dd14a10df996f38c83401007196d887ab6917b1cc333149349948_prof);

    }

    // line 9
    public function block_body($context, array $blocks = array())
    {
        $__internal_cb6beb739b07904bfed3b5598539cd579c213e1339bd1abb71e214f15a80ed63 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_cb6beb739b07904bfed3b5598539cd579c213e1339bd1abb71e214f15a80ed63->enter($__internal_cb6beb739b07904bfed3b5598539cd579c213e1339bd1abb71e214f15a80ed63_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_6c36323dd343cc7af7d5a85c82957cf6bc3c5db779a8551e9fa8a6edd06599b9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6c36323dd343cc7af7d5a85c82957cf6bc3c5db779a8551e9fa8a6edd06599b9->enter($__internal_6c36323dd343cc7af7d5a85c82957cf6bc3c5db779a8551e9fa8a6edd06599b9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 10
        echo "<div class=\"header\">
    <h1>";
        // line 11
        echo twig_escape_filter($this->env, ($context["file"] ?? $this->getContext($context, "file")), "html", null, true);
        echo " <small>line ";
        echo twig_escape_filter($this->env, ($context["line"] ?? $this->getContext($context, "line")), "html", null, true);
        echo "</small></h1>
    <a class=\"doc\" href=\"https://symfony.com/doc/";
        // line 12
        echo twig_escape_filter($this->env, twig_constant("Symfony\\Component\\HttpKernel\\Kernel::VERSION"), "html", null, true);
        echo "/reference/configuration/framework.html#ide\" rel=\"help\">Open in your IDE?</a>
</div>
<div class=\"source\">
    ";
        // line 15
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\CodeExtension')->fileExcerpt(($context["filename"] ?? $this->getContext($context, "filename")), ($context["line"] ?? $this->getContext($context, "line")),  -1);
        echo "
</div>
";
        
        $__internal_6c36323dd343cc7af7d5a85c82957cf6bc3c5db779a8551e9fa8a6edd06599b9->leave($__internal_6c36323dd343cc7af7d5a85c82957cf6bc3c5db779a8551e9fa8a6edd06599b9_prof);

        
        $__internal_cb6beb739b07904bfed3b5598539cd579c213e1339bd1abb71e214f15a80ed63->leave($__internal_cb6beb739b07904bfed3b5598539cd579c213e1339bd1abb71e214f15a80ed63_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Profiler/open.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  90 => 15,  84 => 12,  78 => 11,  75 => 10,  66 => 9,  53 => 5,  50 => 4,  41 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/base.html.twig' %}

{% block head %}
    <style>
        {{ include('@WebProfiler/Profiler/open.css.twig') }}
    </style>
{% endblock %}

{% block body %}
<div class=\"header\">
    <h1>{{ file }} <small>line {{ line }}</small></h1>
    <a class=\"doc\" href=\"https://symfony.com/doc/{{ constant('Symfony\\\\Component\\\\HttpKernel\\\\Kernel::VERSION') }}/reference/configuration/framework.html#ide\" rel=\"help\">Open in your IDE?</a>
</div>
<div class=\"source\">
    {{ filename|file_excerpt(line, -1) }}
</div>
{% endblock %}
", "@WebProfiler/Profiler/open.html.twig", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\views\\symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Profiler\\open.html.twig");
    }
}
