<?php

/* TwigBundle:Exception:error.json.twig */
class __TwigTemplate_3a010ab51691f963c8a75573053e9d8771d909b3dd7c9b14dbdd21839e35835b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a6f7412ffd52da37493fb2bf72557ae9aec7bace67a27d8d6fc7ae0a9c28fd7d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a6f7412ffd52da37493fb2bf72557ae9aec7bace67a27d8d6fc7ae0a9c28fd7d->enter($__internal_a6f7412ffd52da37493fb2bf72557ae9aec7bace67a27d8d6fc7ae0a9c28fd7d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.json.twig"));

        $__internal_21d981b6e827213f737c0ef32075e37d2f0f1c94bd5169d919545187d4d3cac2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_21d981b6e827213f737c0ef32075e37d2f0f1c94bd5169d919545187d4d3cac2->enter($__internal_21d981b6e827213f737c0ef32075e37d2f0f1c94bd5169d919545187d4d3cac2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.json.twig"));

        // line 1
        echo twig_jsonencode_filter(array("error" => array("code" => ($context["status_code"] ?? $this->getContext($context, "status_code")), "message" => ($context["status_text"] ?? $this->getContext($context, "status_text")))));
        echo "
";
        
        $__internal_a6f7412ffd52da37493fb2bf72557ae9aec7bace67a27d8d6fc7ae0a9c28fd7d->leave($__internal_a6f7412ffd52da37493fb2bf72557ae9aec7bace67a27d8d6fc7ae0a9c28fd7d_prof);

        
        $__internal_21d981b6e827213f737c0ef32075e37d2f0f1c94bd5169d919545187d4d3cac2->leave($__internal_21d981b6e827213f737c0ef32075e37d2f0f1c94bd5169d919545187d4d3cac2_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.json.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ { 'error': { 'code': status_code, 'message': status_text } }|json_encode|raw }}
", "TwigBundle:Exception:error.json.twig", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\views\\symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle/Resources/views/Exception/error.json.twig");
    }
}
