<?php

/* @Framework/Form/submit_widget.html.php */
class __TwigTemplate_c731e6a0ca590251c73aa92c3534eb9fb1c2732dc8dfaee985c957d1403fbb83 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b4d9758a7bd65405832dcee9f0e6710bd5f6e5887ebf6b12d9009de9d2569623 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b4d9758a7bd65405832dcee9f0e6710bd5f6e5887ebf6b12d9009de9d2569623->enter($__internal_b4d9758a7bd65405832dcee9f0e6710bd5f6e5887ebf6b12d9009de9d2569623_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/submit_widget.html.php"));

        $__internal_1c1fd5061afa7911846a0f74cdbf86b77217ea8d9bedf10bfbedd8119ba9ac0d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1c1fd5061afa7911846a0f74cdbf86b77217ea8d9bedf10bfbedd8119ba9ac0d->enter($__internal_1c1fd5061afa7911846a0f74cdbf86b77217ea8d9bedf10bfbedd8119ba9ac0d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/submit_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'button_widget', array('type' => isset(\$type) ? \$type : 'submit')) ?>
";
        
        $__internal_b4d9758a7bd65405832dcee9f0e6710bd5f6e5887ebf6b12d9009de9d2569623->leave($__internal_b4d9758a7bd65405832dcee9f0e6710bd5f6e5887ebf6b12d9009de9d2569623_prof);

        
        $__internal_1c1fd5061afa7911846a0f74cdbf86b77217ea8d9bedf10bfbedd8119ba9ac0d->leave($__internal_1c1fd5061afa7911846a0f74cdbf86b77217ea8d9bedf10bfbedd8119ba9ac0d_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/submit_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'button_widget', array('type' => isset(\$type) ? \$type : 'submit')) ?>
", "@Framework/Form/submit_widget.html.php", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\views\\symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\submit_widget.html.php");
    }
}
