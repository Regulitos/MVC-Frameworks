<?php

/* @Framework/Form/form_row.html.php */
class __TwigTemplate_71f85e5b30b4aa0015add95fdf2e935f230ba8438e56b4bfc4a827ede9341e12 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1ef09baee616646fc1d317306b5f4d64e7b1c480a038586420c18b5fcb494c5b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1ef09baee616646fc1d317306b5f4d64e7b1c480a038586420c18b5fcb494c5b->enter($__internal_1ef09baee616646fc1d317306b5f4d64e7b1c480a038586420c18b5fcb494c5b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_row.html.php"));

        $__internal_ed32ecb49e515922abebcbdd2a06407e0857568fa2b3ac4c0946d1cb2b3fb452 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ed32ecb49e515922abebcbdd2a06407e0857568fa2b3ac4c0946d1cb2b3fb452->enter($__internal_ed32ecb49e515922abebcbdd2a06407e0857568fa2b3ac4c0946d1cb2b3fb452_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_row.html.php"));

        // line 1
        echo "<div>
    <?php echo \$view['form']->label(\$form) ?>
    <?php echo \$view['form']->errors(\$form) ?>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
";
        
        $__internal_1ef09baee616646fc1d317306b5f4d64e7b1c480a038586420c18b5fcb494c5b->leave($__internal_1ef09baee616646fc1d317306b5f4d64e7b1c480a038586420c18b5fcb494c5b_prof);

        
        $__internal_ed32ecb49e515922abebcbdd2a06407e0857568fa2b3ac4c0946d1cb2b3fb452->leave($__internal_ed32ecb49e515922abebcbdd2a06407e0857568fa2b3ac4c0946d1cb2b3fb452_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div>
    <?php echo \$view['form']->label(\$form) ?>
    <?php echo \$view['form']->errors(\$form) ?>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
", "@Framework/Form/form_row.html.php", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\views\\symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\form_row.html.php");
    }
}
