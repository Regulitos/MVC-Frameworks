<?php

/* @Framework/Form/hidden_widget.html.php */
class __TwigTemplate_ef0e02473280788a3697a14c8764ae33e7774eed4d262bda3aac5633e3cefc7d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_edb11162a5e3b63c42dd1234fb923915337a13674cc8c51bf62802c4f3efba3c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_edb11162a5e3b63c42dd1234fb923915337a13674cc8c51bf62802c4f3efba3c->enter($__internal_edb11162a5e3b63c42dd1234fb923915337a13674cc8c51bf62802c4f3efba3c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/hidden_widget.html.php"));

        $__internal_6cf13332622d9ae1cf10c076e76cdf97316a8512a83380e716114cbc89c7436e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6cf13332622d9ae1cf10c076e76cdf97316a8512a83380e716114cbc89c7436e->enter($__internal_6cf13332622d9ae1cf10c076e76cdf97316a8512a83380e716114cbc89c7436e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/hidden_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'hidden')) ?>
";
        
        $__internal_edb11162a5e3b63c42dd1234fb923915337a13674cc8c51bf62802c4f3efba3c->leave($__internal_edb11162a5e3b63c42dd1234fb923915337a13674cc8c51bf62802c4f3efba3c_prof);

        
        $__internal_6cf13332622d9ae1cf10c076e76cdf97316a8512a83380e716114cbc89c7436e->leave($__internal_6cf13332622d9ae1cf10c076e76cdf97316a8512a83380e716114cbc89c7436e_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/hidden_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'hidden')) ?>
", "@Framework/Form/hidden_widget.html.php", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\views\\symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\hidden_widget.html.php");
    }
}
