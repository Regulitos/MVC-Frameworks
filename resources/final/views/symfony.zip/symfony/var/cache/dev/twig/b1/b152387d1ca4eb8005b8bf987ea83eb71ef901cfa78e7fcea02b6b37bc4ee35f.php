<?php

/* @WebProfiler/Profiler/toolbar_redirect.html.twig */
class __TwigTemplate_b3bc6c61daa78099703cd636bf909b5a35b1e5a72efb9a36c4125b567accfaa0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@Twig/layout.html.twig", "@WebProfiler/Profiler/toolbar_redirect.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@Twig/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_21883c8e0217f729ec00a08f0fcb733eee983a9f7673016575dc900e3e4288f9 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_21883c8e0217f729ec00a08f0fcb733eee983a9f7673016575dc900e3e4288f9->enter($__internal_21883c8e0217f729ec00a08f0fcb733eee983a9f7673016575dc900e3e4288f9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/toolbar_redirect.html.twig"));

        $__internal_6423a753badf7ac47826473c3d5f7e8748dcd4d3c7af0575c3d96dbabb13987a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6423a753badf7ac47826473c3d5f7e8748dcd4d3c7af0575c3d96dbabb13987a->enter($__internal_6423a753badf7ac47826473c3d5f7e8748dcd4d3c7af0575c3d96dbabb13987a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/toolbar_redirect.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_21883c8e0217f729ec00a08f0fcb733eee983a9f7673016575dc900e3e4288f9->leave($__internal_21883c8e0217f729ec00a08f0fcb733eee983a9f7673016575dc900e3e4288f9_prof);

        
        $__internal_6423a753badf7ac47826473c3d5f7e8748dcd4d3c7af0575c3d96dbabb13987a->leave($__internal_6423a753badf7ac47826473c3d5f7e8748dcd4d3c7af0575c3d96dbabb13987a_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_beb46555bfe4d0d8be250acb63abcbedbe2feddd6d4b59ffbdfe964a1fa25641 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_beb46555bfe4d0d8be250acb63abcbedbe2feddd6d4b59ffbdfe964a1fa25641->enter($__internal_beb46555bfe4d0d8be250acb63abcbedbe2feddd6d4b59ffbdfe964a1fa25641_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_1ab7456f02a3a8be7bc12d2c26137027090a3eee4a1999915d818bb4028a0610 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1ab7456f02a3a8be7bc12d2c26137027090a3eee4a1999915d818bb4028a0610->enter($__internal_1ab7456f02a3a8be7bc12d2c26137027090a3eee4a1999915d818bb4028a0610_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Redirection Intercepted";
        
        $__internal_1ab7456f02a3a8be7bc12d2c26137027090a3eee4a1999915d818bb4028a0610->leave($__internal_1ab7456f02a3a8be7bc12d2c26137027090a3eee4a1999915d818bb4028a0610_prof);

        
        $__internal_beb46555bfe4d0d8be250acb63abcbedbe2feddd6d4b59ffbdfe964a1fa25641->leave($__internal_beb46555bfe4d0d8be250acb63abcbedbe2feddd6d4b59ffbdfe964a1fa25641_prof);

    }

    // line 5
    public function block_body($context, array $blocks = array())
    {
        $__internal_cf3fa4b85a09025860e8bb060d457c7984746b96250d54c43825d4396c382a45 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_cf3fa4b85a09025860e8bb060d457c7984746b96250d54c43825d4396c382a45->enter($__internal_cf3fa4b85a09025860e8bb060d457c7984746b96250d54c43825d4396c382a45_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_8d59a6eb8e20778be9be1b87b2837abfd633f1d56980a5c6928ffcd8bd68d557 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8d59a6eb8e20778be9be1b87b2837abfd633f1d56980a5c6928ffcd8bd68d557->enter($__internal_8d59a6eb8e20778be9be1b87b2837abfd633f1d56980a5c6928ffcd8bd68d557_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "    <div class=\"sf-reset\">
        <div class=\"block-exception\">
            <h1>This request redirects to <a href=\"";
        // line 8
        echo twig_escape_filter($this->env, ($context["location"] ?? $this->getContext($context, "location")), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, ($context["location"] ?? $this->getContext($context, "location")), "html", null, true);
        echo "</a>.</h1>

            <p>
                <small>
                    The redirect was intercepted by the web debug toolbar to help debugging.
                    For more information, see the \"intercept-redirects\" option of the Profiler.
                </small>
            </p>
        </div>
    </div>
";
        
        $__internal_8d59a6eb8e20778be9be1b87b2837abfd633f1d56980a5c6928ffcd8bd68d557->leave($__internal_8d59a6eb8e20778be9be1b87b2837abfd633f1d56980a5c6928ffcd8bd68d557_prof);

        
        $__internal_cf3fa4b85a09025860e8bb060d457c7984746b96250d54c43825d4396c382a45->leave($__internal_cf3fa4b85a09025860e8bb060d457c7984746b96250d54c43825d4396c382a45_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Profiler/toolbar_redirect.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  72 => 8,  68 => 6,  59 => 5,  41 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@Twig/layout.html.twig' %}

{% block title 'Redirection Intercepted' %}

{% block body %}
    <div class=\"sf-reset\">
        <div class=\"block-exception\">
            <h1>This request redirects to <a href=\"{{ location }}\">{{ location }}</a>.</h1>

            <p>
                <small>
                    The redirect was intercepted by the web debug toolbar to help debugging.
                    For more information, see the \"intercept-redirects\" option of the Profiler.
                </small>
            </p>
        </div>
    </div>
{% endblock %}
", "@WebProfiler/Profiler/toolbar_redirect.html.twig", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\views\\symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Profiler\\toolbar_redirect.html.twig");
    }
}
