<?php

/* @Framework/Form/container_attributes.html.php */
class __TwigTemplate_8a959162f56f1bfbb5f9c52e02de2bde1e6c6462ba175f004ceb38a8defcd36f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d72231d1bce94244f0f0674dec6b948c0cc97a3c819ddbb75faef38ba6547e61 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d72231d1bce94244f0f0674dec6b948c0cc97a3c819ddbb75faef38ba6547e61->enter($__internal_d72231d1bce94244f0f0674dec6b948c0cc97a3c819ddbb75faef38ba6547e61_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/container_attributes.html.php"));

        $__internal_9e979570247a52ba83b3d716a271d5514b59d56c2ebb3b4101f04219532162ed = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9e979570247a52ba83b3d716a271d5514b59d56c2ebb3b4101f04219532162ed->enter($__internal_9e979570247a52ba83b3d716a271d5514b59d56c2ebb3b4101f04219532162ed_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/container_attributes.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>
";
        
        $__internal_d72231d1bce94244f0f0674dec6b948c0cc97a3c819ddbb75faef38ba6547e61->leave($__internal_d72231d1bce94244f0f0674dec6b948c0cc97a3c819ddbb75faef38ba6547e61_prof);

        
        $__internal_9e979570247a52ba83b3d716a271d5514b59d56c2ebb3b4101f04219532162ed->leave($__internal_9e979570247a52ba83b3d716a271d5514b59d56c2ebb3b4101f04219532162ed_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/container_attributes.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>
", "@Framework/Form/container_attributes.html.php", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\views\\symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\container_attributes.html.php");
    }
}
