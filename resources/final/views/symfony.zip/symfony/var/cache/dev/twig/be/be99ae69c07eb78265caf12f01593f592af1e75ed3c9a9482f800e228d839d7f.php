<?php

/* @Framework/Form/email_widget.html.php */
class __TwigTemplate_2f3d959d9d3903a747a22cbd389c8b17ad767e5dc1fd577fc679de2d401a013c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_df0592159dffd762d73301824c76d47cb8aef5a981ab9919ac1f363b7ebc4df0 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_df0592159dffd762d73301824c76d47cb8aef5a981ab9919ac1f363b7ebc4df0->enter($__internal_df0592159dffd762d73301824c76d47cb8aef5a981ab9919ac1f363b7ebc4df0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/email_widget.html.php"));

        $__internal_84d0226c42c5ce42cc75cdf3ac2cfb0985cfd00c8ec940337ba577692ccb0a18 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_84d0226c42c5ce42cc75cdf3ac2cfb0985cfd00c8ec940337ba577692ccb0a18->enter($__internal_84d0226c42c5ce42cc75cdf3ac2cfb0985cfd00c8ec940337ba577692ccb0a18_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/email_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'email')) ?>
";
        
        $__internal_df0592159dffd762d73301824c76d47cb8aef5a981ab9919ac1f363b7ebc4df0->leave($__internal_df0592159dffd762d73301824c76d47cb8aef5a981ab9919ac1f363b7ebc4df0_prof);

        
        $__internal_84d0226c42c5ce42cc75cdf3ac2cfb0985cfd00c8ec940337ba577692ccb0a18->leave($__internal_84d0226c42c5ce42cc75cdf3ac2cfb0985cfd00c8ec940337ba577692ccb0a18_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/email_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'email')) ?>
", "@Framework/Form/email_widget.html.php", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\views\\symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\email_widget.html.php");
    }
}
