<?php

/* @Twig/Exception/exception.js.twig */
class __TwigTemplate_503a724b00859d73420ea91e59716c8bb8214c1a5e6126e48cf929e0c700f40e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5b43f9efbb44ac184f7c482a6dcd36f00580253c1154d3883c9f223c59aa2e4a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5b43f9efbb44ac184f7c482a6dcd36f00580253c1154d3883c9f223c59aa2e4a->enter($__internal_5b43f9efbb44ac184f7c482a6dcd36f00580253c1154d3883c9f223c59aa2e4a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.js.twig"));

        $__internal_6ba1a86a6e0fe1d9740a8be60a4b37af6bb66d6fa8da92da64f99b8c592d3e08 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6ba1a86a6e0fe1d9740a8be60a4b37af6bb66d6fa8da92da64f99b8c592d3e08->enter($__internal_6ba1a86a6e0fe1d9740a8be60a4b37af6bb66d6fa8da92da64f99b8c592d3e08_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.js.twig"));

        // line 1
        echo "/*
";
        // line 2
        echo twig_include($this->env, $context, "@Twig/Exception/exception.txt.twig", array("exception" => ($context["exception"] ?? $this->getContext($context, "exception"))));
        echo "
*/
";
        
        $__internal_5b43f9efbb44ac184f7c482a6dcd36f00580253c1154d3883c9f223c59aa2e4a->leave($__internal_5b43f9efbb44ac184f7c482a6dcd36f00580253c1154d3883c9f223c59aa2e4a_prof);

        
        $__internal_6ba1a86a6e0fe1d9740a8be60a4b37af6bb66d6fa8da92da64f99b8c592d3e08->leave($__internal_6ba1a86a6e0fe1d9740a8be60a4b37af6bb66d6fa8da92da64f99b8c592d3e08_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/exception.js.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  28 => 2,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("/*
{{ include('@Twig/Exception/exception.txt.twig', { exception: exception }) }}
*/
", "@Twig/Exception/exception.js.twig", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\views\\symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\exception.js.twig");
    }
}
