<?php

/* TwigBundle:Exception:exception.json.twig */
class __TwigTemplate_9288100d8334098eb8c275861fc64d9d89cf92d90e88e781d43c3626d822db1f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a8908f51090a83a2bb7bae87943239c1e145c114e09016c9ea6fc86aa31288a7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a8908f51090a83a2bb7bae87943239c1e145c114e09016c9ea6fc86aa31288a7->enter($__internal_a8908f51090a83a2bb7bae87943239c1e145c114e09016c9ea6fc86aa31288a7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.json.twig"));

        $__internal_7702f948507e5d08253642a846b0baf6c44dd8a06eefe3b13a0f2c5cb7ad27fb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7702f948507e5d08253642a846b0baf6c44dd8a06eefe3b13a0f2c5cb7ad27fb->enter($__internal_7702f948507e5d08253642a846b0baf6c44dd8a06eefe3b13a0f2c5cb7ad27fb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.json.twig"));

        // line 1
        echo twig_jsonencode_filter(array("error" => array("code" => ($context["status_code"] ?? $this->getContext($context, "status_code")), "message" => ($context["status_text"] ?? $this->getContext($context, "status_text")), "exception" => $this->getAttribute(($context["exception"] ?? $this->getContext($context, "exception")), "toarray", array()))));
        echo "
";
        
        $__internal_a8908f51090a83a2bb7bae87943239c1e145c114e09016c9ea6fc86aa31288a7->leave($__internal_a8908f51090a83a2bb7bae87943239c1e145c114e09016c9ea6fc86aa31288a7_prof);

        
        $__internal_7702f948507e5d08253642a846b0baf6c44dd8a06eefe3b13a0f2c5cb7ad27fb->leave($__internal_7702f948507e5d08253642a846b0baf6c44dd8a06eefe3b13a0f2c5cb7ad27fb_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.json.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ { 'error': { 'code': status_code, 'message': status_text, 'exception': exception.toarray } }|json_encode|raw }}
", "TwigBundle:Exception:exception.json.twig", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\views\\symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle/Resources/views/Exception/exception.json.twig");
    }
}
