<?php

/* @WebProfiler/Profiler/ajax_layout.html.twig */
class __TwigTemplate_e654a57c1c1190cdb6754f7fe92c6fa0261a0159ec19cdd8b92747da0cd431a8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e71c001713a79ca2b08f111b35725cbf92387abb8835de9c430541bd2983f518 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e71c001713a79ca2b08f111b35725cbf92387abb8835de9c430541bd2983f518->enter($__internal_e71c001713a79ca2b08f111b35725cbf92387abb8835de9c430541bd2983f518_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/ajax_layout.html.twig"));

        $__internal_64bfaf044320c8bfec5b9af9bdcd1550c62f5befeead4edb9b4010b713dbb4b9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_64bfaf044320c8bfec5b9af9bdcd1550c62f5befeead4edb9b4010b713dbb4b9->enter($__internal_64bfaf044320c8bfec5b9af9bdcd1550c62f5befeead4edb9b4010b713dbb4b9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/ajax_layout.html.twig"));

        // line 1
        $this->displayBlock('panel', $context, $blocks);
        
        $__internal_e71c001713a79ca2b08f111b35725cbf92387abb8835de9c430541bd2983f518->leave($__internal_e71c001713a79ca2b08f111b35725cbf92387abb8835de9c430541bd2983f518_prof);

        
        $__internal_64bfaf044320c8bfec5b9af9bdcd1550c62f5befeead4edb9b4010b713dbb4b9->leave($__internal_64bfaf044320c8bfec5b9af9bdcd1550c62f5befeead4edb9b4010b713dbb4b9_prof);

    }

    public function block_panel($context, array $blocks = array())
    {
        $__internal_f8b4bf748276f4cc1257f50bb184224a7a7ad0626a806e8e86738fd16a93d3a2 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f8b4bf748276f4cc1257f50bb184224a7a7ad0626a806e8e86738fd16a93d3a2->enter($__internal_f8b4bf748276f4cc1257f50bb184224a7a7ad0626a806e8e86738fd16a93d3a2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_c4a11d8f0ce00a317610daafe46ae4dc97f2f794a6197426351aee3bf00de511 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c4a11d8f0ce00a317610daafe46ae4dc97f2f794a6197426351aee3bf00de511->enter($__internal_c4a11d8f0ce00a317610daafe46ae4dc97f2f794a6197426351aee3bf00de511_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        echo "";
        
        $__internal_c4a11d8f0ce00a317610daafe46ae4dc97f2f794a6197426351aee3bf00de511->leave($__internal_c4a11d8f0ce00a317610daafe46ae4dc97f2f794a6197426351aee3bf00de511_prof);

        
        $__internal_f8b4bf748276f4cc1257f50bb184224a7a7ad0626a806e8e86738fd16a93d3a2->leave($__internal_f8b4bf748276f4cc1257f50bb184224a7a7ad0626a806e8e86738fd16a93d3a2_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Profiler/ajax_layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  26 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% block panel '' %}
", "@WebProfiler/Profiler/ajax_layout.html.twig", "C:\\xampp\\htdocs\\courses\\MVC-Frameworks\\Resources\\start\\views\\symfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Profiler\\ajax_layout.html.twig");
    }
}
