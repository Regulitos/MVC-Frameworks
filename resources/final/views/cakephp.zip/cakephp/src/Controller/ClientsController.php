<?php
namespace App\Controller;

use App\Controller\AppController;

class ClientsController extends AppController
{

    var $clients = [ 
                    [ 'id' => 0 , 'name' => 'Emmett', 'last_name' => 'Brown', 'email' => 'emmett@domain.com' ] ,
                    [ 'id' => 1 , 'name' => 'Jennifer', 'last_name' => 'Parker', 'email' => 'jennifer@domain.com' ] ,
                ];

    public function index()
    {
        //$this->response->body('New controller method index');
        //return $this->response;
        $this->set('clients', $this->clients);
    }

    public function details( $id )
    {
        //$this->response->body('Id: ' . $id);
        //return $this->response;
    }
}